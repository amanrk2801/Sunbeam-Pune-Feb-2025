package com.sunbeam.dao;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;

import com.sunbeam.pojos.Candidate;

public interface CandidateDao {
//get all candidates
	List<Candidate> getAllCandidates() throws SQLException;

//incr votes
	String incrementCandidateVotes(int candidateId) throws SQLException;

	// add a method to get top 2 candidates
	List<Candidate> getTop2Candidates() throws SQLException;

	// add a method to get party wise votes
	LinkedHashMap<String, Integer> getPartywiseVotes() throws SQLException;

	// delete candidate details
	String deleteCandidateDetails(int candidateId) throws SQLException;

	// update candidate details
	String updateCandidateDetails(String newParty, int votes, int candidateId) throws SQLException;
}
