package com.sunbeam.service;

import java.util.List;

import com.sunbeam.entities.Category;

public interface CategoryService {
	List<Category> getAllCategories();
	Category saveCategoryDetails(Category category);
	Category getCategoryDetails(Long categoryId);
	String updateCategoryDetails(Long categoryId,Category category);
	String deleteCategoryDetails(Long categoryId);
	
}
