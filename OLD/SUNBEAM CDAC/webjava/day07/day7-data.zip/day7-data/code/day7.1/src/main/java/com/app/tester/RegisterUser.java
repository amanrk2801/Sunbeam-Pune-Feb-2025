package com.app.tester;

import org.hibernate.SessionFactory;

import com.app.dao.UserDao;
import com.app.dao.UserDaoImpl;
import com.app.entities.Role;
import com.app.entities.User;

import static com.app.utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

public class RegisterUser {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) {
			// create dao
			UserDao dao = new UserDaoImpl();// up casting
			System.out.println("Enter user details - String firstName, String lastName, String email, "
					+ "String password, LocalDate dob, double regAmount,\r\n" + "			Role userRole");
			User user = new User(sc.next(), sc.next(), sc.next(), 
					sc.next(), LocalDate.parse(sc.next()),
					sc.nextDouble(), 
					Role.valueOf(sc.next().toUpperCase()));
			//invoke dao's method
			System.out.println(dao.registerNewUser(user));
		} // JVM -sc.close , sf.close() -> DBCP clened up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
