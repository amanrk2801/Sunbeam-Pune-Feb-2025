package com.sunbeam.service;

import java.util.List;

import com.sunbeam.entities.Restaurant;

public interface RestaurantService {
	List<Restaurant> getAllRestaurants();
	String deleteRestaurantDetail(Long restaurantId);
	Restaurant getRestaurantDetails(Long id);
	String updateDetails(Long id, Restaurant restaurant);
	String addNewRestaurant(Restaurant transientRestaurant);
}
