package com.app.service;

import java.util.List;

import com.app.entities.Department;

public interface DepartmentService {
	List<Department> getAllDepartmens();
	
}
