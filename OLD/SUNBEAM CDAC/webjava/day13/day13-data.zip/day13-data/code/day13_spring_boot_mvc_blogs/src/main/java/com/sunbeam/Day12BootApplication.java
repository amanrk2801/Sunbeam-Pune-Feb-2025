package com.sunbeam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day12BootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day12BootApplication.class, args);
	}

}
