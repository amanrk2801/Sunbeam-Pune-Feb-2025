package com.sunbeam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeam.dao.UserDao;
import com.sunbeam.entities.User;

@Service //B.L holder spring bean
@Transactional//for auto management of txs
public class UserServiceImpl implements UserService {
	// depcy - dao layer i/f
	@Autowired
	private UserDao userDao;

	@Override
	public User authenticateUser(String email, String password) {
		// TODO Auto-generated method stub
		return userDao.findByEmailAndPassword(email, password)
				.orElseThrow();
				
	}

}
