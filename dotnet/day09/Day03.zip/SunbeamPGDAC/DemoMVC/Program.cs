using DemoMVC.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;

namespace DemoMVC
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            //builder.Services.AddScoped(typeof(ISpellChecker), typeof(EnglishSpellChecker));

            //builder.Services.AddScoped(typeof(ISpellChecker), typeof(HindiSpellChecker));


            var app = builder.Build();

         
            app.UseStaticFiles();

            app.UseRouting();

            //app.MapControllerRoute(
            //  name: "MyPattern",
            //  pattern: "{controller=Home}/{action=Index}/{id?}/{name?}");

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();

        }
    }

    public class MyControllerFactory : IControllerFactory
    {
        public object CreateController(ControllerContext context)
        {
            //Know the URL
            //context.HttpContext.Request.Path

            //Reflection based object creation happens in DefaultControllerFactory

            return null;
        }

        public void ReleaseController(ControllerContext context, object controller)
        {
            throw new NotImplementedException();
        }
    }
}
