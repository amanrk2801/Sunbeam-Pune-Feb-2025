package com.myswiggy.entities;

public enum UserRole {
	CUSTOMER, ADMIN, DELIVERY_PERSON
}
