package com.sunbeam.dao;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sunbeam.entities.Address;
import com.sunbeam.entities.User;

public class AddressDaoImpl implements AddressDao {

	@Override
	public String assignUserAddress(Long userId, Address adr) {
		String mesg = "address linking failed !!!!!";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			// 3. get user from its id
			User user = session.get(User.class, userId);
			// 4. null checking
			if (user != null) {
				// user - persistent
				// 5. establish uni dir User --> Address
				user.setMyAddress(adr);//modifying state of persistent entity
			//	session.persist(adr);since added CascadeType.ALL - MERGE
				mesg="address assigned to user...";
			}
			tx.commit();//DML - insert - addess , update - users
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw exc to the caller
			throw e;
		}

		return mesg;
	}

}
