﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using DemoDatabase1.Model;
using Microsoft.Data.SqlClient;

namespace DemoDatabase1.DAL
{
    public class EMPOps
    {
        public List<Emp> GetEmps()
        {
            string connectionDetails =
                "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=TEJATEJA;Integrated Security=True;";

            SqlConnection connection = new SqlConnection(connectionDetails);
            connection.Open();

            SqlCommand command =
                new SqlCommand("select * from Emp", connection);

            SqlDataReader reader = command.ExecuteReader();

            List<Emp> empList = new List<Emp>();

            while (reader.Read())
            {
                Emp emp = new Emp();
                emp.No = Convert.ToInt32(reader["No"]);
                emp.Name = reader["Name"].ToString();
                emp.Address = reader["Address"].ToString();

                empList.Add(emp);
            }

            connection.Close();
            return empList; 
        }
        public int AddEmp(Emp emp)
        {
            string queryTextFormat = "insert into Emp(Name, Address) values('{0}','{1}')";

            string queryText = string.Format(queryTextFormat, emp.Name, emp.Address);

            string connectionDetails =
                "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=TEJATEJA;Integrated Security=True;";

            SqlConnection connection = new SqlConnection(connectionDetails);
            connection.Open();


            SqlCommand command =
                new SqlCommand(queryText, connection);

            int rowsAffected = command.ExecuteNonQuery();

            connection.Close();
            return rowsAffected;
        }
        public int UpdateEmp(Emp emp)
        {

            string queryTextFormat = "update Emp set Name = '{1}', Address= '{2}' where No = {0}";

            string queryText = string.Format(queryTextFormat, emp.No, emp.Name, emp.Address);

            string connectionDetails =
                "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=TEJATEJA;Integrated Security=True;";

            SqlConnection connection = new SqlConnection(connectionDetails);
            connection.Open();


            SqlCommand command =
                new SqlCommand(queryText, connection);

            int rowsAffected = command.ExecuteNonQuery();

            connection.Close();
            return rowsAffected;
        }
        public int RemoveEmp(int No)
        {
            string queryTextFormat = "delete from Emp where No = {0}";

            string queryText = string.Format(queryTextFormat, No);

            string connectionDetails =
                "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=TEJATEJA;Integrated Security=True;";

            SqlConnection connection = new SqlConnection(connectionDetails);
            connection.Open();


            SqlCommand command =
                new SqlCommand(queryText, connection);

            int rowsAffected = command.ExecuteNonQuery();

            connection.Close();

            return rowsAffected;
        }
    }
}
