package com.app.pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.entities.Student;

/**
 * Servlet implementation class ProcessFormServlet
 */
@WebServlet("/result")
public class AdmissionResult extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// 1 get student details from request scoped attribute
			Student myStudent = (Student) request.getAttribute("student_dtls");
			pw.print("<h5>Hello ," + myStudent.getFirstName() + " " + myStudent.getLastName() + "</h5>");
			if (myStudent.isAdmissionStatus()) {
				pw.print(
						"<h5>Congratulations !! You are admitted in Course " + myStudent.getSelectedCourse() + "</h5>");
			} else
				pw.print("<h5>Sorry !! You can't be  admitted in Course " + myStudent.getSelectedCourse() + "</h5>");

		}
	}

}
