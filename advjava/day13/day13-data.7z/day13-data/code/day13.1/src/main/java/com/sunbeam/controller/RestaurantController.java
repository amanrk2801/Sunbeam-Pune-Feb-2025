package com.sunbeam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sunbeam.entities.Restaurant;
import com.sunbeam.service.RestaurantService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/restaurants")
public class RestaurantController {
	//depcy
	@Autowired
	private RestaurantService restaurantService;
	
 public RestaurantController() {
	System.out.println("in ctor "+getClass());
}
 /*  Request hadnling method
	 * URL - http://host:port/ctx_path/restaurants/list
	 * Method - GET
	 * Payload - none
	 * Resp - dyn resp - list of restaurants
	 */
     @GetMapping("/list")
     public String listAllRestaurants(Model map) {
    	 System.out.println("in list restaurants "+map);//{}
    	 //add result under model attribute
    	 map.addAttribute("restaurant_list", restaurantService.getAllRestaurants());
    	 return "restaurants/list"; //AVN - /WEB-INF/views/restaurants/list.jsp
     }
     /*  Request handling method
 	 * URL - http://host:port/ctx_path/restaurants/delete?id=....
 	 * Method - GET
 	 * Payload - request parameter  - restaurant id
 	 * To perform data binding between req param -> method argument
 	 * use @RequestParam - method arg level as dependency
 	 * SC performs data binding + conversion
 	 * 
 	 * 
 	 * Resp - dyn resp - list of restaurants
 	 */
     @GetMapping("/delete")
     public String deleteRestaurantDetails(@RequestParam Long id,
    		RedirectAttributes flashMap) {
    	 System.out.println("in delete details "+id);
    	 //invoke service layer method n store the mesg under session scope
    	flashMap.addFlashAttribute("status",
    			 restaurantService.deleteRestaurantDetail(id));
    	 //redirect the clnt to list page , in the next request
    	 return "redirect:/restaurants/list";
     }
     /*
      * URL - http://host:post/ctx_path/restaurants/update?id=...
Method - GET
Payload - request param - restaurantId
Action - Render Update form (pre populated)
restaurant id - readonly
Resp - Render restaurant details update form to the client

      */
     @GetMapping("/update")
     public String showUpdateForm(@RequestParam Long id,Model map) {
    	 System.out.println("in show update form "+id);
    	 //invoke service layer method - to fetch restaurnat details by id
    	 map.addAttribute("restaurant_details",
    			 restaurantService.getRestaurantDetails(id));
    	 return "restaurants/update";//AVN - /WEB-INF/views/restaurants/update.jsp
    	 }
     /*
      * URL - http://host:post/ctx_path/restaurants/update?id=...
Method - POST
Payload - request param - restaurantId + request body - restaurant details
Action - Process Update form 

Resp - update details -> redirect to list.jsp

      */
     @PostMapping("/update")
     public String processUpdateForm(@RequestParam Long id, 
    		 @ModelAttribute(name="restaurant_details") Restaurant restaurant,
    		 RedirectAttributes flashMap)
     {
    	 System.out.println("in process update form "+id +" "+restaurant);
    	 //invoke service layer method
    	 flashMap.addFlashAttribute("status",
    			 restaurantService.updateDetails(id,restaurant));
    	 return "redirect:/restaurants/list";
     }
     
     
}
