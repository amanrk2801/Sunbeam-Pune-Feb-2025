package com.sunbeam.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeam.dto.AuthRequest;
import com.sunbeam.service.UserService;

import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/users")
@AllArgsConstructor
public class UserController {
	//depcy
	private final UserService userService;
	/*
	 * User sign in
URL - http://host:port/users/signin
Method - POST
Payload - Auth Request DTO (email ,pwd)
error resp - ApiResp dto - SC 401 , mesg - login failed
success resp - UseResp dto - with details
	 */
	@PostMapping("/signin")
	public ResponseEntity<?> userSignIn(@RequestBody AuthRequest dto) {
		return ResponseEntity.ok(userService.authenticate(dto));
	}
	

}
