package com.sunbeam.dao;

import com.sunbeam.entities.Restaurant;

public interface RestaurantDao {
String addRestaurant(Restaurant newRestaurant);
}
