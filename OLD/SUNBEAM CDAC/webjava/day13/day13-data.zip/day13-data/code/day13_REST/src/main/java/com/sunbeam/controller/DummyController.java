package com.sunbeam.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeam.entities.Category;

@RestController // =@Controller at the class level + @ResponeBody -ret type of all req handling
				// method
@RequestMapping("/dummy")
public class DummyController {
	public DummyController() {
		System.out.println("in ctor " + getClass());
	}

	// ret list of numbers
	@GetMapping
	public List<Double> getNumbers() {
		System.out.println("in get nums");
		return List.of(1.0, 2.6, 3.6, 4.56, 5.123);
	}
}
