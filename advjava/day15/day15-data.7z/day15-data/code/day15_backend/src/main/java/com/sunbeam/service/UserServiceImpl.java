package com.sunbeam.service;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeam.custom_exceptions.AuthenticationException;
import com.sunbeam.dao.UserDao;
import com.sunbeam.dto.AuthRequest;
import com.sunbeam.dto.AuthRespDTO;
import com.sunbeam.entities.User;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class UserServiceImpl implements UserService {
	//depcy
	private final UserDao userDao;
	private ModelMapper mapper;

	@Override
	public AuthRespDTO authenticate(AuthRequest dto) {
		//invoke dao's method
		User entity = userDao.
		findByEmailAndPassword(dto.getEmail(), dto.getPassword())
		.orElseThrow(() -> new AuthenticationException("Invalid login !!!!!"));
		//map entity -> dto
		return mapper.map(entity, AuthRespDTO.class);
	}

}
