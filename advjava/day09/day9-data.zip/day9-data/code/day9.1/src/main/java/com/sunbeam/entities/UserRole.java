package com.sunbeam.entities;


public enum UserRole {
	CUSTOMER, MANAGER, ADMIN
}
