package com.sunbeam.entities;

import java.time.LocalDate;
import javax.persistence.*;

/*
 * id (Long) , firstName , lastName , 
 * joinDate (LocalDate) , salary , email , 
 * password, employmentType (enum)
 */
@Entity //mandatory
@Table(name = "employees")
public class Employee {
	@Id // PK
	// auto id generation with auto_increment
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long empId;// MUST be Serializable
	@Column(name = "first_name", length = 20)
	private String firstName;
	@Column(name = "last_name", length = 20)
	private String lastName;
	@Column(length = 25, unique = true)
	private String email;
	// not null
	@Column(length = 20, nullable = false)
	private String password;
	@Column(name = "join_date")
	private LocalDate joinDate;
	private double salary;
	@Enumerated(EnumType.STRING) 
	// create col - varchar -to store enum constant name
	@Column(name="emp_type",length = 20)
	private EmploymentType empType;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(String firstName, String lastName, String email, String password, LocalDate joinDate, double salary,
			EmploymentType empType) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.joinDate = joinDate;
		this.salary = salary;
		this.empType = empType;
	}

	// all getters n setter
	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDate getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public EmploymentType getEmpType() {
		return empType;
	}

	public void setEmpType(EmploymentType empType) {
		this.empType = empType;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", joinDate=" + joinDate + ", salary=" + salary + ", empType=" + empType + "]";
	}

}
