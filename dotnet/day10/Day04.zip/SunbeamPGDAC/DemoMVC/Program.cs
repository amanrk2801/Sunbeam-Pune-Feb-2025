using DemoMVC.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;

namespace DemoMVC
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();
            builder.Services.AddSession();
            builder.Services.AddCors((services) => {

                services.AddPolicy("policy1", (policy) => {
                    policy.WithOrigins("sunbeaminfo.in")
                          .WithMethods("GET")
                          .WithHeaders("*");
                });

                services.AddPolicy("policy2", (policy) => {
                    policy.WithOrigins("bonaventuresystems.com")
                          .WithMethods("GET,POST")
                          .WithHeaders("Content-Type");
                });

                services.AddPolicy("policy3", (policy) => {
                    policy.WithOrigins("*")
                          .WithMethods("*")
                          .WithHeaders("*");
                });


            });
            //builder.Services.AddScoped(typeof(ISpellChecker), typeof(EnglishSpellChecker));

            //builder.Services.AddScoped(typeof(ISpellChecker), typeof(HindiSpellChecker));


            var app = builder.Build();
           
            app.UseSession();


            app.UseStaticFiles();

            app.UseRouting();
            app.UseCors();

            //app.MapControllerRoute(
            //  name: "MyPattern",
            //  pattern: "{controller=Home}/{action=Index}/{id?}/{name?}");

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();

        }
    }

    public class MyControllerFactory : IControllerFactory
    {
        public object CreateController(ControllerContext context)
        {
            //Know the URL
            //context.HttpContext.Request.Path

            //Reflection based object creation happens in DefaultControllerFactory

            return null;
        }

        public void ReleaseController(ControllerContext context, object controller)
        {
            throw new NotImplementedException();
        }
    }
}
