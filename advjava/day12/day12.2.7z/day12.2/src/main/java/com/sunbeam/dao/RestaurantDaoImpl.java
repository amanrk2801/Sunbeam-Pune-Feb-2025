package com.sunbeam.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.sunbeam.entities.Restaurant;

@Repository //class level anno to declare spring bean - DAL
public class RestaurantDaoImpl implements RestaurantDao {
	//depcy
	@Autowired //by type
	private SessionFactory factory;

	@Override
	public List<Restaurant> getAllRetaurants() {
		String jpql="select r from Restaurant r";
		return factory.getCurrentSession()
				.createQuery(jpql, Restaurant.class)
				.getResultList();
	}

}
