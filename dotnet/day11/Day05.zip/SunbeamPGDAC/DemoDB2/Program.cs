﻿using Microsoft.Data.SqlClient;

namespace DemoDB2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            #region Select Code
            //string conStr = "Server=(LocalDB)\\MSSQLLocalDB;database=TestDB;integrated security=true";

            //SqlConnection connection = new SqlConnection();
            //connection.ConnectionString = conStr;
            //connection.Open();

            //SqlCommand cmd = connection.CreateCommand();
            //cmd.CommandText = "select * from Emp1";

            //SqlDataReader reader =  cmd.ExecuteReader();

            //while (reader.Read())
            //{
            //    Console.WriteLine("Welcome " + reader["Name"].ToString() + " from " + reader["Address"]);
            //}

            //connection.Close();
            #endregion

            Console.WriteLine("Enter value of X e.g. 10");
            string xValue = Console.ReadLine();

            Console.WriteLine("Enter value of Y");
            string yValue = Console.ReadLine();

            int x = Convert.ToInt32(xValue);
            int y = Convert.ToInt32(yValue);

            int result = Maths.Add(x, y);

            Console.WriteLine("Sum is = " + result.ToString());

            Console.ReadLine();

        }
    }
}
