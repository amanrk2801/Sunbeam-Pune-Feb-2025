package com.sunbeam.service;

import com.sunbeam.dto.DataDto;

public interface RestClientService {
	DataDto getData(int id);
}
