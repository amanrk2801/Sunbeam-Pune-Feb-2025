package com.app.dao;

import com.app.entities.User;
import org.hibernate.*;
import static com.app.utils.HibernateUtils.getFactory;

import java.io.Serializable;

public class UserDaoImpl implements UserDao {

	@Override
	public String registerNewUser(User newUser) {
		String mesg="User registration failed !!!!!!!!";
		// 1. get Session from SessionFactory
		/*
		 * API of SF
		 * public Session getCurrentSession() throws HibernateException
		 */
		Session session=getFactory().getCurrentSession();
		Session session2=getFactory().getCurrentSession();
		System.out.println(session==session2);//t
		
		//2. Begin a Transaction
		/*
		 * Session API -
		 * public Transaction beginTransaction() throws HibernateException
		 */
		Transaction tx=session.beginTransaction();
		try  {
			/*
			 * Session API 
			 * public Serializable save(Object o)
			 * o - trasient entity ref.
			 * Rets Serializable ID associated with the persistent entity.
			 */
			Serializable userId = session.save(newUser);
			tx.commit();
			mesg="User registered with ID "+userId;
		} catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			//re throw the SAME exception to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public User getUserDetails(Long userId) {
		User user=null;
		//1. get Session from SF
		Session session=getFactory().getCurrentSession();
		//2. Begin tx
		Transaction tx=session.beginTransaction();
		try {
			user=session.get(User.class, userId);
			tx.commit();
		} catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return user;
	}
	

}
