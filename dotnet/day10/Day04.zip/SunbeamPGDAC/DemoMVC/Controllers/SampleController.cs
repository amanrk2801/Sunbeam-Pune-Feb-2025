﻿using DemoMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace DemoMVC.Controllers
{
    public class SampleController : BaseController
    {
        [HttpGet]
        public IActionResult Index()
        {
            Emp emp = new Emp() { No = 99, Name = "MahendraPathy", Address = "Chennai" };
            Book book = new Book() { ISBN = 9898, Title = "HMAD", Author = "MP" };
            string message = "Hello World!";

            //ViewData will require typecasting in View
            //Unwritten rule: Avoid type casting in View!!

            ViewData["MyMessage"] = message;
            ViewData["Title"] = "Welcome Home!";
            //ViewData["MyBook"] = book; 

            ViewBag.MyBook = book;

            return View(emp);
        }


        //public IActionResult AfterIndex(IFormCollection entireForm) 

        [HttpPost]
        public IActionResult Index(IFormCollection entireForm)
        {
            return null;
        }
    }
}
