﻿using Microsoft.AspNetCore.Mvc;
using DemoMVC.Filters;

namespace DemoMVC.Controllers
{
    [AuthFilter]
    [SBFilter]
    public abstract class BaseController : Controller
    {
      
    }
}
