﻿using Demo.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Demo.Filters;
namespace Demo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors(PolicyName = "policy3")]
    [AuthFilter]
    public class LoginController : ControllerBase
    {
        [HttpPost]
        public Reply Post([FromBody]SBUser user)
        {
            if (user.UserName == "mahesh" && user.Password == "mahesh@123")
            {
                return new Reply() { token = "1234" };
            }
            else
            {
                return new Reply() { token = null};
            }
        }

    }

    public class Reply
    {
        public string token { get; set; }
    }
}
