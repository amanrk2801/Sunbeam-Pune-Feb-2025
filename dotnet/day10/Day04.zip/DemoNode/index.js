const http = require('http');
const server = http.createServer((request, response)=>{
    if(request.url.includes("/home"))
    {
        response.write("U called Home");
        response.end();
    }
    else
    {
        response.write("U called Something else");
        response.end();
    }
});
server.listen(9999, ()=>{
    console.log("Server started at port no 9999")
});