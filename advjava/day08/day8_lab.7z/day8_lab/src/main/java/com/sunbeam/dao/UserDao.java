package com.sunbeam.dao;

import java.time.LocalDate;
import java.util.List;

import com.sunbeam.pojos.User;

public interface UserDao {

	User signIn(String email,String pwd) ;
	//sign up 
	// String signUp(User newUser) throws SE
	String signUp(User newUser) ;
	//add a method to change the voting status
	String updateVotingStatus(Long voterId) ;
	//update user details - password
	String updateUserDetails(Long userId,String newPassword,LocalDate dob) ;
	//delete user
	String deleteUser(Long userId) ;
	//list users 
	List<User> listUsers() ;
	//get user details
	User getUserDetails(Long userId) ;
	
}
