package com.sunbeam.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "categories")
public class Category extends BaseEntity {
	@Column(name = "category_name", 
			length = 30, unique = true)
	private String categoryName;
	private String description;
	// one -> many Category 1->* BlogPost
	@OneToMany(mappedBy = "blogCategory",
			cascade = CascadeType.ALL,orphanRemoval = true) // mandatory , otherwise MappingException !
	private List<BlogPost> posts = new ArrayList<>();

	public Category() {
		// TODO Auto-generated constructor stub
	}

	public Category(String categoryName, String description) {
		super();
		this.categoryName = categoryName;
		this.description = description;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<BlogPost> getPosts() {
		return posts;
	}

	public void setPosts(List<BlogPost> posts) {
		this.posts = posts;
	}

	// add helper method to establish a bi dir association between Category 1<--->*
	// BlogPost
	public void addBlogPost(BlogPost post) {
		//add post ref to the list
		this.posts.add(post);
		//assign category ref to the post
		post.setBlogCategory(this);
	}
	// add helper method to un -establish(de link) a bi dir association between Category 1<--->*
		// BlogPost
		public void removeBlogPost(BlogPost post) {
			this.posts.remove(post);
			post.setBlogCategory(null);
		}

	@Override
	public String toString() {
		return "Category ID " + getId() + " [categoryName=" + categoryName + ", description=" + description + "]";
	}

}
