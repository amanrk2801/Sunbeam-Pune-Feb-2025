package com.ecom.service;

import com.ecom.dto.AuthRequest;
import com.ecom.dto.UserDTO;

public interface UserService {
//user signin
	UserDTO authenticateUser(AuthRequest dto);
//signup
	UserDTO registerUser(UserDTO request);
}
