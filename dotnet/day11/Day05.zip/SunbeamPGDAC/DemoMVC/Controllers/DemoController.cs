﻿using Microsoft.AspNetCore.Mvc;
using DemoMVC.Filters;

namespace DemoMVC.Controllers
{
  
     //[SBFilter]
    public class DemoController : BaseController
    {

        //[SBFilter]
        public IActionResult Index()
        {
            ViewBag.Message = "Welcome Home!";

            return View();
        }
    }
}
