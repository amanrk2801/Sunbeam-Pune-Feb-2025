package com.ecom.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecom.custom_exceptions.ResourceNotFoundException;
import com.ecom.dto.ApiResponse;
import com.ecom.dto.CategoryDTO;
import com.ecom.dto.CategoryProductsDTO;
import com.ecom.dto.ProductDTO;
import com.ecom.entities.Category;
import com.ecom.entities.Product;
import com.ecom.repository.CategoryRepository;
import com.ecom.repository.ProductRepository;

import lombok.AllArgsConstructor;

@Service // represents a spring bean containing B.L
@Transactional // for automatic tx management
@AllArgsConstructor
public class CategoryServiceImpl implements CategoryService {
	
	private CategoryRepository categoryRepository;
	private ProductRepository productRepository;
	private ModelMapper mapper;

	@Override
	public List<CategoryDTO> getCategories() {
		// TODO Auto-generated method stub
	
		return categoryRepository.findAll().stream()
				.map(category -> mapper.map(category, CategoryDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public ApiResponse addNewCategory(CategoryDTO dto) {
		Category savedCategory = categoryRepository.save(mapper.map(dto, Category.class));
		// savedCatgory - PERSISTENT
		return new  ApiResponse("new category added with id=" + savedCategory.getId());
	}
	

	@Override
	public ApiResponse deleteCategory(Long categoryId) {
		// invoke dao's inherited method
		Category category = categoryRepository.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Category Id !!!!"));
		//soft delete - status : false
		category.setStatus(false);
		return new ApiResponse("Deleted Category with ID="+categoryId);

		
	}

	@Override
	
	public CategoryDTO getCategory(Long categoryId) {
		// TODO Auto-generated method stub
		Category entity = categoryRepository.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Category Id !!!!"));
		return mapper.map(entity, CategoryDTO.class);
	}

	@Override
	public ApiResponse updateCategory(Long categoryId, CategoryDTO category) {
		Category entity = categoryRepository.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Category Id !!!!"));		
			// => valid id
		    mapper.map(category, entity);			
			return new ApiResponse( "Updated category !");		
	}

	@Override
	public CategoryProductsDTO getCategoryAndPosts(Long categoryId) {
		Category category = categoryRepository.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Category ID!!!"));
	
		List<Product> products = productRepository.findByCategoryId(categoryId);
		
		//map List<Product> -> List<DTO>
		List<ProductDTO> dtos = products.stream()
		.map(product -> mapper.map(product, ProductDTO.class))
		.collect(Collectors.toList());
		
		return new CategoryProductsDTO(category.getId(),category.getCategoryName(),
				category.getDescription(),dtos);
	}

}
