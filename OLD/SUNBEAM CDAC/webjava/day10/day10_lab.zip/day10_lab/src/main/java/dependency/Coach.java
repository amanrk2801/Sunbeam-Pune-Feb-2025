package dependency;

public interface Coach {

    String getDailyWorkout();
}
