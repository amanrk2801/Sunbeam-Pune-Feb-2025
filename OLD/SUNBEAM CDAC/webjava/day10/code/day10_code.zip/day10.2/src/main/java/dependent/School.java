package dependent;

public interface School {
	void manageAcademics();
	void organizeSportsEvent();
}
