package com.ecom.service;

import java.util.List;

import com.ecom.dto.ApiResponse;
import com.ecom.dto.CategoryDTO;
import com.ecom.dto.CategoryProductsDTO;
import com.ecom.entities.Category;

public interface CategoryService {
	List<CategoryDTO> getCategories();
	ApiResponse addNewCategory(CategoryDTO newCategory);
	ApiResponse deleteCategory(Long categoryId);
	CategoryDTO getCategory(Long categoryId);
	ApiResponse updateCategory(Long categoryId, CategoryDTO category);
	CategoryProductsDTO getCategoryAndPosts(Long categoryId);
}
