package com.app.pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.entities.Course;
import com.app.entities.Student;

/**
 * Servlet implementation class ProcessFormServlet
 */
@WebServlet("/process_admission")
public class ProcessFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			pw.print("<h5>from 1st page</h5>");
		pw.flush();
			// 1. get req params
			String firstName = request.getParameter("fn");
			String lastName = request.getParameter("ln");
			int examScore = Integer.parseInt(request.getParameter("score"));
			Course myCourse = Course.valueOf(request.getParameter("course").toUpperCase());
			// 2. create student object - wraaping the details
			Student student = new Student(firstName, lastName, examScore, myCourse);
			//3. check score
			if(examScore>myCourse.getMinScore())
				student.setAdmissionStatus(true);
			//4. save student details under suitable scope
			//min scope required for RD - request
			request.setAttribute("student_dtls", student);
			//5 Create RD to represent chain of 2 servlets
			RequestDispatcher rd=request.getRequestDispatcher("result");
			//6 include
			rd.include(request, response);
			/*
			 * WC - retains resp buffer
			 * Invokes (doGet -> doGet, doPost ->doPost)
			 * 1st page n last page in the chain , BOTH , can generate dyn resp
			 * control comes back then only actual resp is rendered.
			 */
			System.out.println("control came back....");		
		}//pw.close -> pw.flush (included contents) -> close stream
	}

}
