package com.sunbeam.pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;

import com.sunbeam.dao.CandidateDaoImpl;
import com.sunbeam.pojos.Candidate;
import com.sunbeam.pojos.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/admin_dashboard")
public class AdminPage extends HttpServlet {
	// doGet
	@Override
	public void doGet(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
		System.out.println("in admin page ");
		// 1. set resp cont type
		rs.setContentType("text/html");
		// 2. get PW : to send resp from servlet ---> web clnt
		try (PrintWriter pw = rs.getWriter()) {
			// get HttpSession
			HttpSession session = rq.getSession();
			// get user details from HttpSession
			User userDetails = (User) session.getAttribute("user_info");
			// get candidate dao from HttpSession
			CandidateDaoImpl dao = (CandidateDaoImpl)
					session.getAttribute("candidate_dao");
			// generate dyn contents
			pw.print("<h5>Welcome Admin!</h5>");
			pw.print("<h5> Hello , " + userDetails.getFirstName() + "</h5>");
			pw.print("<h5 align='center'>Top 2 Candidates</h5>");
			List<Candidate> top2Candidates = dao.getTop2Candidates();
			for (Candidate c : top2Candidates) {
				pw.print("<h5> Name " + c.getName() + " Party " + c.getPartyName() + " Votes " + c.getVotes() + "</h5>");
			}
			pw.print("<h5 align='center'>Partywise Votes </h5>");
			LinkedHashMap<String, Integer> map = dao.getPartywiseVotes();
			map.forEach((k, v) -> {
				pw.print("<h5> Party Name " + k + " Votes " + v + "</h5>");
			});
			pw.print("<h5> <a href='logout'>Log Me Out</a></h5>");
			

		} catch (Exception e) {
			throw new ServletException("err on do-get of " + getClass(), e);
		}
	}

}
