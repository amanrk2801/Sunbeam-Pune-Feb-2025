package com.sunbeam.dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sunbeam.entities.User;

public interface UserDao extends JpaRepository<User,Long>{
//	user signin
	Optional<User> findByEmailAndPassword(String em,String pass);
	//How to get list of users born in the range - begin n end date
     List<User> findByDobBetween(LocalDateTime start,LocalDate end);
	
}
