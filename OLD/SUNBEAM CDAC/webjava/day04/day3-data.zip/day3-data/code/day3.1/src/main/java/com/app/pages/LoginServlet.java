package com.app.pages;

import static com.app.utils.DBUtils.closeConnection;
import static com.app.utils.DBUtils.openConnection;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.CandidateDaoImpl;
import com.app.dao.UserDaoImpl;
import com.app.entities.User;

/**
 * Servlet implementation class LoginServlet
 */
/*
 * WC creates a map @ web app deployment time. Adds the entries per servlet key
 * - /login value -com.app.pages.LoginServlet
 */
//@WebServlet(value = "/login", loadOnStartup = 1)
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDaoImpl userDao;
	private CandidateDaoImpl candidateDao;
	private String url,userName,password;
	
//	public LoginServlet() {
//		System.out.println("in def ctor - cfg "+getServletConfig());
//		System.out.println("ctx - "+getServletContext());
//	}
	
//	public LoginServlet(String url, String userName, String password) {
//		super();
//		System.out.println("in parameterized ctor");
//		this.url = url;
//		this.userName = userName;
//		this.password = password;
//	}

	/**
	 * @see Servlet#init()
	 */
	/*
	 * Overriding / Implementing form of the method CAN NOT throw NEW or BROADER
	 * CHECKED exceptions
	 */
	
	@Override
	public void init() throws ServletException {
		try {
			System.out.println("in init");
			System.out.println("cfg "+getServletConfig());
			System.out.println("ctx - "+getServletContext());
			//get servlet config
			ServletConfig config=getServletConfig();
			//accessing init params
			String url=config.getInitParameter("db_url");
			String userName=config.getInitParameter("user_name");
			String password=config.getInitParameter("password");	
			// open connection
			openConnection(url,userName,password);
			userDao = new UserDaoImpl();
			candidateDao=new CandidateDaoImpl();
		} catch (Exception e) {
			System.out.println(e);
			/*
			 * Centralized exc handling in Servlets 1. catch the exception in Servlet class
			 * 2. re -throw the same exc to the caller (WC) by using ServletException API -
			 * public class ServletException(String mesg, Throwable rootCause)
			 */
			throw new ServletException("err in init of " + getClass(), e);
		}
	}

	

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			System.out.println("in destroy");
			userDao.cleanUp();
			candidateDao.cleanUp();
			closeConnection();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. set resp cont type for the clnt
		response.setContentType("text/html");
		// 2. get PW to send buffered text resp -> clnt
		try (PrintWriter pw = response.getWriter()) {
			// 3.read request parameters
			/*
			 * ServletRequest Methods String getParameter(String paramName) Rets value or
			 * null String[] getParameterValues(String paramName) Rets values or null
			 * 
			 */
			String email = request.getParameter("em");
			String pwd = request.getParameter("pass");
			// 4. invoke dao's method for authentication
			User user = userDao.signIn(email, pwd);
			// 5. valid or invalid login
			if (user == null) {
				// invalid , send retry link to the clnt
				pw.print("<h5>Invalid Login , " + "Please <a href='login.html'>Retry</a></h5>");

			} else {
				
			
				//6. get HttpSession from WC
				HttpSession session=request.getSession();
				// valid login 
				pw.print("<h5>Valid Login</h5>");
		//		pw.flush();
				System.out.println("session "+session.getClass());//F.Q imple class name - server specific
				System.out.println("session new "+session.isNew());//true
				System.out.println("session id from login page "+session.getId());
				//7. save user details under HttpSession
				session.setAttribute("user_info", user);
				//8 , store daos under session scope
				session.setAttribute("user_dao", userDao);
				session.setAttribute("candidate_dao", candidateDao);
				//--> continue to role based authorization
				if (user.getRole().equals("admin")) {
					// redirect the clnt to admin page
					/*
					 * API of HttpServletResponse public void sendRedirect(String redirectLoc)
					 * throws IOException
					 */
					response.sendRedirect("admin_page");
				} else {
					// voter - role
					if (user.isStatus()) {
						// voted alrdy !
						response.sendRedirect("logout_page");
					} else {
						//voter - not yet voted 
						response.sendRedirect("candidate_list");
						/*
						 * WC sends temp redirect resp to the clnt
						 * CLEARS/DISCARDS/EMPTIES resp buffer.
						 * SC 302 , Header - Location-candidate_list ,
						 * Set-Cookie -JSESSIONID-dsgadfg57567gfhgf
						 * Body : empty
						 * clnt browser - cookies enabled case -stores the cookie
						 * in cache
						 * clnt browser -> send redirect req
						 * URL -http://host:port/ctx_path/candidate_list
						 * Method - GET
						 * header -Cookie - JSESSIONID-dsgadfg57567gfhgf
						 * 
						 * 
						 */
					}
				}
			}

		} catch (Exception e) {
			// centralized exc handling
			throw new ServletException("err in servicing " + getClass(), e);
		}
	}

}
