﻿using Microsoft.Data.SqlClient;

namespace DemoDatabase
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Select Code
            //string connectionDetails =
            //    "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=TEJATEJA;Integrated Security=True;";

            //SqlConnection connection = new SqlConnection(connectionDetails);
            //connection.Open();

            //SqlCommand command = 
            //    new SqlCommand("select * from Emp", connection);

            //SqlDataReader reader =   command.ExecuteReader();

            //List<Emp> empList = new List<Emp>();    

            //while (reader.Read())
            //{
            //   Emp emp = new Emp();
            //   emp.No = Convert.ToInt32(reader["No"]);
            //   emp.Name = reader["Name"].ToString();
            //   emp.Address = reader["Address"].ToString();

            //    empList.Add(emp);
            //}

            //connection.Close();

            //foreach (var emp in empList)
            //{
            //    Console.WriteLine(emp.ToString());
            //}
            #endregion

            #region Insert Code

            //Console.WriteLine("Enter Name");
            //string Name = Console.ReadLine();

            //Console.WriteLine("Enter Address");
            //string Address = Console.ReadLine();

            //string queryTextFormat = "insert into Emp(Name, Address) values('{0}','{1}')";

            //string queryText = string.Format(queryTextFormat, Name, Address);

            //string connectionDetails =
            //    "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=TEJATEJA;Integrated Security=True;";

            //SqlConnection connection = new SqlConnection(connectionDetails);
            //connection.Open();


            //SqlCommand command =
            //    new SqlCommand(queryText, connection);

            //int rowsAffected = command.ExecuteNonQuery();

            //connection.Close();

            //Console.WriteLine("Rows affected = {0}", rowsAffected);

            #endregion

            #region Update Code

            //Console.WriteLine("Enter No To Update The Record:");
            //int No = Convert.ToInt32(Console.ReadLine());   

            //Console.WriteLine("Enter New Name");
            //string Name = Console.ReadLine();

            //Console.WriteLine("Enter New Address");
            //string Address = Console.ReadLine();

            //string queryTextFormat = "update Emp set Name = '{1}', Address= '{2}' where No = {0}";

            //string queryText = string.Format(queryTextFormat, No,Name, Address);

            //string connectionDetails =
            //    "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=TEJATEJA;Integrated Security=True;";

            //SqlConnection connection = new SqlConnection(connectionDetails);
            //connection.Open();


            //SqlCommand command =
            //    new SqlCommand(queryText, connection);

            //int rowsAffected = command.ExecuteNonQuery();

            //connection.Close();

            //Console.WriteLine("Rows affected = {0}", rowsAffected);

            #endregion

            #region Delete Code

            //Console.WriteLine("Enter No To Remove The Record:");
            //int No = Convert.ToInt32(Console.ReadLine());

            //string queryTextFormat = "delete from Emp where No = {0}";

            //string queryText = string.Format(queryTextFormat, No);

            //string connectionDetails =
            //    "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=TEJATEJA;Integrated Security=True;";

            //SqlConnection connection = new SqlConnection(connectionDetails);
            //connection.Open();


            //SqlCommand command =
            //    new SqlCommand(queryText, connection);

            //int rowsAffected = command.ExecuteNonQuery();

            //connection.Close();

            //Console.WriteLine("Rows affected = {0}", rowsAffected);

            #endregion

            Console.ReadLine();
        }
    }

    public class Emp
    {
        public int? No { get; set; }
        public string? Name { get; set; }
        public string? Address { get; set; }

        public override string ToString()
        {
            return string.Format("No = {0}, Name = {1}, Address = {2}", No, Name, Address);
        }
    }
}
