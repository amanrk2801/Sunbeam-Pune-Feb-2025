package com.sunbeam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeam.custom_exceptions.ResourceNotFoundException;
import com.sunbeam.dao.BlogPostDao;
import com.sunbeam.dao.CategoryDao;
import com.sunbeam.dao.TagDao;
import com.sunbeam.dao.UserDao;
import com.sunbeam.entities.BlogPost;
import com.sunbeam.entities.Tag;

@Service
@Transactional
public class BlogPostServiceImpl implements BlogPostService {
	@Autowired
	private BlogPostDao blogPostDao;
	
	@Autowired
	private CommentService commentService;
	
	@Autowired
	private TagDao tagDao;	

	@Override
	public List<BlogPost> getAllPosts() {
		// TODO Auto-generated method stub
		return blogPostDao.findAll();
	}
	
	@Override
	public BlogPost getBlogDetails(Long id) {
		// TODO Auto-generated method stub
		return blogPostDao.findById(id)
				.orElseThrow(() -> 
				new ResourceNotFoundException("Invalid Blog post ID !!"));
	}
	@Override
	public String deleteBlogPost(Long blogPostId) {
		// validate if id exists
		BlogPost post = blogPostDao.findById(blogPostId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Blog POst ID!!"));
		
			// => blog post exists
			// 1. delete all comments(child recs)
			String mesg = commentService.deleteComments(blogPostId);
			// delete recs in tag_post
			// get all tags associated with a blog post
			List<Tag> tags = tagDao.findTagsByPostId(blogPostId);
			tags.forEach(tag -> tag.getPosts().remove(post));
			//finally delete post (parent record)
			blogPostDao.delete(post);
			return "blog post deleted ";		
	}

	@Override
	public String createNewBlog(BlogPost post) {
//		// 1. get category from category id
//		Category category = categoryDao.findById(categoryId)
//				.orElseThrow(() -> new ResourceNotFoundException("Invalid category id !!!!"));
//		User blogger = userDao.findById(bloggerId)
//				.orElseThrow(() -> new ResourceNotFoundException("Invalid blogger id !!!!"));
//		// category, blogger : persistent
//		// establish E-R
//		// post *<--->1 catgeory
//		category.addBlogPost(post);
//		// blog post *---->1 user
//		post.setBlogger(blogger);
//		// => success
		/*
		 * Associations are already set in the handler layer.
		 */
		blogPostDao.save(post);
		return "new blog post added ";
	}
	@Override
	public String updateBlogContents(Long id, String content) {
		BlogPost blogPost = blogPostDao.findById(id)
		.orElseThrow(() -> 
		new ResourceNotFoundException("Invalid Blog post ID !!"));
		//blogPost - PERSISTENT
		blogPost.setContent(content);//modifying state of the persistent entity
		
		return "Updated blog post cotents...";
	}
	/*
	 * returning from Transaction method
	 * Spring supplied Tx mgr bean -chks for run time exc
	 * yes - session.close
	 * no - session.flush-> dirty chking -> update -> session.close
	 */


}
