﻿namespace DemoMVC.Helpers
{
    public class Logger
    {
        private static Logger logger = new Logger();
        private Logger()
        {
            
        }

        public static Logger CurrentLogger
        {
            get { return logger; }
        }

        public void Log(string message)
        {
            string filePath = "C:\\DACDOTNET\\SunbeamPGDAC\\Log.txt";

            FileStream fileStream = null;

            if (File.Exists(filePath))
            {
                fileStream = new FileStream(filePath, FileMode.Append, FileAccess.Write);
            }
            else
            {
                fileStream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
            }
    
            StreamWriter writer = new StreamWriter(fileStream);

            string msgFormat = "Logged at : {0} - {1}";
            string msg = string.Format(msgFormat, DateTime.Now.ToString(), message);

            writer.WriteLine(msg);

            writer.Close();
            fileStream.Close();

            writer = null;
            fileStream = null;
        }
    }
}
