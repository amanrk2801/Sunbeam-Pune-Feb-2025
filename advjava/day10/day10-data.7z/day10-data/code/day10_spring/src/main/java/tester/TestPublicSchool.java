package tester;

import com.sunbeam.dependency.MathsTeacher;
import com.sunbeam.dependent.PublicSchool;

public class TestPublicSchool {

	public static void main(String[] args) {
		PublicSchool publicSchool=new PublicSchool
				(new MathsTeacher());
		publicSchool.manageAcademics();

	}

}
