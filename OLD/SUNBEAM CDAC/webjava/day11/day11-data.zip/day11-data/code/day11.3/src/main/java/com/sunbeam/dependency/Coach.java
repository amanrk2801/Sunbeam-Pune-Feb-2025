package com.sunbeam.dependency;

public interface Coach {

    String getDailyWorkout();
}
