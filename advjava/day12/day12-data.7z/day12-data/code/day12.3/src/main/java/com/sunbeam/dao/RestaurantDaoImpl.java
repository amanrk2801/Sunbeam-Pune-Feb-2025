package com.sunbeam.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.sunbeam.entities.Restaurant;

import jakarta.persistence.EntityManager;

@Repository //class level anno to declare spring bean - DAL
public class RestaurantDaoImpl implements RestaurantDao {
	//depcy
	@Autowired //by type
	private EntityManager manager;

	@Override
	public List<Restaurant> getAllRetaurants() {
		String jpql="select r from Restaurant r";
		return manager
				.createQuery(jpql, Restaurant.class)
				.getResultList();
	}

}
