import React from 'react';
import ReactDOM from 'react-dom/client';
import Dashbard from './dashboard';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Dashbard></Dashbard>);
