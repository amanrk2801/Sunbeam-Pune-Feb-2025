package com.app.beans;
//dependent - Java Bean

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;

import com.app.dao.UserDaoImpl;
import com.app.entities.User;

public class UserBean {
//state - client's conversational state
	private String email;
	private String password;
	private String firstName;
	private String lastName;
	private String dob;// Java bean dev. has to parse string -> Date
	// dependency - Dao layer
	private UserDaoImpl userDao;
	// user details - under session scope(simply add it as the property of a java
	// bean)
	private User userDetails;
	// add a property for status message
	private String message;

	// def ctor
	public UserBean() throws SQLException {
		// create depcy (dependency)
		userDao = new UserDaoImpl();
		System.out.println("user bean created");
	}

	// setters n getters
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserDaoImpl getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDaoImpl userDao) {
		this.userDao = userDao;
	}

	public User getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(User userDetails) {
		this.userDetails = userDetails;
	}

	public String getMessage() {
		return message;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	// Business logic method for user authentication
	public String authenticateUser() throws SQLException {
		System.out.println("in auth user " + email + " " + password);
		// invoke dao's method
		userDetails = userDao.signIn(email, password);
		if (userDetails == null) {
			// invalid login
			message = "Invalid email or password , Please retry !!!!";
			return "login";// JB rets -> JSP -> dynamic navigational outcome !
		}
		// => valid login
		message = "Login Successful!";
		if (userDetails.getRole().equals("admin")) {
			return "admin_page";
		}
		// => voter
		if (userDetails.isStatus())
			return "logout";
		// => not yet voted
		return "candidate_list";

	}

	// add B.L method for validation n registration of voter
	public String validateAndRegisterVoter() throws SQLException {
		System.out.println("in reg " + firstName + " " + dob);
		// validate age
		LocalDate dateOfBirth = LocalDate.parse(dob);
		int age = Period.between(dateOfBirth, LocalDate.now()).getYears();
		if (age > 21) {
			// create voter instance : transient(not yet persistent!)
			User voter = new User(firstName, lastName, email, password, dateOfBirth);
			// invoke dao's method
			return userDao.voterRegistration(voter);
		} else
			return "Voter registration failed - Invalid Age !!!";

	}

}
