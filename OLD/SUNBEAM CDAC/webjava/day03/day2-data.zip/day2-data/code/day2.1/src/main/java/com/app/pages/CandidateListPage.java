package com.app.pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdminPageServlet
 */
@WebServlet("/candidate_list")
public class CandidateListPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//1. set content type
		response.setContentType("text/html");
		//2. get PW
		try (PrintWriter pw=response.getWriter()) {
	//		pw.print("<h5>Welcome Voter  ! "+request.getParameter("em")+"</h5>");
			pw.print("<h5>Welcome Voter  ! </h5>");
			//3. Get cookie/s from request header
			Cookie[] cookies=request.getCookies();
			if(cookies != null)
			{
				//cookie present
				for(Cookie c : cookies)
					if(c.getName().equals("user_details"))
						pw.print("<h5> User details from the cookie"+c.getValue()+"</h5>");
			}
			else pw.print("<h5> No cookies , Session Tracking failed !!!!!!!!</h5>");
		
		}
	}

}
