package com.sunbeam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeam.custom_exceptions.ApiException;
import com.sunbeam.custom_exceptions.ResourceNotFoundException;
import com.sunbeam.dao.CategoryDao;
import com.sunbeam.entities.Category;

@Service
@Transactional
public class CategoryServiceImpl implements CategoryService {
	// depcy - dao
	@Autowired
	private CategoryDao categoryDao;

	@Override
	public List<Category> getAllCategories() {
		// TODO Auto-generated method stub
		return categoryDao.findAll();
	}

	@Override
	public Category saveCategoryDetails(Category category) {
		// validate if category already exists by the supplied name : B.L validation
		if (categoryDao.existsByCategoryName(category.getCategoryName()))
			throw new ApiException("Category name duplicate !!!!!");
		// => category name - unique
		return categoryDao.save(category);
	}// session.flush-> insert -> close

	@Override
	public Category getCategoryDetails(Long categoryId) {
		// TODO Auto-generated method stub
		return categoryDao.findById(categoryId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Category Id !!!!"));
	}

	@Override
	public String updateCategoryDetails(Long categoryId, Category category) {
		// validate if category exists !
		if (categoryDao.existsById(categoryId)) {
			// => exists
			Category persistentCategory = categoryDao.save(category);
			return "Category updated.....";
		}
		throw new ResourceNotFoundException("Invalid Category ID !!!!!!!!");
	}

	@Override
	public String deleteCategoryDetails(Long categoryId) {
		if (categoryDao.existsById(categoryId)) {
			categoryDao.deleteById(categoryId);
			return "deleted category !!!";
		}
		throw new ResourceNotFoundException("Invalid category id !!!");
	}

}
