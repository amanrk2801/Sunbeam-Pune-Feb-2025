package com.app.pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.CandidateDaoImpl;
import com.app.dao.UserDaoImpl;
import com.app.entities.User;

/**
 * Servlet implementation class AdminPageServlet
 */
@WebServlet("/logout_page")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. set content type
		response.setContentType("text/html");
		// get PW
		try (PrintWriter pw = response.getWriter()) {
			//get session from WC
			HttpSession session=request.getSession();
			// To DO - get voter name from HttpSession n greeting !
			pw.print("<h5>You have already voted!!!!!</h5>");
			//invalidate Http Session
			session.invalidate();
			pw.print("<h5> You have logged out...</h5>");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 0 set cont type n get PW
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {

			// 1. get Session from WC
			HttpSession session = request.getSession();
			// 2. get user details , daos
			User voter = (User) session.getAttribute("user_info");
			UserDaoImpl userDao = (UserDaoImpl) session.getAttribute("user_dao");
			CandidateDaoImpl candidateDao = (CandidateDaoImpl) session.getAttribute("candidate_dao");
			// 3 add greeting mesg for the voter
			pw.print("<h5> Hello , " + voter.getFirstName() + " " + voter.getLastName() + " </h5>");
			// 4. change the voting status
			String votingStatus = userDao.updateVotingStatus(voter.getUserId());
			pw.print("<h6>" + votingStatus + "</h6>");
			// 5. increment candidate's votes
			int candidateId = Integer.parseInt(request.getParameter("cid"));
			pw.print("<h6>" + candidateDao.updateVotes(candidateId) + "</h6>");
			//invalidate Http Session
			session.invalidate();
			pw.print("<h5> You have logged out...</h5>");
		} catch (Exception e) {
			throw new ServletException("err in do-post -" + getClass(), e);
		}

	}

}
