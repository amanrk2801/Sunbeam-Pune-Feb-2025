package com.sunbeam.tester;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

//import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.SessionFactory;

import com.sunbeam.dao.UserDao;
import com.sunbeam.dao.UserDaoImpl;
import com.sunbeam.entities.UserRole;

public class RestoreImage {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); 
				Scanner sc = new Scanner(System.in)) // SF -> DBCP
		{
			UserDao dao = new UserDaoImpl();
			System.out.println("Enter image file name to restore Blob from DB");
			String file=sc.nextLine();
			System.out.println("Enter user email");			
			// invoker dao's method
			System.out.println(dao.restoreImage(file,sc.next()));

		} // JVM - sc.close() , sf.close() => cleaning up of DBCP
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
