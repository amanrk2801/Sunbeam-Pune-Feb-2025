package com.sunbeam.dependent;

import java.util.Arrays;

import com.sunbeam.dependency.Coach;
import com.sunbeam.dependency.Teacher;

public class PublicSchool implements School {
	private Teacher[] subjectTeachers;
	private Coach[] sportsCoaches;

	public PublicSchool(Teacher[] subjectTeachers, Coach[] sportsCoaches) {
		this.subjectTeachers = subjectTeachers;
		this.sportsCoaches = sportsCoaches;
		System.out.println("in ctor of " + getClass() + " " + subjectTeachers + " " + sportsCoaches);
	}

	// B.L
	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		Arrays.stream(subjectTeachers) // Stream<Teacher>
				.forEach(Teacher::teach); // teacher -> teacher.teach()
	}

	// B.L - sports event
	@Override
	public void organizeSportsEvent() {
		System.out.println("Organizing sports event ....");
		// System.out.println(sportsCoach.getDailyWorkout());
		Arrays.stream(sportsCoaches) // Stream<Coach>
				.forEach(coach -> System.out.println(coach.getDailyWorkout()));

	}

	// custom init method
	public void anyInit() {
		System.out.println("in init of " + getClass() + " depcy " + subjectTeachers + " depcy " + sportsCoaches);// not
																													// null
	}

	// custom destroy method
	public void anyDestroy() {
		System.out.println("in destroy of " + getClass() + " depcy " + subjectTeachers + " depcy " + sportsCoaches);// not
																													// null
	}

}
