import { useEffect, useState } from "react";
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import axios from "axios";

function Dashboard() 
{
    //var url = "http://localhost:5269/api/emps";
    var url = "https://sunbeamdac-cxhxc8gfbbehehgq.centralus-01.azurewebsites.net/api/emps";
    const [message, setMessage] = useState("");
    const [emps, setEmps] = useState([]);
    const [emp, setEmp] = useState({No : 0, Name : "", Address: ""});

    const getData = ()=>{
        axios.get(url).then((result)=>{
            setEmps(result.data);
        })
    }

    useEffect(()=>{
        debugger;
        getData();
    }, []);

    useEffect(()=>{
        if(message!="")
        {
            setTimeout(() => {
                setMessage("");
            }, 3000);
        }
    }, [message]);

    const OnTextChange =(args)=>
    {
        debugger;
        var copyOfEmp = {...emp};
        copyOfEmp[args.target.name] = args.target.value;
        setEmp(copyOfEmp);
    }

    const addRecord = ()=>{
        axios.post(url, emp).then((result)=>{
            if(result.status == 200)
            {
                setMessage("Record Added!")
                setEmp({No : 0, Name : "", Address: ""});
                getData();
            }
           
        })
    }

    const updateRecord = ()=>
       {
        var modifiedUrl = url + "/" + emp.No;

        axios.put(modifiedUrl, emp).then((result)=>{
            if(result.status == 200)
            {
                setMessage("Record Updated!")
                setEmp({No : 0, Name : "", Address: ""});
                getData();
            }
           
        })
    }

    const removeRecord = (no)=>
        {
         var modifiedUrl = url + "/" + no;
 
         axios.delete(modifiedUrl).then((result)=>{
             if(result.status == 200)
             {
                 setMessage("Record Removed!")
                 setEmp({No : 0, Name : "", Address: ""});
                 getData();
             }
            
         })
     }

    

    return (<div className="container" style={{margin: 100}}>

                <div className="table-responsive">
                <table className="table table-bordered">
                <tbody>
                    <tr>
                        <td colSpan={2}>
                            <input type="hidden" value={emp.No}/>
                        </td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td>
                            <input type="text" value={emp.Name} name="Name" onChange={OnTextChange}/>
                        </td>
                    </tr>

                    <tr>
                        <td>Address</td>
                        <td>
                            <input type="text" name="Address" value={emp.Address}  onChange={OnTextChange}/>
                        </td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                          <button className="btn btn-primary" onClick={addRecord}>Add Record</button> { "|" }
                          <button className="btn btn-success" onClick={updateRecord}>Update Record</button>
                        </td>
                    </tr>
                    <tr>
                        <td colSpan={2}>
                            <div className="alert alert-info">
                                {message}
                            </div>
                        </td>
                    </tr>
                </tbody>
                </table>
                </div>
                <hr></hr>
                <div className="table-responsive">
                    <table className="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                emps.map((emp)=>{
                                    return (<tr key={emp.no}>
                                                <td>{emp.no}</td>
                                                <td>{emp.name}</td>
                                                <td>{emp.address}</td>
                                                <td>
                                                    <button className="btn btn-warning" onClick={()=>{
                                                        setEmp({No :emp.no, 
                                                                Name : emp.name, Address: emp.address});
                                                    }}>Edit</button>
                                                </td>

                                                <td>
                                                    <button className="btn btn-danger" onClick={()=>{
                                                        removeRecord(emp.no);
                                                    }}>Delete</button>
                                                </td>
                                            </tr>)
                                })
                            }
                        </tbody>
                    </table>
                </div>
            </div>);
}

export default Dashboard;