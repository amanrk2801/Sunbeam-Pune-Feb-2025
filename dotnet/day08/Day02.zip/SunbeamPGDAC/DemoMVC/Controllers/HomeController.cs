using DemoMVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DemoMVC.Controllers
{
    public class HomeController : Controller
    {
        public HomeController(IEnumerable<ISpellChecker> checkers)
        {
            
        }
        public IActionResult Index()
        {
            return View();
        }
    }


    public interface ISpellChecker
    {
        void Check();
    }

    public class EnglishSpellChecker : ISpellChecker
    {
        public void Check()
        {
           //Some code here
        }
    }

    public class HindiSpellChecker : ISpellChecker
    {
        public void Check()
        {
            //Some code here
        }
    }
}
