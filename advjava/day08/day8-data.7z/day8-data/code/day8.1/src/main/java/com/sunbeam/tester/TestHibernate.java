package com.sunbeam.tester;

import static com.sunbeam.utils.HibernateUtils.getFactory;

//import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.SessionFactory;

public class TestHibernate {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory()) //SF -> DBCP
		{
			System.out.println("hibernate up n running...."+sf);
		}  //JVM - sf.close() => cleaning up of DBCP
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
