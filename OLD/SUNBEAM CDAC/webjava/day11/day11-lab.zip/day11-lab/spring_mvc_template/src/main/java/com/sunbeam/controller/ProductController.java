package com.sunbeam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/operation")
public class ProductController {
	public ProductController() {
		System.out.println("in ctor "+getClass());
	}
	//URL - http://host:port/ctx_path/operation/product
	//,method=GET
	//render result = 123*345
	@GetMapping("/product")
	public String multiplyNumbers(Model modelMap,
			@RequestParam int num1,@RequestParam int num2) {
		System.out.println("in mult "+modelMap);//{}
		//add attribute - under model map
		//API - public Model addAttribute(String nm,Object val)
		modelMap.addAttribute("result",num1*num2);
		return "/operation/product_result";
		//AVN - /WEB-INF/views/operation/product_result.jsp
	}

}
