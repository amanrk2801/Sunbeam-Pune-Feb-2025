package com.sunbeam.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeam.dto.ApiResponse;
import com.sunbeam.entities.Restaurant;
import com.sunbeam.service.RestaurantService;

import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;

@RestController // = @Controller : class level +
//@ResponseBody - ret types of all req handling methods
@RequestMapping("/restaurants")
@CrossOrigin(origins = "http://localhost:3000")
@AllArgsConstructor
public class RestaurantController {
	
	private final RestaurantService restaurantService;

	/*
	 * Request handling method (REST API end point) URL -
	 * http://host:port/restaurants/ 
	 * Method - GET 
	 * Payload - none 
	 * Resp - in case of empty list - SC204 (NO_CONTENT) 
	 * o.w SC 200 + list of restaurants -> JSON []
	 */
	@GetMapping
	public  ResponseEntity<?> listAvailableRestaurants() {
		System.out.println("in list");
		List<Restaurant> restaurants 
		= restaurantService.getAllRestaurants();
		if(restaurants.isEmpty())
			 return ResponseEntity
					 .status(HttpStatus.NO_CONTENT).build();
		//=> list non empty		
		return ResponseEntity.ok(restaurants);
	}

	/*
	 * Request handling method (REST API end point) 
	 * - desc - Add new restaurant 
	 * URL -http://host:port/restaurants 
	 * Method - POST 
	 * Payload -JSON representation of restaurant 
	 * Resp - in case failure (dup restaurant name) - ApiResp DTO
	 *  - containing err mesg + SC 400(BAD_REQUEST)
	 *  success - SC 201 + ApiResp - success mesg
	 */
	@PostMapping
	@Operation(description = "Add New Resaturant")
	public ResponseEntity<?> addNewRestaurant(@RequestBody 
			Restaurant newRestaurant) {
		System.out.println("in add " + newRestaurant);
		try {
		// call service method
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(restaurantService
						.addNewRestaurant(newRestaurant));
		} catch (RuntimeException e) {
			return ResponseEntity.status(HttpStatus.CONFLICT)
					.body(new ApiResponse(e.getMessage()));
		}
	}

	/*
	 * REST API end point - desc -soft delete restaurant details URL
	 * -http://host:port/restaurants/{restaurantId} Method - DELETE Payload - none
	 * Resp - String
	 */
	@DeleteMapping("/{restaurantId}") // =@RequestMapping(method=DELETE)
	public String deleteDetails(@PathVariable /* (name="restaurantId") */ Long restaurantId) {
		System.out.println("in delete " + restaurantId);
		return restaurantService.deleteRestaurantDetail(restaurantId);
	}

	/*
	 * REST API end point - desc -get restaurant details by id 
	 * URL
	 * -http://host:port/restaurants/{restaurantId} 
	 * Method - GET 
	 * Payload - none 
	 * successful Resp - SC 200 +Restaurant -> JSON
	 * error resp - SC 404 + Apiresp (err mesg)
	 */
	@GetMapping("/{restaurantId}")
	// swagger annotation
	@Operation(description = "Get restaurant details by ID")
	public ResponseEntity<?> getRestaurantDetails(@PathVariable Long restaurantId) {
		System.out.println("in get details " + restaurantId);
		try {
		return ResponseEntity.ok(
				restaurantService.getRestaurantDetails(restaurantId));
		} catch (RuntimeException e) {
			return ResponseEntity
					.status(HttpStatus.NOT_FOUND)
					.body(new ApiResponse(e.getMessage()));
		}
	}
	/*
	 * REST API end point - 
	 * desc -update restaurant details by id
	 *  URL -http://host:port/restaurants/{restaurantId} 
	 *  Method - PUT 
	 *  Payload - JSON representation of Restaurant
	 *  Resp - string	   	 
	 */
	@PutMapping("/{restaurantId}")
	@Operation(description = "Complete Update restaurant details")
	public String updateDetails(@PathVariable Long restaurantId,@RequestBody Restaurant restaurant ) {
		System.out.println("in update "+restaurantId+" "+restaurant);
		return restaurantService.updateDetails(restaurantId, restaurant);
	}
	

}
