package com.app.entities;

public enum Course {
	JAVA(75), SPRING_BOOT(80), MERN(85), DBT(70);
	private int minScore;

	private Course(int minScore) {
		this.minScore = minScore;
	}

	public int getMinScore() {
		return minScore;
	}
	
	
	
}
