﻿using DemoMVC.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace DemoMVC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors(PolicyName = "policy3")]
    public class EmpsController : ControllerBase
    {
        SBDBContext context = new SBDBContext();

        [HttpGet]
        public IEnumerable<Emp> Get()
        {
            //  return context.Emps.ToList();
            List<Emp> emps = new List<Emp>() {
             new Emp{ No = 11, Name = "Mahesh", Address = "Pune" },
             new Emp { No = 12, Name = "Nilesh", Address = "Panji" },
             new Emp{ No = 13, Name = "Amit", Address = "Mumbai" },
             new Emp{ No = 14, Name = "Chetan", Address = "Chennai" }
        };
            return emps;
        }

        [HttpGet("{id}")]
        public Emp Get(int id)
        {
            return context.Emps.Find(id);
        }

        [HttpPost]
        public void Post([FromBody] Emp emp)
        {
            context.Emps.Add(emp);
            context.SaveChanges();
        }

        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Emp empUpdated)
        {
            var emp = context.Emps.Find(id);
            emp.Name = empUpdated.Name;
            emp.Address = empUpdated.Address;
            context.SaveChanges();
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var emp = context.Emps.Find(id);
            context.Emps.Remove(emp);
            context.SaveChanges();
        }
    }
}
