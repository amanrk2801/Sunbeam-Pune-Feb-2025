//package com.myswiggy.service;
//
//import org.modelmapper.ModelMapper;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.myswiggy.custom_exceptions.ResourceNotFoundException;
//import com.myswiggy.dao.AddressDao;
//import com.myswiggy.dao.UserDao;
//import com.myswiggy.dto.AddressReqDTO;
//import com.myswiggy.dto.ApiResponse;
//import com.myswiggy.entities.Address;
//import com.myswiggy.entities.User;
//
//import lombok.AllArgsConstructor;
//
//@Service
//@Transactional
//@AllArgsConstructor
//public class AddressServiceImpl implements AddressService {
//	//depcy 
//	private final AddressDao addressDao;
//	private final UserDao userDao;
//	private ModelMapper modelMapper;
//
//	@Override
//	public ApiResponse assignUserAddress(Long userId,
//			AddressReqDTO dto) {
//		// 1. get user from its id
//		User user=userDao.findById(userId)
//				.orElseThrow(() -> new ResourceNotFoundException("Invalid user id !!!!!"));
//		//user : persistent
//		//2. dto -> entity
//		Address addressEntity = modelMapper.map
//				(dto, Address.class);
//		//3. establish uni dir asso User 1---->1 Address
//		user.setMyAddress(addressEntity);
//		return new ApiResponse("address linked to user ....");
//	}
//
//}
