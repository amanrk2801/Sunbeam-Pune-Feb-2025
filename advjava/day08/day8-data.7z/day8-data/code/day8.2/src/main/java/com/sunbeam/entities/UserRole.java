package com.sunbeam.entities;

public enum UserRole {
	ADMIN, CUSTOMER, DELIVERY_PERSON
}
