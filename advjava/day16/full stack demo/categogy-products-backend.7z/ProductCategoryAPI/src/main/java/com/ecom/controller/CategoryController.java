package com.ecom.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.dto.CategoryDTO;
import com.ecom.entities.Category;
import com.ecom.service.CategoryService;

import lombok.AllArgsConstructor;

@RestController // =@Controller : class level + @ResponseBody : method ret type
@RequestMapping("/categories")
@CrossOrigin(origins = "http://localhost:3000")
@AllArgsConstructor
public class CategoryController {
	
	private CategoryService categoryService;	

	/*
	 * URL - http://host:port/categories 
	 * Method - GET 
	 * Payload - none 
	 * Response - List<CategoryDTO> 
	 */
	@GetMapping
	public ResponseEntity<?> getAllCategories() {
		System.out.println("in get all categories");
		// 200 : OK , 204 : No content
		List<CategoryDTO> categories = categoryService.getCategories();
		if (categories.isEmpty())
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		return ResponseEntity.ok(categories);
	}

	/*
	 * URL - http://host:port/categories 
	 * Method - POST 
	 * Payload - Category DTO
	 * Resp - Api resp (SC 201) 
	 * 
	 */
	@PostMapping
	public ResponseEntity<?> addNewCategory(@RequestBody CategoryDTO category) {
		System.out.println("in add category " + category);
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(categoryService.addNewCategory(category));
	}

	/*
	 * Desc -Soft delete category URL - http://host:port/categories/{categoryId} Method
	 * - DELETE Payload - category id (using URI template variable) * Response -
	 * ApiResponse DTO
	 */
	@DeleteMapping("/{categoryId}")
	public ResponseEntity<?> deleteCategoryDetails(@PathVariable Long categoryId) {
		System.out.println("in soft delete " + categoryId);		
		return ResponseEntity.ok(categoryService.deleteCategory(categoryId));
		
	}

	/*
	 * Desc - get category details by id URL -
	 * http://host:port/categories/{categoryId} Method - GET Payload - category id
	 * (using URI template variable) * Response - Category
	 */
	@GetMapping("/{categoryId}")
	public ResponseEntity<?> getCategoryDetails(@PathVariable Long categoryId) {
		System.out.println("in get category " + categoryId);
		return ResponseEntity.ok(categoryService.getCategory(categoryId));
	}

	/*
	 * Desc - update category details URL - http://host:port/categories/{categoryId}
	 * Method - PUT Payload - category id (using URI template variable) + Request
	 * Body - updated category details Response - mesg wrapped in Api resp
	 */
	@PutMapping("/{categoryId}")
	public ResponseEntity<?> updateCategoryDetails(@RequestBody CategoryDTO category,
			@PathVariable Long categoryId) {
		System.out.println("in update " + categoryId + " " + category);
		return ResponseEntity.ok(categoryService.updateCategory(categoryId, category));
	}

	/*
	 * Objective - i/p - category id. o/p - category +product details	 * 
	 * Desc - Get category n associated products details 
	 * URL -
	 * http://host:port/categories/{categoryId}/posts Method - GET Payload -
	 * category id (using URI template variable) Response - CategoryPostDTO
	 */
	@GetMapping("/{categoryId}/posts")
	public ResponseEntity<?> getCategoryAndPostDetails(@PathVariable Long categoryId) {
		System.out.println("in category + posts");
		return ResponseEntity.ok
				(categoryService.getCategoryAndPosts(categoryId));

	}
}
