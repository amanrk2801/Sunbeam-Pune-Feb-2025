package com.sunbeam.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeam.custom_exceptions.ApiException;
import com.sunbeam.custom_exceptions.ResourceNotFoundException;
import com.sunbeam.dao.RestaurantDao;
import com.sunbeam.dto.ApiResponse;
import com.sunbeam.dto.RestaurantRespDTO;
import com.sunbeam.entities.Restaurant;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class RestaurantServiceImpl implements RestaurantService {
	// depcy - auto wire by type : constr based D.I - immutable	
	private final RestaurantDao restaurantDao;
	private ModelMapper modelMapper;
	

	@Override
	public List<Restaurant> getAllRestaurants() {
		// TODO Auto-generated method stub
		return restaurantDao.findByStatusTrue();
	}

	@Override
	public String deleteRestaurantDetail(Long restaurantId) {
		// get restaurant from its id
		Restaurant restaurant = restaurantDao.findById(restaurantId)
				.orElseThrow(() -> new ResourceNotFoundException("invalid restaurant id !!!!!"));
		// => restaurant : PERSISTENT
		restaurant.setStatus(false);// modifying state the persistent entity
		return "soft deleted restaurant details ....";
	}
	/*
	 * Service layer rets (@Transactional) Spring supplied Tx manager bean - checks
	 * run time excs (un chked) - > yes - > tx.rollback() -> session.close() no excs
	 * - >tx.commit -> session.flush -> dirty checking -> DML - update ->
	 * session.close()
	 */

	@Override
	public RestaurantRespDTO getRestaurantDetails(Long id) {
		// invoke dao's method
	 
				Restaurant entity = restaurantDao.findById(id)
				.orElseThrow(() -> 
				new ResourceNotFoundException("Invalid Restaurant ID !!!!!"));
				//=> success , map entity -> dto
				return modelMapper.map(entity, RestaurantRespDTO.class);
	}

	@Override
	public String updateDetails(Long id, Restaurant restaurant) {
		if(restaurantDao.existsById(id)) {
			restaurantDao.save(restaurant);
			return "restaurant detail updated !";
		}
		return "Invalid resturant id !!!!!!!!!!!!!!!!";
	}//DML - update

	@Override
	public ApiResponse addNewRestaurant(Restaurant transientRestaurant) {
		//validate restaurant name - distinct
		if(restaurantDao.existsByName(transientRestaurant.getName()))
			throw new ApiException("Dup Restaurant Name !!!!!!!!!");
		
		// disting name -> setter
		transientRestaurant.setStatus(true);
		// invoke dao's method - save : inherited API from CrudRepo
		Restaurant persistenRestaurant = restaurantDao.save(transientRestaurant);
		return 
				new ApiResponse("Added new restaurant with ID=" + persistenRestaurant.getId());
	}// upon no exc -> commit -> flush -> insert -> close

}
