﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace DemoMVC.Filters
{
    public class AuthFilter: ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.HttpContext.Request.Path.ToString().ToLower().Contains("login"))
            {
                string? userName = context.HttpContext.Session.GetString("Username");

                if (userName==null)
                {
                    context.HttpContext.Response.Redirect("/Login/SignIn");
                }
                
            }
        }
    }
}
