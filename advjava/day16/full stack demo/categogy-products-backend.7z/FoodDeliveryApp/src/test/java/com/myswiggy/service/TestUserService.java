package com.myswiggy.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.myswiggy.dto.AuthRequest;
import com.myswiggy.dto.UserRespDTO;
import com.myswiggy.service.UserService;

@SpringBootTest
class TestUserService {
	//D.I - auto wiring byType - field level
	@Autowired
	private UserService userService;

	@Test
	void testAuthenticate() {
		AuthRequest dto=new AuthRequest("a1@gmail.com", "12345");
		UserRespDTO respDto = userService.authenticate(dto);
		assertEquals(1,respDto.getId());
	
		
	}

}
