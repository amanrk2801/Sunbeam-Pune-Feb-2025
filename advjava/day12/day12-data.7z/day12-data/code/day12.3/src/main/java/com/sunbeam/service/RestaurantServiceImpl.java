package com.sunbeam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeam.dao.RestaurantDao;
import com.sunbeam.entities.Restaurant;

@Service //B.L holder - spring bean
@Transactional //auto tx management
public class RestaurantServiceImpl implements RestaurantService {
	 //depcy
	@Autowired
	private RestaurantDao restaurantDao;
	

	@Override
	public List<Restaurant> getAllRestaurants() {
		// TODO Auto-generated method stub
		return restaurantDao.getAllRetaurants();
	}

}
