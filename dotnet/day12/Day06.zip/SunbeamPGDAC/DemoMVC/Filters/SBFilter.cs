﻿using Microsoft.AspNetCore.Mvc.Filters;
using DemoMVC.Helpers;

namespace DemoMVC.Filters
{

    public class SBFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            Logger.CurrentLogger.Log(context.HttpContext.Request.Path + " is Executing");
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            Logger.CurrentLogger.Log(context.HttpContext.Request.Path + " is Executed");
        }

        public override void OnResultExecuting(ResultExecutingContext context)
        {
            Logger.CurrentLogger.Log(context.HttpContext.Request.Path + " UI is getting processed");
        }

        public override void OnResultExecuted(ResultExecutedContext context)
        {
            Logger.CurrentLogger.Log(context.HttpContext.Request.Path + " UI is processed");
        }
    }


    //public class SBFilter : Attribute, IActionFilter
    //{
    //    public void OnActionExecuted(ActionExecutedContext context)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public void OnActionExecuting(ActionExecutingContext context)
    //    {
    //        throw new NotImplementedException();
    //    }
    //}
}
