package com.sunbeam.pages;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.sunbeam.dao.UserDaoImpl;
import com.sunbeam.pojos.User;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.Servlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FrontControllerServlet
 */
@WebServlet(value = "/", loadOnStartup = 1)
public class FrontControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDaoImpl userDao;

	/**
	 * @see Servlet#init()
	 */
	public void init() throws ServletException {
		try {
			// 1. create dao instance
			userDao = new UserDaoImpl();
			System.out.println("init successful !");
		} catch (Exception e) {
			throw new ServletException("err in init of " + getClass(), e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			// clean up dao
			userDao.cleanUp();
			System.out.println("user dao cleaned up");
		} catch (Exception e) {
			throw new RuntimeException("err in destroy of " + getClass(), e);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// dev steps
			// 1. get request path
			// URL http://host:port/ctx/
			String path = request.getServletPath();// "/"
			String viewName = null;
			String prefix = "/WEB-INF/views/";
			String suffix = ".jsp";
			switch (path) {
			case "/": // render user list
				// add results (user list) - under request scope
				request.setAttribute("user_list", listUsers());
				viewName = "list";
				break;
			case "/delete":
				System.out.println(deleteUserDetailsById(request));
				//redirect the client in the next request
				response.sendRedirect("./");
				return;
		
			}
			if (viewName != null) {
				RequestDispatcher rd = request.getRequestDispatcher(prefix + viewName + suffix);// AVN -
																								// /WEB-INF/views/list.jsp
				rd.forward(request, response);
			}
		} catch (Exception e) {
			throw new ServletException("err in do-get of " + getClass(), e);
		}
	}

	private String deleteUserDetailsById(HttpServletRequest request) throws SQLException {
		int userId = Integer.parseInt(request.getParameter("id"));
		return userDao.deleteUser(userId);
	}

	private List<User> listUsers() throws SQLException {
		// invoke dao's method
		return userDao.listUsers();

	}

}
