package com.sunbeam.dao;

import java.util.List;

import com.sunbeam.entities.Restaurant;

public interface RestaurantDao {
//get all restaurants
	List<Restaurant> getAllRetaurants();
}
