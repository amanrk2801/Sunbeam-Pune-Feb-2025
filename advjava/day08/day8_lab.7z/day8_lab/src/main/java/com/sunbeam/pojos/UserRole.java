package com.sunbeam.pojos;

public enum UserRole {
	ADMIN, VOTER
}
