package com.sunbeam.dependent;

import com.sunbeam.dependency.Teacher;

public class PublicSchool implements School {
	private Teacher subjectTeacher;// =new MathsTeacher();

	// ctor based D.I
	public PublicSchool(Teacher myTeacher) {
		this.subjectTeacher = myTeacher;
		System.out.println("In constructor - " + getClass());
	}

	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}

	// custom init method
	public void anyInit() {
		System.out.println("in init of " 
	+getClass()+" depcy "+ subjectTeacher);// not null
	}

	// custom destroy method
	public void anyDestroy() {
		System.out.println("in destroy of "+getClass()+" depcy "+ subjectTeacher);// not null
	}

}
