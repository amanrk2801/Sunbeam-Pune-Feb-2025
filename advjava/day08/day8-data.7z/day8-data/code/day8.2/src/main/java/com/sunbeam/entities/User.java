package com.sunbeam.entities;

import java.time.LocalDate;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//JPA annotations
@Entity
@Table(name = "users") // to specify table name
//lombok annotations
@NoArgsConstructor
@Getter
@Setter
@ToString(exclude = { "password",  "image" })
public class User extends BaseEntity{
	/*
	 * Hibernate can perform null checking for the id property more effectively than
	 * checking against the default un saved value 0. What should be the id prop
	 * type ? prmitive or wrapper ? - wrapper
	 */
	@Column(name = "first_name", length = 20) // col name n varchar(20) size
	private String firstName;
	@Column(name = "last_name", length = 30) // col name n varchar(30) size
	private String lastName;
	@Column(length = 20, unique = true) // adds unique constraint
	private String email;
	@Column(nullable = false) // NOT NULL constraint
	private String password;
	
	private LocalDate dob;
	// to create column type - enum | varchar
	@Enumerated(EnumType.STRING)
	@Column(name = "user_role")
	private UserRole userRole;
	@Column(name = "subscription_amount")
	private double subscriptionAmount;
	@Lob // => large object - BLOB (longblob) - byte[] , CLOB - char[]
	private byte[] image;

	// parameterized ctor
	public User(String firstName, String lastName, String email, String password, LocalDate dob, UserRole userRole,
			double subscriptionAmount) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.dob = dob;
		this.userRole = userRole;
		this.subscriptionAmount = subscriptionAmount;
	}

	public User(String firstName, String lastName, LocalDate dob) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
	}
}
