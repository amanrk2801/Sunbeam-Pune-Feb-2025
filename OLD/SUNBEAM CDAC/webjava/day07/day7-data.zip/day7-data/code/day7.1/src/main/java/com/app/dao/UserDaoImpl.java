package com.app.dao;

import com.app.entities.Role;
import com.app.entities.User;

import org.apache.commons.io.FileUtils;
import org.hibernate.*;
import static com.app.utils.HibernateUtils.getFactory;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

public class UserDaoImpl implements UserDao {

	@Override
	public String registerNewUser(User newUser) {
		// newUser - TRANSIENT (exists only in java heap)
		String mesg = "User registration failed !!!!!!!!";
		// 1. get Session from SessionFactory
		/*
		 * API of SF public Session getCurrentSession() throws HibernateException
		 */
		Session session = getFactory().getCurrentSession();

		// 2. Begin a Transaction
		/*
		 * Session API - public Transaction beginTransaction() throws HibernateException
		 */
		Transaction tx = session.beginTransaction();
		try {
			/*
			 * Session API public Serializable save(Object o) o - trasient entity ref. Rets
			 * Serializable ID associated with the persistent entity.
			 */
			Serializable userId = session.save(newUser);
			// newUser - PERSISTENT (part of L1 cache , not yet in DB)
			tx.commit();
			/*
			 * 1. session.flush() 2. Hibernate performs - auto dirty checking (DMLs)
			 * Compares / checks the state of L1 cache against DB new entity -insert updated
			 * entity - update removed entity - delete 3. session.close() - L1 cache is
			 * destroyed Pooled out DB cn rets to DBCP
			 * 
			 */
			mesg = "User registered with ID " + userId;
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			/*
			 * 1. session.close() - L1 cache is destroyed Pooled out DB cn rets to DBCP
			 * 
			 */
			// re throw the SAME exception to the caller
			throw e;
		}
		// newUser - DETACHED (only from L1 cache)
		return mesg;
	}// newUser - marked for GC (doesn't exist !)

	@Override
	public User getUserDetails(Long userId) {
		User user = null;// user - Doesn't exist in heap
		// 1. get Session from SF
		Session session = getFactory().getCurrentSession();
		// 2. Begin tx
		Transaction tx = session.beginTransaction();
		try {
			user = session.get(User.class, userId);
			/*
			 * Hibernate chks - if entity alrdy exists L1 cache if no - select query if yes
			 * - data will be lifted from cache!
			 */
			user = session.get(User.class, userId);
			user = session.get(User.class, userId);
			user = session.get(User.class, userId);

			/*
			 * In case of valid id user - PERSISTENT (part of L1 cache , part of DB) invalid
			 * id - null
			 */
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return user;// user - DETACHED
	}

	@Override
	public List<User> getAllUsers() {
		List<User> users = null;
		String jpql = "select u from User u";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).getResultList();
			// users - list of persistent entities
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return users;// users - list of detached entities
	}

	@Override
	public List<User> getUsersByDobAndRole(LocalDate begin, LocalDate end1, Role userRole1) {
		List<User> users = null;
		String jpql = "select u from User u where u.dob between :start and :end and u.userRole=:role";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("start", begin).setParameter("end", end1)
					.setParameter("role", userRole1).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return users;
	}

	@Override
	public List<String> getLastNamesByRole(Role role1) {
		List<String> lastNames = null;
		String jpql = "select u.lastName from User u where u.userRole=:rl";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			lastNames = session.createQuery(jpql, String.class).setParameter("rl", role1).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return lastNames;
	}

	@Override
	public List<User> getSelectedUserDetailsByRole(Role role1) {
		List<User> users = null;
		String jpql = "select new com.app.entities.User(firstName,lastName,dob) from User u where u.userRole=:role";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("role", role1).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return users;
	}

	@Override
	public String changePassword(String email, String oldPassword, String newPwd) {
		User user = null;
		String mesg = "changing pwd failed!!!";
		String jpql = "select u from User u where u.email=:em and u.password=:pass";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			user = session.createQuery(jpql, User.class).setParameter("em", email).setParameter("pass", oldPassword)
					.getSingleResult();
			// user - PERSISTENT
			user.setPassword(newPwd);// modifying state of the PERSISTEN entity
			// session.evict(user);//cancelling updates (removing user ref from L1 cache)
			// user - DETACHED
			tx.commit();// as a result of dirty checking - DML - update
			mesg = "changed the password !";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		user.setPassword("1234567890");// modifying state of the DETACHED entity
		return mesg;
	}

	@Override
	public String applyDiscount(LocalDate date1, double discountAmount) {
		String mesg = "updation failed!!!";
		String jpql = "update User u set u.regAmount=u.regAmount-:disc where u.dob < :date and u.userRole <> 'ADMIN'";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			int rowCount = session.createQuery(jpql).setParameter("disc", discountAmount).setParameter("date", date1)
					.executeUpdate();
			mesg = "Updated " + rowCount + " users ....";
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public String deleteUserDetails(Long userId) {
		String mesg = "deletion of user details failed!!!!";
		User user = null;
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
//get user details from the id
			user = session.get(User.class, userId);
			// chk if user exists
			if (user != null) {
				// user - PERSISTENT
				// mark the entity for removal
				session.delete(user);// user - REMOVED
				mesg = "deleted user details !";
			}
			tx.commit();
			/*
			 * session.flush() -> dirty checking -> DML - delete session.close() -> L1 cache
			 * destroyed -> user - TRANSIENT
			 */
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return mesg;
	}// user - marked for GC (end of java obj life cycle!)

	@Override
	public String storeImage(String fileName, String email1) throws IOException {
		String mesg = "storing of image failed!!!!!!!!!";
		String jpql = "select u from User u where u.email=:email";

		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
//3. validate user
			User user = session.createQuery(jpql, User.class).setParameter("email", email1).getSingleResult();// throws
			// NoResultExc
			// - in
			// case
			// of
			// invalid
			// ema// user - PERSISTENT
			// validate file
			File file = new File(fileName);
			if (file.isFile() && file.canRead()) {
				user.setImage(FileUtils.readFileToByteArray(file));// modifying state of persistent user
				mesg="stored image !";
			}
			tx.commit();//DML - update
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return mesg;
	}

}
