package com.sunbeam.listeners;

import jakarta.servlet.ServletContext;
import static com.sunbeam.utils.DBUtils.*;

import java.sql.SQLException;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class DBConnectionSetupListener
 *
 */
@WebListener
public class DBConnectionSetupListener implements ServletContextListener {

	/**
	 * @see ServletContextListener#contextInitialized(ServletContextEvent)
	 */
	/*
	 * Invoked by WC - exactly once @ web app start up
	 */
	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("in ctx inited");
		// 1 get servlet ctx from ServletContextEvent
		ServletContext ctx = sce.getServletContext();
		// 2. get ctx's init parameters
		String url = ctx.getInitParameter("db_url");
		String userName = ctx.getInitParameter("user_name");
		String pwd = ctx.getInitParameter("password");
		// 3. open singleton DB cn
		try {
			openConnection(url, userName, pwd);
		} catch (SQLException e) {
			System.out.println("err in ctx listener " + e);
		}
	}

	/**
	 * @see ServletContextListener#contextDestroyed(ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent sce) {
		/*
		 * WC invokes exactly once @ app shut down (server shut down | re deploy | un
		 * deploy)
		 */
		System.out.println("in ctx destroyed");
		try {
			closeConnection();
		} catch (SQLException e) {
			System.out.println("err in ctx destroy " + e);
		}
	}

}
