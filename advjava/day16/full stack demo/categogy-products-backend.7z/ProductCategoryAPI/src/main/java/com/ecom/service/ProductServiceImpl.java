package com.ecom.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecom.custom_exceptions.ResourceNotFoundException;
import com.ecom.dto.ApiResponse;
import com.ecom.dto.ProductDTO;
import com.ecom.entities.Category;
import com.ecom.entities.Product;
import com.ecom.repository.CategoryRepository;
import com.ecom.repository.ProductRepository;

import lombok.AllArgsConstructor;

@Service // represents a spring bean containing B.L
@Transactional // for automatic tx management
@AllArgsConstructor
public class ProductServiceImpl implements ProductService {
	private ProductRepository productRepository;
	private CategoryRepository categoryRepository;
	private ModelMapper modelMapper;

	@Override
	public ApiResponse addProduct(ProductDTO dto) {
		Category category = categoryRepository.findById(dto.getCategoryId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Category Id !!!!"));

		Product product = modelMapper.map(dto, Product.class);
		// E-R : Product *---->1 Category
		product.setCategory(category);
		Product savedProduct = productRepository.save(product);
		return new ApiResponse("New product added with id=" + savedProduct.getId());

	}

	@Override
	public List<ProductDTO> getProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll().stream().map(product -> modelMapper.map(product, ProductDTO.class))
				.collect(Collectors.toList());

	}

	@Override
	public ApiResponse deleteProduct(Long productId) {
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid product ID !!!"));
		// valid id
		productRepository.delete(product);
		return new ApiResponse("Product deleted !");
	}

	@Override
	public ProductDTO getProduct(Long productId) {
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid product ID !!!"));

		ProductDTO dto = modelMapper.map(product, ProductDTO.class);
		dto.setCategoryId(product.getCategory().getId());//assigning category id - so that it will be sent to front end
		return dto;
	}

	@Override
	public ApiResponse updateProduct(Long productId, ProductDTO dto) {
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid product ID !!!"));
		modelMapper.map(dto, product);
		return new ApiResponse("Updated product details !");
	}

}
