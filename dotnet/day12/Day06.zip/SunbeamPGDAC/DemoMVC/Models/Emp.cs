﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoMVC.Models
{
    [Table("Emp")]
    public class Emp
    {
        [Key]
        //[DisplayName("ENo")]
        public int No { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }

    public class SBDBContext: DbContext
    {
        public DbSet<Emp> Emps { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=SBDB;Integrated Security=True;");
        }
    }
}
