package com.sunbeam.tester;

//import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.SessionFactory;

import com.sunbeam.utils.HibernateUtils;

public class TestHibernate {

	public static void main(String[] args) {
		try (SessionFactory sf = HibernateUtils.getFactory()) {
			System.out.println("hibernate up n running....");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
