package dependent;

import dependency.Coach;
import dependency.Teacher;

public class PublicSchool implements School {
	private Teacher subjectTeacher;// mandatory depcy
	private Coach sportsCoach; // optional depcy

	public PublicSchool() {
		System.out.println("in def ctor of " + getClass());
	}

	private PublicSchool(Teacher myTeacher, Coach myCoach) {
		this.subjectTeacher = myTeacher;
		this.sportsCoach = myCoach;
		System.out.println("In private constructor - " + getClass() + " " + subjectTeacher + " " + sportsCoach);// not null n
																										// null
	}

	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}

	@Override
	public void organizeSportsEvent() {
		System.out.println("organizing sports event ");
		System.out.println(sportsCoach.getDailyWorkout());

	}

	// add custom init method
	public void anyInit() {
		System.out.println("in init " + subjectTeacher + " " + sportsCoach);// both - not null
	}

	// add destroy
	public void anyDestroy() {
		System.out.println("in destroy " + subjectTeacher);// not null
	}

	// factory method based D.I
	public static PublicSchool myFactoryMethod(Teacher teacher123,
			Coach myCoach1) {
		System.out.println("in factory method " + teacher123 + " " + myCoach1);
		PublicSchool school = new PublicSchool(teacher123, myCoach1);//partial IoC
		return school;//factory method rets depnt spring bean to the caller
	}

}
