package com.sunbeam.controller;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/test")
public class TestController {
	public TestController() {
		System.out.println("in ctor of " + getClass());
	}

	// URL -http://host:port/ctx_path/test/test1 ,method=GET
	@GetMapping("/test1")
	public ModelAndView testModelAndView() {
		System.out.println("test m n v");
		return 
				new ModelAndView("/test/test1", "server_ts", LocalDateTime.now());// AVN - /WEB-INF/views/test/test1.jsp
	}
	// URL -http://host:port/ctx_path/test/test2 ,method=GET
		@GetMapping("/test2")
		public String testModelMap(Model modelMap) {
			System.out.println("in test model map "+modelMap);//{}
			//add model attributes in the map
			modelMap.addAttribute("ts", new Date())
			.addAttribute("number_list", List.of(10,20,30,40));
			return "/test/test2";
			/*
			 * Handler rets explicitly LVN n implicitly (SC) rets model map
			 * -> D.S -> LVN -> V.R -> AVN ->D.S
			 * -> adds model attributes under request scope 
			 * -> forwards the clnt -> JSP
			 */
		}

}
