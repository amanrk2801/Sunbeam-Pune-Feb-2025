package com.ecom.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecom.entities.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity,Long>{
//add derived finder method for user signin 
	Optional<UserEntity> findByEmailAndPassword(String email,String pass);
}
