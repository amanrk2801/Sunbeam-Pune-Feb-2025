package com.app.dao;

import static com.app.utils.HibernateUtils.getFactory;

import java.sql.Date;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.entities.Candidate;
import com.app.entities.User;

public class UserDaoImpl implements UserDao {

	@Override
	public User signIn(String email, String password) throws SQLException {
		User user=null;
		String jpql="select u from User u where u.email=:em and u.password=:pass";
		// 1. get session from SF (getCurrentSession)
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			user=session.createQuery(jpql,User.class)
					.setParameter("em",email)
					.setParameter("pass", password)
					.getSingleResult();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return user;
	}

	@Override
	public List<User> getUserDetails(Date begin, Date end) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String voterRegistration(User newVoter) throws SQLException {
		// 1. get session from SF (getCurrentSession)
				Session session=getFactory().getCurrentSession();
				//2. Begin a Tx
				Transaction tx=session.beginTransaction();
				try {
					
					tx.commit();
				} catch (RuntimeException e) {
					if(tx != null)
						tx.rollback();
					//re throw the exc to the caller
					throw e;
				}
		return null;
	}

	@Override
	public String changePassword(String email, String oldPwd, String newPwd) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteVoterDetails(int voterId) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateVotingStatus(int voterId) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
