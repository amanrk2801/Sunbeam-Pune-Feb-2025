package com.sunbeam.dao;

import com.sunbeam.entities.Employee;

public interface EmployeeDao {
//add a method for inserting emp details
	String insertEmpDetails(Employee employee);
}
