package com.sunbeam.service;

import java.util.List;

import com.sunbeam.dto.ApiResponse;
import com.sunbeam.dto.RestaurantRespDTO;
import com.sunbeam.entities.Restaurant;

public interface RestaurantService {
	List<Restaurant> getAllRestaurants();
	String deleteRestaurantDetail(Long restaurantId);
	RestaurantRespDTO getRestaurantDetails(Long id);
	String updateDetails(Long id, Restaurant restaurant);
	ApiResponse addNewRestaurant(Restaurant transientRestaurant);
}
