package com.sunbeam.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
//to add composite unique constraint on multiple columns 
@Table(name = "food_items",
uniqueConstraints = @UniqueConstraint
(columnNames = {"item_name","restaurant_id"}))
@NoArgsConstructor
@Getter
@Setter
@ToString(callSuper = true)
public class FoodItem extends BaseEntity {
	@Column(name="item_name",length = 50)
	private String itemName;
	@Column(name="item_description")
	private String itemDescription;
	@Column(name="is_veg")
	private boolean isVeg;
	private int price;
	//FoodItem *--->1 Restaurant 
	@ManyToOne //mandatory
	//to customize name of FK column 
	@JoinColumn(name="restaurant_id")	
	private Restaurant myRestaurant;

}
