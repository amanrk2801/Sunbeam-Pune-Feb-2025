package com.sunbeam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeam.entities.Restaurant;
import com.sunbeam.service.RestaurantService;

import lombok.AllArgsConstructor;

@RestController // = @Controller : class level +
//@ResponseBody - ret types of all req handling methods
@RequestMapping("/restaurants")
@CrossOrigin(origins = "http://localhost:3000")
@AllArgsConstructor
public class RestaurantController {
	// depcy - constr based D.I =>
	// 1. mandatory dependencies => SC creates dependencies
	// n then dependent
	// 2. can add immutability => final keyword
	// => inherently thread safe (no need of synchronization)
//	@Autowired//(required = false)
	private final RestaurantService restaurantService;

//	@Autowired //ctor based D.I - depcy -> depnt
//	public RestaurantController(RestaurantService restaurantService) {
//		super();
//		this.restaurantService = restaurantService;
//	}

//	@Autowired
//	public RestaurantController(RestaurantService restaurantService) {
//		super();
//		this.restaurantService = restaurantService;
//	}

	/*
	 * Request handling method (REST API end point) URL -
	 * http://host:port/restaurants/ Method - GET Payload - none Resp - @RespBody
	 * list of restaurants -> JSON []
	 */
	@GetMapping
	public /* @ResponseBody */ List<Restaurant> listAvailableRestaurants() {
		System.out.println("in list");
		return restaurantService.getAllRestaurants();
	}
	/*
	 * Request handling method (REST API end point) 
	 * - desc - Add new restaurant
	 * URL -http://host:port/restaurants
	 *  Method - POST 
	 *  Payload -JSON representation of restaurant
	 * Resp - string 
	 */
	@PostMapping
	public String addNewRestaurant(@RequestBody
			Restaurant newRestaurant) {
		System.out.println("in add "+newRestaurant);
		//call service method
		return restaurantService.addNewRestaurant(newRestaurant);
	}
	
	/*
	 * REST API end point
	 * - desc -soft  delete restaurant details
	 * URL -http://host:port/restaurants/{restaurantId}
	 *  Method - DELETE 
	 *  Payload - none
	 * Resp - String 
	 */
	@DeleteMapping("/{restaurantId}")//=@RequestMapping(method=DELETE)
	public String deleteDetails(@PathVariable /* (name="restaurantId") */ Long restaurantId) {
		System.out.println("in delete "+restaurantId);
		return restaurantService.deleteRestaurantDetail(restaurantId);
	}

}
