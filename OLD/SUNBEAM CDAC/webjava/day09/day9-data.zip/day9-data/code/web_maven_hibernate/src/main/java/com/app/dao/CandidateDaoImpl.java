package com.app.dao;
import static com.app.utils.HibernateUtils.getFactory;

import java.util.LinkedHashMap;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.app.entities.Candidate;

public class CandidateDaoImpl implements CandidateDao {

	@Override
	public List<Candidate> getAllCandidates() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateVotes(int candidateId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Candidate> getTop2Candidates() {
		// 1. get session from SF (getCurrentSession)
				Session session=getFactory().getCurrentSession();
				//2. Begin a Tx
				Transaction tx=session.beginTransaction();
				try {
					
					tx.commit();
				} catch (RuntimeException e) {
					if(tx != null)
						tx.rollback();
					//re throw the exc to the caller
					throw e;
				}
		return null;
	}

	@Override
	public LinkedHashMap<String, Integer> getPartywiseVotes() {
		// 1. get session from SF (getCurrentSession)
				Session session=getFactory().getCurrentSession();
				//2. Begin a Tx
				Transaction tx=session.beginTransaction();
				try {
					
					tx.commit();
				} catch (RuntimeException e) {
					if(tx != null)
						tx.rollback();
					//re throw the exc to the caller
					throw e;
				}
		return null;
	}

	@Override
	public String deleteCandidateDetails(int candidateId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateCandidateDetails(String newParty, int votes, int candidateId) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
