package com.sunbeam.tester;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import com.sunbeam.dao.CategoryDao;
import com.sunbeam.dao.CategoryDaoImpl;
import com.sunbeam.entities.Category;

public class GetOrLoadCategoryDetails {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); 
				Scanner sc = new Scanner(System.in)) {
			// create category dao instance
			CategoryDao dao = new CategoryDaoImpl();
			System.out.println("Enter category id to search");
			Category category = dao.getCategoryDetailsById(sc.nextLong());
			System.out.println(category);
			System.out.println(category.getClass());//F.Q cls name - proxy !

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
