package tester;

import dependency.MathsTeacher;
import dependent.PublicSchool;
import dependent.School;

public class TestSchool {

	public static void main(String[] args) {
		School mySchool=new PublicSchool(new MathsTeacher());
		mySchool.manageAcademics();

	}

}
