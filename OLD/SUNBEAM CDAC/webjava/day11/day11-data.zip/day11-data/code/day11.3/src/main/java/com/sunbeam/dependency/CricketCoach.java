package com.sunbeam.dependency;

import org.springframework.stereotype.Component;

//singleton n eager
@Component("cricket") // to tell SC following is spring bean , whose life cycle must be managed by SC
			// + make it available for D.I
public class CricketCoach implements Coach {

	public CricketCoach() {
		System.out.println("In constructor - " + getClass());
	}

	@Override
	public String getDailyWorkout() {
		return "Practice fast bowling for 15 minutes";
	}
}
