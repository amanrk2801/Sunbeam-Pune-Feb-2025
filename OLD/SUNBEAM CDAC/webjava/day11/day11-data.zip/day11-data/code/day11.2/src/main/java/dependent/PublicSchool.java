package dependent;

import dependency.Coach;
import dependency.Teacher;

public class PublicSchool implements School {
	private Teacher subjectTeacher;// optional depcy
	private Coach sportsCoach; // optional depcy

//	public PublicSchool() {
//		System.out.println("in def ctor of " + getClass());
//	}

//ctor based D.I
	public PublicSchool(Teacher subjectTeacher, Coach sportsCoach) {
		super();
		this.subjectTeacher = subjectTeacher;
		this.sportsCoach = sportsCoach;
		System.out.println("in ctor "+getClass());
	}

	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}

	@Override
	public void organizeSportsEvent() {
		System.out.println("organizing sports event ");
		System.out.println(sportsCoach.getDailyWorkout());

	}

	// add custom init method
	public void anyInit() {
		System.out.println("in init " + subjectTeacher + " " + sportsCoach);// both - not null
	}

	// add destroy
	public void anyDestroy() {
		System.out.println("in destroy " + subjectTeacher);// not null
	}
	
}
