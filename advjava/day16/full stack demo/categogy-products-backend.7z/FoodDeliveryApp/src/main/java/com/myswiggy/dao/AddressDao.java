//package com.myswiggy.dao;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.myswiggy.entities.Address;
//
//public interface AddressDao extends JpaRepository<Address, Long> {
//
//}
