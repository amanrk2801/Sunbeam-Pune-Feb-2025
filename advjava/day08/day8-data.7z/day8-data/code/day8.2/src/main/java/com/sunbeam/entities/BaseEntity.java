package com.sunbeam.entities;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@MappedSuperclass // to declare a super class , containing common fields , no table !
//lombok
@Getter
@Setter
@ToString //only for debugging
public class BaseEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // optional
	@Column
	private Long id;
	@CreationTimestamp // entity creation
	@Column(name="created_on")
	private LocalDate createdOn;
	@UpdateTimestamp // entity last updation
	@Column(name="last_updated")
	private LocalDateTime lastUpdated;
}
