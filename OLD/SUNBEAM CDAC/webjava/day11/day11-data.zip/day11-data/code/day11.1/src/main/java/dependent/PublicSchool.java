package dependent;

import dependency.Coach;
import dependency.Teacher;

public class PublicSchool implements School {
	private Teacher subjectTeacher;// optional depcy
	private Coach sportsCoach; //optional depcy

	public PublicSchool() {
		System.out.println("in def ctor of " + getClass());
	}

	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}
	
	

	@Override
	public void organizeSportsEvent() {
		System.out.println("organizing sports event ");
		System.out.println(sportsCoach.getDailyWorkout());
		
	}

	// add custom init method
	public void anyInit() {
		System.out.println("in init " + subjectTeacher+" "+sportsCoach);//both -  not null
	}

	// add destroy
	public void anyDestroy() {
		System.out.println("in destroy " + subjectTeacher);// not null
	}
	//setter Based D.I

	public void setSportsCoach(Coach sportsCoach123) {
		this.sportsCoach = sportsCoach123;
		System.out.println("in setter coach "+sportsCoach);
	}

	public void setSubjectTeacher(Teacher subjectTeacher1) {
		this.subjectTeacher = subjectTeacher1;
		System.out.println("in setter teacher "+subjectTeacher);
	}	

}
