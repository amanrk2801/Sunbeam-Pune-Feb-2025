package com.sunbeam.dao;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sunbeam.entities.Restaurant;

public class RestaurantDaoImpl implements RestaurantDao {

	@Override
	public String addRestaurant(Restaurant newRestaurant) {
		String mesg = "adding restuarant failed !!!!!!!!!";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			// transient -> persistent
			session.persist(newRestaurant);
			tx.commit();
			mesg = "Added new restaurant with ID " + newRestaurant.getId();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return mesg;
	}

}
