package com.sunbeam.entities;
import java.util.ArrayList;
import java.util.List;

/*
 * Details -
Restaurant - 
private String name;
private String address;
private String city;
private String description;

 */
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Entity
@Table(name="restaurants")
@NoArgsConstructor
@Getter
@Setter
@ToString(callSuper = true)
public class Restaurant extends BaseEntity {
	@Column(length = 100,unique = true)
	private String name;
	private String address;
	@Column(length = 30)
	private String city;
	private String description;
	//Restaurant 1---->* FoodItem
	/*
	 * Tip - Always initialize  collection based property to an empty 
	 * collection
	 * - to avoid NPExc.
	 */
	@OneToMany (mappedBy = "myRestaurant")
	//mandatory - otherwise Mapping Exception !
	private List<FoodItem> foodItems=new ArrayList<>();//size :0 , initCapa=10
	//overloaded ctor to add new restaurant
	public Restaurant(String name, String address, String city, String description) {
		super();
		this.name = name;
		this.address = address;
		this.city = city;
		this.description = description;
	}
	
}
