package com.sunbeam.dependent;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sunbeam.dependency.Coach;
import com.sunbeam.dependency.Teacher;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

//singleton n eager , id="public_school" 
//, autowire -> Field level D.I
@Component("public_school")
public class PublicSchool implements School {
	@Autowired // field level D.I - byType
	private Teacher[] subjectTeachers;
	@Autowired // field level D.I - byType
	private Coach[] sportsCoaches;
	public PublicSchool() {
		System.out.println("in def ctor of "+getClass());
	}
	

	// B.L
	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		Arrays.stream(subjectTeachers) // Stream<Teacher>
				.forEach(Teacher::teach); // teacher -> teacher.teach()
	}

	// B.L - sports event
	@Override
	public void organizeSportsEvent() {
		System.out.println("Organizing sports event ....");
		// System.out.println(sportsCoach.getDailyWorkout());
		Arrays.stream(sportsCoaches) // Stream<Coach>
				.forEach(coach -> System.out.println(coach.getDailyWorkout()));

	}

	// custom init method
	@PostConstruct
	public void anyInit() {
		System.out.println("in init of " + getClass() + " depcy " + subjectTeachers + " depcy " + sportsCoaches);// not
																						// null
	}
	@PreDestroy
	// custom destroy method
	public void anyDestroy() {
		System.out.println("in destroy of " + getClass() + " depcy " + subjectTeachers + " depcy " + sportsCoaches);// not
																													// null
	}

}
