package com.sunbeam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sunbeam.entities.Role;
import com.sunbeam.entities.User;
import com.sunbeam.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	// depcy - service layer i.f
	@Autowired
	private UserService userService;

	public UserController() {
		System.out.println("in ctor " + getClass());
	}

	// URL - http://host:port/ctx_path/user/login , method=GET
	@GetMapping("/login")
	public String showLoginForm() {
		System.out.println("in show login form");
		return "/user/login";// AVN : /WEB-INF/views/user/login.jsp
	}

	// URL - http://host:port/ctx_path/user/login , method=POST
	// method with rq param handling
	@PostMapping("/login")
	// @RequestParam => Used for binding incoming req params
	// to method args
	public String processLoginForm(@RequestParam String em, @RequestParam String pass, Model modelMap) {
		System.out.println("in process login form " + em + " " + pass + " " + modelMap);
		try {
			// 1. invoke service layer method
			User user = userService.authenticateUser(em, pass);
			// => login successful , continue to role authorization
			// save user details under suitable scope
			modelMap.addAttribute("message", "Successful Login !")
			.addAttribute("user_details", user);
			// authorization
			if (user.getRole() == Role.ADMIN) // forward clnt to admin's home page
				return "/admin/home";
			// blogger
			return "/blogger/home";

		} catch (RuntimeException e) {
			System.out.println("err " + e);
			// in case of invalid login ->
			// forward the clnt to login page , with err mesg
			modelMap.addAttribute("message", "Please retry , Invalid Email or Password !!!");
			return "/user/login";// AVN -/WEB-INF/views/user/login.jsp
		}
		
	}

}
