package com.sunbeam.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeam.dao.CategoryDao;
import com.sunbeam.entities.Category;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class CategoryServiceImpl implements CategoryService {
	//depcy - dao layer 
	//constructor based D.I - using lombok annotation
	//depcy first n then depnt 
	private final CategoryDao categoryDao;
	

	@Override
	public List<Category> getAllCategories() {
		// call dao's method
		return categoryDao.findAll();
	}


	@Override
	public String addNewCategory(Category transientCategory) {
		//transient -> persistent : via save inherited method of CrruRepository
		Category persistentCategory = categoryDao.save(transientCategory);		
		return "new category added , id="+persistentCategory.getId();
	}
	
	

}
