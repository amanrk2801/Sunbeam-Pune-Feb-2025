package com.ecom.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecom.custom_exceptions.AuthenticationException;
import com.ecom.dto.AuthRequest;
import com.ecom.dto.UserDTO;
import com.ecom.entities.UserEntity;
import com.ecom.repository.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	// depcy
	@Autowired
	private UserRepository userDao;
	@Autowired
	private ModelMapper mapper;

	@Override
	public UserDTO authenticateUser(AuthRequest dto) {
		// 1.invoke dao 's method
		UserEntity user = userDao.findByEmailAndPassword(
				dto.getEmail(), dto.getPwd())
				.orElseThrow(() -> 
				new AuthenticationException("Invalid Email or Password !!!!!!"));
		//valid login -user : persistent -> entity -> dto
		return mapper.map(user, UserDTO.class);
	}

	@Override
	public UserDTO registerUser(UserDTO request) {
		UserEntity persistentEntity = userDao.save(mapper.map(request, UserEntity.class));
		return mapper.map(persistentEntity, UserDTO.class);
	}
	

}
