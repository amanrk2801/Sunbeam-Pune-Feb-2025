﻿using Demo.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Demo.Filters;
namespace Demo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors(PolicyName = "policy3")]
    [AuthFilter]
    public class EmpsController : ControllerBase
    {
        [HttpGet]
        public IEnumerable<Emp> Get()
        {
            List<Emp> emps = new List<Emp>() {
             new Emp{ No = 11, Name = "Mahesh", Address = "Pune" },
             new Emp { No = 12, Name = "Nilesh", Address = "Panji" },
             new Emp{ No = 13, Name = "Amit", Address = "Mumbai" },
             new Emp{ No = 14, Name = "Chetan", Address = "Chennai" }
        };
            return emps;
        }
    }
}
