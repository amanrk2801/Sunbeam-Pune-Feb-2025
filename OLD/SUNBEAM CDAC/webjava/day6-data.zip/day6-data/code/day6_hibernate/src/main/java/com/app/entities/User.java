package com.app.entities;

import java.time.LocalDate;
import javax.persistence.*;

/*
 * users table 
column - id , first name , last name, email ,password , 
dob , registration amount,role,image

 */
@Entity // to tell JPA vendors - following is the entity
//, whose life cycle is to be managed.
@Table (name="users")//to specify table name
public class User {
	// Till Hibernate 5.x -ONLY unique id property MUST be Serializable(eg numeric
	// wrapper)
	@Id // mandatory field level annotation - PK constraint
	// for auto generation of Ids - most recommeded id 
	//generation strategy for MySQL
	@GeneratedValue(strategy = GenerationType.IDENTITY) // (strategy = GenerationType.AUTO) -adds auto increment
														// constraint
//default chosen strategy
	private Long id;
	@Column(name="first_name", length = 20) //col name , varchar(20)
	private String firstName;
	@Column(name="last_name", length = 20) //col name , varchar(20)
	private String lastName;
	@Column(length = 25,unique = true)//adds unique constraint
	private String email;
	@Column(length = 20, nullable = false) //NOT NULL constraint
	private String password;
	private LocalDate dob;
	@Column(name="reg_amount")
	private double regAmount;
	@Enumerated(EnumType.STRING) //col type - varchar (constant name)
	@Column(length = 15, name="user_role")
	private Role userRole;
	@Lob //large object , for MySql - longblob
	private byte[] image;

	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(String firstName, String lastName, String email, String password, LocalDate dob, double regAmount,
			Role userRole) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.dob = dob;
		this.regAmount = regAmount;
		this.userRole = userRole;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public double getRegAmount() {
		return regAmount;
	}

	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}

	public Role getUserRole() {
		return userRole;
	}

	public void setUserRole(Role userRole) {
		this.userRole = userRole;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", dob="
				+ dob + ", regAmount=" + regAmount + ", userRole=" + userRole + "]";
	}

}
