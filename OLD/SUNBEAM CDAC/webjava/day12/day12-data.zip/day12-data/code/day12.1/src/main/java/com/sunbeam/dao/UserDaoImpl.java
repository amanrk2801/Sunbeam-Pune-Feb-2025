package com.sunbeam.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sunbeam.entities.User;

@Repository //mandatory cls level annotation to specify following 
//is spring bean containing DAL
public class UserDaoImpl implements UserDao {
	//depcy - autowired byType , using Field level D.I
	@Autowired 
	private SessionFactory factory;

	@Override
	public User authenticateUser(String email1, String password1) {
		
		String jpql="select u from User u where u.email=:em and u.password=:pass";
		
		return factory.getCurrentSession()
				.createQuery(jpql,User.class)
				.setParameter("em", email1)
				.setParameter("pass", password1)
				.getSingleResult();
	}

}
