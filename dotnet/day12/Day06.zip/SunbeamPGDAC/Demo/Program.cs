namespace Demo
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();
            builder.Services.AddCors((services) => {

                services.AddPolicy("policy1", (policy) => {
                    policy.WithOrigins("sunbeaminfo.in")
                          .WithMethods("GET")
                          .WithHeaders("*");
                });

                services.AddPolicy("policy2", (policy) => {
                    policy.WithOrigins("bonaventuresystems.com")
                          .WithMethods("GET,POST")
                          .WithHeaders("Content-Type");
                });

                services.AddPolicy("policy3", (policy) => {
                    policy.WithOrigins("*")
                          .WithMethods("*")
                          .WithHeaders("*");
                });


            });

            var app = builder.Build();


            app.UseRouting();
            app.UseCors();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
