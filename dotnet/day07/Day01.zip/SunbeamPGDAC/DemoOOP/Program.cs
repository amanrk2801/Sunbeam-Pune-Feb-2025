﻿namespace DemoOOP
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("1: PDF, 2 :DOCX, 3: TXT");
            int choice  = Convert.ToInt32(Console.ReadLine());

            ReportFactory reportFactory = new ReportFactory();

            Report report = reportFactory.GetSomeReport(choice);
            report.GenerateReport();



            Console.ReadLine();
        }

      
    }

    public class ReportFactory
    {
        public Report GetSomeReport(int choice)
        {
            if (choice == 1)
            {
                return new PDF();
            }
            else if(choice == 2)
            {
                return new DOCX();
            }
            else
            {
                return new TXT();
            }
        }
    }

    public abstract class Report
    {
        protected abstract void Create();
        protected abstract void Parse();
        protected abstract void Validate();
        protected abstract void Save();
        public virtual void GenerateReport()
        {
            Create();
            Parse();
            Validate();
            Save();
        }
    }

    public abstract class SpecialReport : Report
    {
        protected abstract void ReValidate();
        public override void GenerateReport()
        {
            Create();
            Parse();
            Validate();
            ReValidate();
            Save();
        }
    }

    public class TXT : SpecialReport
    {
        protected override void Create()
        {
            Console.WriteLine("TXT Created");
        }

        protected override void Parse()
        {
            Console.WriteLine("TXT Parsed");
        }

        protected override void Validate()
        {
            Console.WriteLine("TXT Validated");
        }

        protected override void ReValidate()
        {
            Console.WriteLine("TXT RE-Validated");
        }

        protected override void Save()
        {
            Console.WriteLine("TXT Saved");
        }


    }

    public class PDF : Report
    {
        protected override void  Create()
        {
            Console.WriteLine("PDF Created");
        }

        protected override void Parse()
        {
            Console.WriteLine("PDF Parsed");
        }

        protected override void Validate()
        {
            Console.WriteLine("PDF Validated");
        }

        protected override void Save()
        {
            Console.WriteLine("PDF Saved");
        }

       
    }


    public class DOCX : Report
    {
        protected override void Create()
        {
            Console.WriteLine("DOCX Created");
        }

        protected override void Parse()
        {
            Console.WriteLine("DOCX Parsed");
        }

        protected override void Validate()
        {
            Console.WriteLine("DOCX Validated");
        }

        protected override void Save()
        {
            Console.WriteLine("DOCX Saved");
        }

     
    }


}
