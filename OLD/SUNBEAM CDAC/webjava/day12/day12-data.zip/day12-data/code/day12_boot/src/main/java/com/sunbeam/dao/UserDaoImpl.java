package com.sunbeam.dao;

import javax.persistence.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sunbeam.entities.User;

@Repository //mandatory cls level annotation to specify following 
//is spring bean containing DAL
public class UserDaoImpl implements UserDao {
	//depcy - autowired byType , using Field level D.I
	@Autowired // OR @PersistenceContext
	private EntityManager entityManager;//super i/f of Session

	@Override
	public User authenticateUser(String email1, String password1) {
		
		String jpql="select u from User u where u.email=:em and u.password=:pass";
		
		return entityManager //factory.getCurrentSession()
				.createQuery(jpql,User.class)
				.setParameter("em", email1)
				.setParameter("pass", password1)
				.getSingleResult();
	}

}
