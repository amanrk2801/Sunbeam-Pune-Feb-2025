package com.app.pages;

import static com.app.utils.DBUtils.closeConnection;
import static com.app.utils.DBUtils.openConnection;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class LoginServlet
 */


public class DBConnectionManager extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	public void init() throws ServletException {
		try {
			System.out.println("in init");
			System.out.println("cfg "+getServletConfig());
			System.out.println("ctx - "+getServletContext());
			//get servlet config
			ServletConfig config=getServletConfig();
			//accessing init params
			String url=config.getInitParameter("db_url");
			String userName=config.getInitParameter("user_name");
			String password=config.getInitParameter("password");	
			// open connection
			openConnection(url,userName,password);			
		} catch (Exception e) {
			System.out.println(e);		
			throw new ServletException("err in init of " + getClass(), e);
		}
	}

	

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			System.out.println("in destroy");			
			closeConnection();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	}
