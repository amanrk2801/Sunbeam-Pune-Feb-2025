package com.sunbeam.dao;

import com.sunbeam.entities.Employee;
import org.hibernate.*;
import static com.sunbeam.utils.HibnernateUtils.getFactory;

import java.io.Serializable;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public String insertEmpDetails(Employee employee) {
		String mesg="adding emp details failed!!!!";
		// 1. Get session from SF
		Session session=getFactory().getCurrentSession();
		//2. Begin a Tx
		Transaction tx=session.beginTransaction();
		try {
			Serializable empId = session.save(employee);
			//=> success
			tx.commit();
			mesg="added emp details with ID"+empId;
		} catch (RuntimeException e) {
			//=> failure -> rollback tx
			if(tx != null)
				tx.rollback();
			//re throw the SAME exception to the caller
			throw e;
		}
		return mesg;
	}

}
