package com.sunbeam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sunbeam.service.RestaurantService;

@Controller
@RequestMapping("/restaurants")
public class RestaurantController {
	//depcy
	@Autowired
	private RestaurantService restaurantService;
	
 public RestaurantController() {
	System.out.println("in ctor "+getClass());
}
 /*  Request hadnling method
	 * URL - http://host:port/ctx_path/restaurants/list
	 * Method - GET
	 * Payload - none
	 * Resp - dyn resp - list of restaurants
	 */
     @GetMapping("/list")
     public String listAllRestaurants(Model map) {
    	 System.out.println("in list restaurants "+map);
    	 //add result under model attribute
    	 map.addAttribute("restaurant_list", restaurantService.getAllRestaurants());
    	 return "restaurants/list"; //AVN - /WEB-INF/views/restaurants/list.jsp
     }
}
