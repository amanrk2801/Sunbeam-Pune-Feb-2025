package com.sunbeam.tester;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

//import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.SessionFactory;

import com.sunbeam.dao.RestaurantDao;
import com.sunbeam.dao.RestaurantDaoImpl;
import com.sunbeam.dao.UserDao;
import com.sunbeam.dao.UserDaoImpl;
import com.sunbeam.entities.Restaurant;
import com.sunbeam.entities.User;
import com.sunbeam.entities.UserRole;

public class AddNewRestaurant {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) // SF -> DBCP
		{
			// create dao instance
			RestaurantDao dao = new RestaurantDaoImpl();
			System.out.println("Enter restaurant details - name,  address,  city,  description");
			Restaurant restaurant=new Restaurant(sc.next(), sc.next(), sc.next(), sc.next());
				// invoker dao's method
			System.out.println(dao.addRestaurant(restaurant));
		} // JVM - sc.close() , sf.close() => cleaning up of DBCP
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
