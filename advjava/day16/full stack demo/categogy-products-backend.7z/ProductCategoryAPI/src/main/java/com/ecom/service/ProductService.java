package com.ecom.service;

import java.util.List;

import com.ecom.dto.ApiResponse;
import com.ecom.dto.ProductDTO;

public interface ProductService {
	ApiResponse addProduct(ProductDTO dto);

	List<ProductDTO> getProducts();

	ApiResponse deleteProduct(Long productId);

	ProductDTO getProduct(Long productId);

	ApiResponse updateProduct(Long productId, ProductDTO product);
}
