package com.sunbeam.dependent;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sunbeam.dependency.Coach;
import com.sunbeam.dependency.Teacher;

//singleton n eager
@Component("my_school") 
//<bean id="my_school" class="com.sunbeam.dependent.PublicSchool"/>
public class PublicSchool implements School {
	//science teacher
	@Autowired(required = false)// - default  => byType
	@Qualifier("sc123") //=> byName
	private Teacher subjectTeacher;// Mandatory  depcy
	//swimming coach
	@Autowired
	@Qualifier("swimmingCoach")
	private Coach sportsCoach; // Mandatory depcy

	public PublicSchool() {
		System.out.println("in ctor " + getClass());
	}

	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}

	@Override
	public void organizeSportsEvent() {
		System.out.println("organizing sports event ");
		System.out.println(sportsCoach.getDailyWorkout());

	}

	// add custom init method
	@PostConstruct
	public void anyInit() {
		System.out.println("in init " + subjectTeacher + " " + sportsCoach);// both - not null
	}

	// add destroy
	@PreDestroy
	public void anyDestroy() {
		System.out.println("in destroy " + subjectTeacher);// not null
	}

}
