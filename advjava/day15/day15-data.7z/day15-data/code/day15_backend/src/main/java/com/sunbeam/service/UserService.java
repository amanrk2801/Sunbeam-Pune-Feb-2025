package com.sunbeam.service;

import com.sunbeam.dto.AuthRequest;
import com.sunbeam.dto.AuthRespDTO;

public interface UserService {
//sign in
	AuthRespDTO authenticate(AuthRequest dto);
}
