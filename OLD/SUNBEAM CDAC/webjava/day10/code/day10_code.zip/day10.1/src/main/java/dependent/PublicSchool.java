package dependent;

import dependency.Teacher;

public class PublicSchool implements School {	
	private Teacher subjectTeacher;//=new MathsTeacher();//depcy 
	
	public PublicSchool() {
		System.out.println("in def ctor of "+getClass());
	}
	//constructor based D.I
	public PublicSchool(Teacher myTeacher) {
		this.subjectTeacher=myTeacher;
		System.out.println("In constructor - " + getClass()+" "+subjectTeacher);
	}

	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}
	//add init
	public void anyInit() {
		System.out.println("in init "+subjectTeacher);//not null
	}
	//add destroy
	public void anyDestroy() {
		System.out.println("in destroy "+subjectTeacher);//not null
	}

	

}
