package com.myswiggy.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.myswiggy.custom_exceptions.ResourceNotFoundException;
import com.myswiggy.dao.FoodItemDao;
import com.myswiggy.dao.OrderDao;
import com.myswiggy.dao.RestaurantDao;
import com.myswiggy.dao.UserDao;
import com.myswiggy.dto.FoodItemDTO;
import com.myswiggy.dto.FoodOrderItem;
import com.myswiggy.dto.OrderLineDTO;
import com.myswiggy.dto.OrderRequestDTO;
import com.myswiggy.dto.OrderRespDTO;
import com.myswiggy.dto.RestaurantRespDTO;
import com.myswiggy.dto.UserRespDTO;
import com.myswiggy.entities.DeliveryAddress;
import com.myswiggy.entities.FoodItem;
import com.myswiggy.entities.Order;
import com.myswiggy.entities.OrderLine;
import com.myswiggy.entities.OrderStatus;
import com.myswiggy.entities.Restaurant;
import com.myswiggy.entities.User;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class OrderServiceImpl implements OrderService {
	private final OrderDao orderRepository;
	private final UserDao userRepository;
	private final ModelMapper modelMapper;
	private final RestaurantDao restaurantRepository;
	private final FoodItemDao foodItemDao;

	@Override
	public OrderRespDTO saveOrderDetails(OrderRequestDTO orderDetails) {
		/*
		 * i/p - List<FoodOrderItem- foodItemId,quantity> and userId n restaurantId
		 * Development steps 1. Create Order entity - orderStatus : NEW , delivery
		 * address , customerId Later add validation of customer id from Customer MS DB
		 * action - 1 rec inserted in orders table n 1 in delivery adr table 2. Get
		 * order id. 3. From list of FoodOrderItem - create list of OrderLine 4.
		 * Establish bi dir association - Order 1<--->* OrderLine DB action - recs
		 * inserted in order_lines table with FK set 5. generate n return order resp dto
		 */
		// 1. Validate n get customer details
		User customer = userRepository.findById(orderDetails.getCustomerId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid customer id"));
		// 2. Validate n get restaurant details by its id
		Restaurant restaurant = restaurantRepository.findById(orderDetails.getRestaurantId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid restaurant id !!!"));

		// 3. create new Order entity (transient)
		Order newOrder = new Order();
		// 4. set order status
		newOrder.setOrderStatus(OrderStatus.NEW);
		// 5. get delivery address from DTO n map it to DeliveryAddress entity
		DeliveryAddress address = modelMapper.map(orderDetails.getDeliveryAddress(), DeliveryAddress.class);
		// establish association : Order 1----->1 DeliveryAddress
		// newOrder.setAddress(address);
		// 6. Assign customer n restaurant
		newOrder.setCustomer(customer);
		newOrder.setRestaurant(restaurant);
		// 7. Set Promised delivery time (+30 minutes)
		newOrder.setDeliveryDateTime(LocalDateTime.now().plusMinutes(30));
		// 8. save order entity
		Order savedOrder = orderRepository.save(newOrder);
		// 9. create n save order lines
		List<OrderLineDTO> orderLines = 
				saveOrderLines(savedOrder, orderDetails.getFoodOrderItems());
		// 10. Create n return order response dto
		return generateOrderResp(savedOrder, orderLines, modelMapper.map(customer, UserRespDTO.class),
				restaurant.getName());
	}

	private List<OrderLineDTO> saveOrderLines(Order order, List<FoodOrderItem> orderItems) {
		List<OrderLineDTO> orderLines = orderItems
				.stream()
				.map(orderItem -> mapToOrderLine(orderItem, order))
				.collect(Collectors.toList());
		return orderLines;
	}

	// map FoodOrderItem -> OrderLine
	private OrderLineDTO mapToOrderLine(FoodOrderItem orderItem, Order order) {

		/*
		 * FoodOrderItem private Long foodItemId; private int quantity;
		 * 
		 * OrderLine - private int quantity; 
		 * private int subTotal; 
		 * private Order order;
		 * private String foodItemName
		 * 
		 */
		// fetch food item details by food item id
		FoodItem foodItem = foodItemDao
				.findById(orderItem.getFoodItemId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid food item id !!!"));
		// Create order line entity
		OrderLine orderLine = new OrderLine();
		// set food item name
		orderLine.setFoodItem(foodItem);
		// set order quantity for this order item
		orderLine.setQuantity(orderItem.getQuantity());
		// compute n assign sub total
		orderLine.setSubTotal(foodItem.getPrice() * orderItem.getQuantity());
		// establish bi dir association , Order 1<---->* OrderLine , using a helper
		// method
		order.addOrderLine(orderLine);
		// update total order amount
		order.setOrderAmount(order.getOrderAmount() + orderLine.getSubTotal());
		// map OrderLine entity -> DTO (for adding it in the response)
		 OrderLineDTO dto = modelMapper.map(orderLine, OrderLineDTO.class);
		 dto.setFoodItemName(foodItem.getItemName());
		 return dto;
	}

	private OrderRespDTO generateOrderResp(Order order, List<OrderLineDTO> orderLines, UserRespDTO user,
			String restaurantName) {
		/*
		 * private Long orderId;
		 * 
		 * private OrderStatus orderStatus;
		 * 
		 * private int orderAmount;
		 * 
		 * private LocalDateTime orderDateTime;
		 * 
		 * private LocalDateTime deliveryDateTime;
		 * 
		 * private int deliveryCharges;
		 * 
		 * private List<FoodItemDTO> foodItemList; private String restaurantName;
		 * private String userName;
		 */
		// map Order -> OrderRespDTO
		OrderRespDTO respDTO = modelMapper.map(order, OrderRespDTO.class);
		// set OrderLine DTOs
		respDTO.setOrderLineList(orderLines);
		// set restaurant name
		respDTO.setRestaurantName(restaurantName);
		// set customer name
		respDTO.setCustomerName(user.getFirstName() + " " + user.getLastName());
		return respDTO;
	}

}
