﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;

namespace DemoEF
{

    [Table("Emp")]
    public  class Emp
    {
        [Key]
        public int No { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }

    [Table("Trainer")]
	public class Trainer
	{
        [Column("TrainerID")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TrainerID { get; set; }

        [Column("TrainerName")]
        [StringLength(50)]
        public string TrainerName { get; set; }

        public List<Subject> Subjects { get; set; }
    }


    [Table("Subject")]
    public class Subject
    {
        [Column("SubjectID")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SubjectID { get; set; }

        [Column("SubjectTitle")]
        [StringLength(50)]
        public string SubjectTitle { get; set; }

        public List<Trainer> Trainers { get; set; }
    }

    public class SunbeamDBContext : DbContext
    {
        public DbSet<Emp> Emps { get; set; }
        public DbSet<Trainer> Trainers { get; set; }

        public DbSet<Subject> Subjects { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=SunbeamDB;Integrated Security=True;");
        }
    }
}
