package com.sunbeam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller //spring bean - req handling logic
//singleton n eager
public class HelloWorldController {
	public HelloWorldController() {
		System.out.println("in ctor of "+getClass());
	}
	@RequestMapping("/hello")
	//key - /hello
	//value - com.sunbeam.controller.HelloWorldController.renderHello
	public String renderHello() {
		System.out.println("in render hello");
		return "/welcome";//rets LVN to D.S ->
		//V.R -> AVN -/WEB-INF/views/welcome.jsp
	}
	//add req handling method for rendering index page
	//URL - http://host:port/ctx_path/ , method=GET
	@GetMapping("/")
	public String renderIndexPage() {
		System.out.println("in render index page");
		return "/index";//AVN - /WEB-INF/views/index.jsp
	}
	
	
	

}
