package com.sunbeam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller //mandatory class level annotation to tell SC , 
//followoing is 
//spring bean  containing req handling logic.
//singleton n eager 
public class HomePageController {
	public HomePageController() {
		System.out.println("in ctor of "+getClass());
	}
	//add req handling method to render index page
	//URL - http://host:port/ctx_path/ , method=GET
	@GetMapping("/")
	public String renderIndexPage() {
		System.out.println("in render index page");
		return "/index";
	}
	/*
	 * Handler method rets LVN -> D.S -> V.R -> 
	 * AVN -/WEB-INF/views/index.jsp -> D.S
	 * D.S forwards the client to view layer (AVN)
	 */
	

}
