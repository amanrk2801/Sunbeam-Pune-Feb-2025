package com.sunbeam.dao;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sunbeam.entities.BlogPost;
import com.sunbeam.entities.Comment;
import com.sunbeam.entities.User;

public class CommentDaoImpl implements CommentDao {

	@Override
	public String postNewComment(Comment newComment, 
			Long commenterId, Long postId) {
		String mesg = "adding comment failed ....";
		// 1. get session from SF (getCurrentSession)
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
//3. get commenter from id
			User commenter=session.get(User.class, commenterId);
			//4. get blog post from its id
			BlogPost blogPost=session.get(BlogPost.class, postId);
			//5 validate 
			if(commenter != null && blogPost != null 
					&& commenterId != blogPost.getBlogger().getId()) {
				//6. establish uni dir asso Comment ---> Commenter
				newComment.setCommenter(commenter);
				//7 establish uni dir asso Comment ---> BlogPost
				newComment.setBlogPost(blogPost);
				//will have to explicitly persist - since NO cascading her e!
				session.persist(newComment);
				mesg="added new comment !";
			}
			tx.commit();//DML   - insert
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public List<Comment> getCommentsByPost(String postTitle) {
		List<Comment> comments = null;
		String jpql="select c from Comment c where c.blogPost.title=:title";
		// 1. get session from SF (getCurrentSession)
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			comments=session.createQuery(jpql,Comment.class)
					.setParameter("title",postTitle)
					.getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return comments;
	}

}
