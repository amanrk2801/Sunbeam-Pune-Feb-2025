package com.ecom.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.dto.ProductDTO;
import com.ecom.service.ProductService;

import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/products")
@CrossOrigin(origins = "http://localhost:3000")
@AllArgsConstructor
public class ProductController {
	
	private ProductService productService;
	
	/*
	 * URL - http://host:port/products
	 *  Method - GET
	 *   Payload - none 
	 *   Response - List<Product> 
	 */
	@GetMapping
	public ResponseEntity<?> getAllProducts() {
		System.out.println("in get all products");
		List<ProductDTO> products = productService.getProducts();
		if (products.isEmpty())
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		return ResponseEntity.ok(products);
	}
	
	
	/*
	 * Desc - Add new Product
	 *  URL - http://host:port/posts
	 * Method - POST 
	 * payload -Product DTO (product Id ,name,price , quantity) 
	 * Successful Resp - SC 201 + mesg (ApiResponse)
	 * Error resp - SC 400 , error mesg -wrapped in DTO(ApiResponse)
	 */
	@PostMapping
	public ResponseEntity<?> addProduct
	(@RequestBody ProductDTO dto) {
		System.out.println("in add product "+dto);	
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(productService.addProduct(dto));		
	}
	/*
	 * Desc - Get product by ID 
	 * URL - http://host:port/products/{productId} 
	 * Method - GET 
	 * Payload - product id (using URI template variable) 
	 * Response - ProductDTO
	 */
	@GetMapping("/{productId}")
	public ResponseEntity<?> getProductDetails(@PathVariable Long productId) {
		System.out.println("in get product" + productId);		
		return ResponseEntity.ok(productService.getProduct(productId));
		
	}
	/*
	 * Desc - update product details 
	 * URL - http://host:port/products/{productId}
	 * Method - PUT 
	 * Payload - product id (using URI template variable) + 
	 * Request Body - updated category details 
	 * Response - mesg wrapped in Api resp
	 */
	@PutMapping("/{productId}")
	public ResponseEntity<?> updateProductDetails(@RequestBody ProductDTO product, 
			@PathVariable Long productId) {
		System.out.println("in update " + productId + " " + product);
		return ResponseEntity.ok
				(productService.updateProduct(productId, product));
	}

	/*
	 * Desc - delete product 
	 * URL - http://host:port/products/{productId} 
	 * Method - DELETE 
	 * Payload - product id (using URI template variable) 
	 * Response - ApiResponse DTO
	 */
	@DeleteMapping("/{productId}")
	public ResponseEntity<?> deleteProductDetails(@PathVariable Long productId) {
		System.out.println("in hard delete product" + productId);		
		return ResponseEntity.ok(productService.deleteProduct(productId));
		
	}

}
