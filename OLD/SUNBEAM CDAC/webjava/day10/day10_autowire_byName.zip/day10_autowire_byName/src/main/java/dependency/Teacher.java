package dependency;

public interface Teacher {
	void teach();
}
