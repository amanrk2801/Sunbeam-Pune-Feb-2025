package com.myswiggy.entities;

public enum OrderStatus {
	NEW, PROCESSING, DELIVERED, CANCELLED
}
