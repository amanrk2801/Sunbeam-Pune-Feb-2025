package com.sunbeam.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sunbeam.entities.BlogPost;
import com.sunbeam.entities.User;
import com.sunbeam.service.BlogPostService;
import com.sunbeam.service.CategoryService;

@Controller
@RequestMapping("/blogger")
public class BloggerController {
	@Autowired
	private BlogPostService blogPostService;
	@Autowired
	private CategoryService categoryService;

	// add a method to get all posts 
	// name
	@GetMapping("/home")
	public String getAllPosts(Model map) {
		map.addAttribute("blogs_list", blogPostService.getAllPosts());
		return "/blogger/home";
	}

	// add a method to show form to create a new blog
	@GetMapping("/new_blog")
	public String showFormNewBlog(Model map, BlogPost post) {
		map.addAttribute("all_categories", categoryService.getAllCategories());
		return "/blogger/new_blog";
	}

	// add a method to process form to create a new blog
	@PostMapping("/new_blog")
	public String processFormNewBlog(RedirectAttributes flashMap, BlogPost post, HttpSession session) {
		System.out.println(post);
		System.out.println(post.getBlogCategory());
		User author = (User) session.getAttribute("user_details");
		post.setBlogger(author);
		flashMap.addFlashAttribute("message", blogPostService.createNewBlog(post));
		return "redirect:/blogger/home";
	}

	// add a method to show form for update blog contents
	// http:host:port/ctx/blogger/edit_post?id=blogId
	@GetMapping("/edit_post")
	public String showUpdateForm(@RequestParam Long postId,
Model map) {
		System.out.println("in update form " + postId);
		map.addAttribute("blog", blogPostService.getBlogDetails(postId));
		return "/blogger/edit_post";
	}

	// add a method to update blog contents
	// http:host:port/ctx/blogger/edit_post?id=blogId
	@PostMapping("/edit_post")
	public String processUpdateForm(@RequestParam Long postId, 
			@RequestParam String content,
			RedirectAttributes flashMap) {
		System.out.println("in process update form " + postId + " content");
		flashMap.addFlashAttribute("message", blogPostService.updateBlogContents(postId, content));
		return "redirect:/blogger/home";
	}

	// add a method to delete blog contents
	// http:host:port/ctx/blogger/delete_post?postId=blogId
	@GetMapping("/delete_post")
	public String deleteBlogDetails(@RequestParam Long postId, RedirectAttributes flashMap) {
		System.out.println("in delete blog " + postId);
		flashMap.addFlashAttribute("message", blogPostService.deleteBlogPost(postId));
		return "redirect:/blogger/home";
	}

}
