package com.sunbeam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller // mandatory class level annotation
//- to declare a spring bean , containing req handling logic (P.L)
//request handling controller - a.k.a - Handler
//singleton n eager
public class HelloWorldController {
//added only for debugging
	public HelloWorldController() {
		System.out.println("in constr of " + getClass());
	}
	/*
	 * SC creates HandlerMapping bean @ web app startup
	 * singleton n eager
	 * Map (HashMap)
	 * Key - value of the @RequestMapping - "/"
	 * Value - Fully qualified Handler cls Name+methodName - 
	 *  com.sunbeam.controller.HelloWorldController.renderIndexPage
	 */
	@RequestMapping(value="/") //mandatory method level annotation
	//to declare rq handling method - service method of HttpServlet
	//can intercept ANY HTTP request - GET |POST|PUT|DELETE ....
	public String renderIndexPage() {
		System.out.println("in render index page....");
		//return LVN - logical | forward view name
		return "index";//AVN - /WEB-INF/views/index.jsp
	}

}
