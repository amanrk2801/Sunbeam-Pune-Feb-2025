package com.myswiggy.dto;

import lombok.Getter;
import lombok.Setter;

@Getter 
@Setter 
public class RestaurantReqDTO {
	private String name;
	private String address;
	private String city;
	private String description;
	
}
