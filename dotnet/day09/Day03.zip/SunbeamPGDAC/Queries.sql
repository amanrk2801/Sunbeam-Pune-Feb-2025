﻿create table Emp(No int primary key identity, 
				 Name varchar(50), 
				 Address varchar(50),
				 Age int);