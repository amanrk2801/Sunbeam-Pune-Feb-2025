import React from 'react';

const FooterComponent = () => {
  return (
    <>
      <footer className='footer'>
        <span>Copyright @ Full Stack Developers</span>
      </footer>
    </>
  );
};

export default FooterComponent;
