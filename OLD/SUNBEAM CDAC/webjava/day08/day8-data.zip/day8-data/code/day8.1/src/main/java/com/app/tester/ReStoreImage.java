package com.app.tester;

import org.hibernate.SessionFactory;

import com.app.dao.UserDao;
import com.app.dao.UserDaoImpl;
import com.app.entities.Role;
import com.app.entities.User;

import static com.app.utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

public class ReStoreImage {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory();
				Scanner sc = new Scanner(System.in)) {
			// create dao
			UserDao dao = new UserDaoImpl();// up casting
			System.out.println("Enter filename along with path");
			String fileName=sc.nextLine();
			System.out.println("Enter user email");
			// invoke dao's method
			System.out.println(dao.restoreImage(fileName, sc.next()));
		} // JVM -sc.close , sf.close() -> DBCP clened up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
