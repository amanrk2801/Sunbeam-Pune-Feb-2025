package com.sunbeam.dao;

import com.sunbeam.entities.User;
import com.sunbeam.entities.UserRole;

import org.apache.commons.io.FileUtils;
import org.hibernate.*;
import static com.sunbeam.utils.HibernateUtils.getFactory;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public class UserDaoImpl implements UserDao {

	@Override
	public String signUpUser(User newUser) {
		// newUser - TRANSIENT - exists only in heap
		String mesg = "Registration failed!!!!!!";
		// 1. Get Session from SF
		/*
		 * API of SessionFactory public Session getCurrentSession() throws
		 * HibernateExcetion - SF checks if there is an existing session bound to
		 * current thread(main) - yes - rets existing - no - creates new session OR
		 * public Session openSession() throws HibernateExcetion
		 */
		Session session = getFactory().getCurrentSession();
		Session session2 = getFactory().getCurrentSession();
		System.out.println(session == session2);// t
		/*
		 * 2. Begin a Tx Session API public Transaction beginTransaction() throws
		 * HibernateExcetion
		 */
		Transaction tx = session.beginTransaction();
		System.out.println("is open " + session.isOpen() + " is connected " + session.isConnected());// t t
		try {
			/*
			 * 3. Session API for inserting a record - public void persist(Object
			 * trasientObjectRef) throws HibernateExcetion
			 */
			session.persist(newUser); // newUser : PERSISTENT
			System.out.println(newUser.getUserId());// id - not null - generated
			// => success
			tx.commit(); /*
							 * What does Hibernate do upon commit ? 1. session.flush() - Triggers auto dirty
							 * checking - Synchronizes state of L1 cache with DB - new entity - insert -
							 * existing entity with updated state - update - entity marked for removal -
							 * delete 2. session.close() - L1 cache is destroyed - Pooled out DB connection
							 * rets to DBCP
							 */
			mesg = "User signed up with ID" + newUser.getUserId();
		} catch (RuntimeException e) {
			// => failure
			if (tx != null)
				tx.rollback();
			/*
			 * What does Hibernate do upon rollback ? 1. session.close() - L1 cache is
			 * destroyed - Pooled out DB connection rets to DBCP
			 * 
			 */
			// re throw the exception to the caller
			throw e;
		}
		System.out.println("is open " + session.isOpen() + " is connected " + session.isConnected());// f f
		// newUser - DETACHED (from L1 cache)
		return mesg;
	}

	@Override
	public User getUserDetailsById(Long userId) {
		User user = null; // doesn't exist in heap
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			user = session.get(User.class, userId);// select
			user = session.get(User.class, userId);// cache
			user = session.get(User.class, userId);// cache
			// user - PERSISTENT
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		// user - DETACHED
		return user;
	}

	@Override
	public List<User> getAllUsers() {
		List<User> users = null;
		String jpql = "select u from User u";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {

			users = session.createQuery(jpql, User.class).getResultList();
			// users : List of PERSISTENT entities
			tx.commit();// L1 cache is destroyed n db cn rets to the DBCP
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return users;// users : List of DETACHED entities
	}

	@Override
	public List<User> getUserDetailsByRoleAndDoB(UserRole role1, LocalDate dob1) {
		List<User> users = null;
		String jpql = "select u from User u where u.userRole = :role and u.dob > :dt";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class) // Query
					.setParameter("role", role1) // set 1st named param
					.setParameter("dt", dob1) // set 2nd named param
					.getResultList();// exec -> ORM -> List of PERSISTENT entities
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return users;// list of detached entities
	}

	@Override
	public List<String> getUserLastNamesByRole(UserRole userRole1) {
		List<String> lastNames = null;
		String jpql = "select u.lastName from User u where u.userRole=:rl";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			lastNames = session.createQuery(jpql, String.class).setParameter("rl", userRole1).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return lastNames;
	}

	@Override
	public List<User> getDetailsByRole(UserRole role) {
		List<User> users = null;
		String jpql = "select new com.sunbeam.entities.User(u.firstName,u.lastName,u.dob) "
				+ "from User u where u.userRole=:rl";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("rl", role).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return users;
	}

	@Override
	public String changePassword(String email1, String oldPwd1, String newPwd1) {
		String mesg = "Password updation failed.....";
		// get user by em n pass
		String jpql = "select u from User u where u.email=:em and u.password=:pass";
		User user = null;
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			user = session.createQuery(jpql, User.class).setParameter("em", email1).setParameter("pass", oldPwd1)
					.getSingleResult();// throws NoResultExc - in case of no result !
			// => success - user : PERSISTENT
			user.setPassword(newPwd1);// modifying state of persistent entity
			// session.evict(user);//user - DETACHED
			tx.commit();
			mesg = "changed password !";
			/*
			 * session.flush() -> dirty chcking -> DML - update session.close() -> user -
			 * DETACHED from L1 cache
			 */
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		user.setPassword("1234567890");// detached state -> is not reflected in DB.
		return mesg;
	}

	@Override
	public String applyDiscount(LocalDate date, UserRole role, double discountAmount) {
		String mesg = "Failed to apply discount!!!!!!!!!!";
		String jpql = "update User u set u.subscriptionAmount=u.subscriptionAmount-:disc where u.userRole=:role and u.dob < :date";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			int updateCount = session.createMutationQuery(jpql) // Query - DMLs
					.setParameter("disc", discountAmount).setParameter("role", role).setParameter("date", date)
					.executeUpdate();
			tx.commit();
			mesg = "No of users - updated " + updateCount;
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public String deleteUserDetailsById(Long userId) {
		String mesg = "deletion failed !!!!!!!";
		User user = null;
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			// 3. Get user details by id
			user = session.get(User.class, userId);
			if (user != null) {
				// user - PERSISTENT - exists in L1 n DB
				session.remove(user);// user - REMOVED - marked for removal !
				mesg = "user details deleted...";
			}
			tx.commit();
			/*
			 * session.flush -> dirty chking -> DML - delete - removed from DB session.close
			 * -> L1 cache is destroyed - removed from L1 , db cn rets to the DBCP
			 */
			// user - TRANSIENT
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return mesg;
	}// user - Marked for GC -> does not exist !

	@Override
	public String saveImage(String filePath, Long userId) throws IOException {
		String mesg = "Saving image failed !!!!!!!!!";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			// 3. Get user details by id
			User user = session.get(User.class, userId);
			if (user != null) {
				// user - persistent
				// validate - read file till EOF - byte[]
				// validate file
				File file = new File(filePath);
				if (file.isFile() && file.canRead()) {
					// valid file
					user.setImage(FileUtils.readFileToByteArray(file));
					// modifying state of persistent entity
					mesg = "saved image...";
				}

			}
			tx.commit();// session.flush -> dirty checking - DML : update -> session.close
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public String restoreImage(String filePath, String userEmail) throws IOException{
		String mesg="restoring image failed ....";
		String jpql="select u from User u where u.email=:em";
		// 1. Get Session from SessionFactory
				Session session=getFactory().getCurrentSession();
				//2. Begin Tx
				Transaction tx=session.beginTransaction();
				try {
					User user=session.createQuery(jpql, User.class)
							.setParameter("em", userEmail)
							.getSingleResult();
					//user - persistent
					//get image 
					byte[] imageData=user.getImage();
					if(imageData != null)
					{
						FileUtils.writeByteArrayToFile(new File(filePath),
								imageData);
						mesg="restored image from DB";
					}
					tx.commit();
				} catch (RuntimeException e) {
					if(tx != null)
						tx.rollback();
					//re throw the exception to the caller
					throw e;
				}
		return mesg;
	}
	
	

}
