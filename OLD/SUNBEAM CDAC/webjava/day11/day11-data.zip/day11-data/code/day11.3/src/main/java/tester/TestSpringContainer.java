package tester;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sunbeam.dependent.PublicSchool;

public class TestSpringContainer {

	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("bean_config.xml")) {
			System.out.println("SC up n running .....");
			// get ready to use public school bean n manage academics (B.L)
			PublicSchool school1 =
					ctx.getBean("my_school", PublicSchool.class);
			PublicSchool school2 =
					ctx.getBean("my_school", PublicSchool.class);
			System.out.println(school1==school2);//t
			//Invoke B.L using injected dependencies !
			school1.manageAcademics();
			school1.organizeSportsEvent();
		
			
		} // JVM ctx.close() ->
		//SC -> are there any singleton beans -> is there any
			// destroy -> yes -> invokes custom destroy method -> marks spring bean for GC
		//no - simply marks bean instance for GC
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
