package com.myswiggy.service;

import com.myswiggy.dto.ApiResponse;
import com.myswiggy.dto.FoodItemDTO;
import com.myswiggy.dto.FoodItemReqDTO;
import com.myswiggy.dto.RestaurantMenuDetails;
import com.myswiggy.entities.FoodItem;

public interface FoodItemService {
	FoodItemDTO getFoodItemDetails(Long foodItemId);

	String updateFoodItemDetails(Long id, String desc, double price);

	ApiResponse addFoodItem(FoodItemReqDTO dto);
	
			
}
