package com.sunbeam.dependent;

import com.sunbeam.dependency.Coach;
import com.sunbeam.dependency.Teacher;

public class PublicSchool implements School {
	private Teacher subjectTeacher;// =new MathsTeacher();
	private Coach sportsCoach;

	private PublicSchool(Teacher myTeacher, Coach coach) {
		this.subjectTeacher = myTeacher;
		this.sportsCoach=coach;
		System.out.println("In constructor - " + getClass());
	}

//B.L
	@Override
	public void manageAcademics() {
		System.out.println("Managing academics here -");
		subjectTeacher.teach();
	}

	// B.L - sports event
	@Override
	public void organizeSportsEvent() {
		System.out.println("Organizing sports event ....");
		System.out.println(sportsCoach.getDailyWorkout());

	}

	// custom init method
	public void anyInit() {
		System.out.println("in init of " + getClass() + " depcy " + subjectTeacher + " depcy " + sportsCoach);// not
																												// null
	}

	// custom destroy method
	public void anyDestroy() {
		System.out.println("in destroy of " + getClass() + " depcy " + subjectTeacher + " depcy " + sportsCoach);// not
																													// null
	}

	// Factory method - D.I
	public static PublicSchool myFactoryMethod(Teacher mySubjectTeacher,
			Coach myCoach) {
		System.out.println("in factory method "+mySubjectTeacher+" "+myCoach);//not null
		return new PublicSchool(mySubjectTeacher,myCoach);
	}

}
