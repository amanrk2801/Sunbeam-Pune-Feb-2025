﻿using System.Diagnostics;

namespace DemoThreading
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ID of Main Thread = {0}", Thread.CurrentThread.ManagedThreadId);

            Stopwatch sw = new Stopwatch();
            sw.Start();

            #region Multiple Tasks - Multiple Threads - Multiple CPUs

            //List<Task> tasks = new List<Task>();

            //for (int i = 0; i < 500; i++)
            //{

            //    Task task = new Task(DoSomethingImportant);
            //    tasks.Add(task);
            //    task.Start();
            //}


            //Task.WaitAll(tasks.ToArray());

            #endregion

            #region Multiple Threads - Single CPU Concept: 194 MS
            //List<Thread> threads = new List<Thread>();

            //for (int i = 0; i < 500; i++)
            //{
            //    //Thread thread = new Thread(new ThreadStart(DoSomethingImportant));

            //    Thread thread = new Thread(DoSomethingImportant);
            //    threads.Add(thread);

            //    thread.Start();
            //}


            //foreach (var thread in threads)
            //{
            //    thread.Join();
            //}
            #endregion

            #region Single Thread - Single CPU Concept: 1028 MS

            //for (int i = 0; i < 500; i++)
            //{
            //    DoSomethingImportant();
            //}
            #endregion



            sw.Stop();

            Console.WriteLine("Time taken = {0}", sw.ElapsedMilliseconds);
            Console.ReadLine();

        }
        
        public static void DoSomethingImportant()
        {
            Console.WriteLine("ID of Thread being used = {0}",Thread.CurrentThread.ManagedThreadId);
            for (int i = 0; i < 1000; i++)
            {
                for(int j = 0; j < 10000; j++) 
                {
                    //Do Nothing
                }
            }
        }
    }


}
