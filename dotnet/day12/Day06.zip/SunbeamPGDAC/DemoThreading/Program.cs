﻿using System.Diagnostics;

namespace DemoThreading
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ID of Main Thread = {0}", Thread.CurrentThread.ManagedThreadId);

            Stopwatch sw = new Stopwatch();
            sw.Start();

            #region Understand Explicit Parallel Programming

            #region Multiple Tasks - Multiple Threads - Multiple CPUs

            //List<Task> tasks = new List<Task>();

            //for (int i = 0; i < 500; i++)
            //{

            //    Task task = new Task(DoSomethingImportant);
            //    tasks.Add(task);
            //    task.Start();
            //}


            //Task.WaitAll(tasks.ToArray());

            #endregion

            #region Multiple Threads - Single CPU Concept: 194 MS
            //List<Thread> threads = new List<Thread>();

            //for (int i = 0; i < 500; i++)
            //{
            //    //Thread thread = new Thread(new ThreadStart(DoSomethingImportant));

            //    Thread thread = new Thread(DoSomethingImportant);
            //    threads.Add(thread);

            //    thread.Start();
            //}


            //foreach (var thread in threads)
            //{
            //    thread.Join();
            //}
            #endregion

            #region Single Thread - Single CPU Concept: 1028 MS

            //for (int i = 0; i < 500; i++)
            //{
            //    DoSomethingImportant();
            //}
            #endregion

            #endregion

            #region Understand Implicit Parallel Programming

            string []allFileNames = Directory.GetFiles("C:\\Windows\\System32");

            #region Understand Parallel For Each
            //Time Taken : 274
            //foreach (string fileName in allFileNames)
            //{
            //    Console.WriteLine(fileName);
            //}


            //Time Taken : 204
            //Parallel.ForEach(allFileNames, (fileName) =>
            //                                {
            //                                    Console.WriteLine(fileName);
            //                                });
            #endregion

            #region Understand Parallel LINQ

            //Find PNG Files from all files.
            //Option 1: Simple For  Each
            //int counter = 0;
            //foreach (string fileName in allFileNames) { 
            //    if(fileName.Contains(".png"))
            //    {
            //        counter = counter + 1;
            //    }
            //}

            //Option 2:  LINQ
            //var counter = (from file in allFileNames
            //              where file.Contains(".png")
            //              select file).ToList().Count;


            //Option 3: Parallel LINQ
            //var counter = (from file in allFileNames.AsParallel()
            //               where file.Contains(".png")
            //               select file).ToList().Count;

            #endregion

            //Console.WriteLine("Total PNG Files = {0}", counter);



            #endregion

            sw.Stop();

            //Console.WriteLine("Time taken = {0}", sw.ElapsedMilliseconds);
            Console.WriteLine("Time taken = {0}", sw.ElapsedTicks);
            Console.ReadLine();



            //ForEach: Single Thread -Single CPU     66516

            //| 1B records/ 16B iterations 24Hr

            //LINQ    : Single Thread -Single CPU     57092

            //| 1B records/ 16B iterations 12Hr

            //PLINQ   : Multiple Thread -Multiple CPU 229866

            //| 1B records/ 16B iterations 2.5 Hr

        }

        public static void DoSomethingImportant()
        {
            Console.WriteLine("ID of Thread being used = {0}",Thread.CurrentThread.ManagedThreadId);
            for (int i = 0; i < 1000; i++)
            {
                for(int j = 0; j < 10000; j++) 
                {
                    //Do Nothing
                }
            }
        }
    }


}
