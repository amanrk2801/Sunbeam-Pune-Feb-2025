package com.sunbeam.controller;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sunbeam.service.BlogPostService;

@Controller
@RequestMapping("/blogger")
public class BloggerController {
	//depcy  - service layer i/f
	@Autowired
	private BlogPostService blogPostService;
	
	public BloggerController() {
		System.out.println("in ctor "+getClass()+" "+blogPostService);//null
	}
	@PostConstruct
	public void myInit()
	{
		System.out.println("in init "+blogPostService);//not null
	}
	//URL - http://host:port/ctx_path/blogger/home , method= GET
	//resp - blogger's home page , hello name + list of blogs.
	@GetMapping("/home")
	public String renderHomePage(Model map) {
		System.out.println("in blogger hm page");
		//invoke service method to get all blogs
		map.addAttribute("blogs_list", blogPostService.getAllPosts());
		return "/blogger/home";//LVN  -> AVN
	}

}
