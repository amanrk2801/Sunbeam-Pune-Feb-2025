package com.sunbeam.dao;

import com.sunbeam.entities.User;
import com.sunbeam.entities.UserRole;

import org.hibernate.*;
import static com.sunbeam.utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.List;

public class UserDaoImpl implements UserDao {

	@Override
	public String signUpUser(User newUser) {
		// newUser - TRANSIENT - exists only in heap
		String mesg = "Registration failed!!!!!!";
		// 1. Get Session from SF
		/*
		 * API of SessionFactory public Session getCurrentSession() throws
		 * HibernateExcetion - SF checks if there is an existing session bound to
		 * current thread(main) - yes - rets existing - no - creates new session OR
		 * public Session openSession() throws HibernateExcetion
		 */
		Session session = getFactory().getCurrentSession();
		Session session2 = getFactory().getCurrentSession();
		System.out.println(session == session2);// t
		/*
		 * 2. Begin a Tx Session API public Transaction beginTransaction() throws
		 * HibernateExcetion
		 */
		Transaction tx = session.beginTransaction();
		System.out.println("is open " + session.isOpen() + " is connected " + session.isConnected());// t t
		try {
			/*
			 * 3. Session API for inserting a record - public void persist(Object
			 * trasientObjectRef) throws HibernateExcetion
			 */
			session.persist(newUser); // newUser : PERSISTENT
			// => success
			tx.commit(); /*
							 * What does Hibernate do upon commit ? 1. session.flush() - Triggers auto dirty
							 * checking - Synchronizes state of L1 cache with DB - new entity - insert -
							 * existing entity with updated state - update - entity marked for removal -
							 * delete 2. session.close() - L1 cache is destroyed - Pooled out DB connection
							 * rets to DBCP
							 */
			mesg = "User signed up with ID" + newUser.getUserId();
		} catch (RuntimeException e) {
			// => failure
			if (tx != null)
				tx.rollback();
			/*
			 * What does Hibernate do upon rollback ? 1. session.close() - L1 cache is
			 * destroyed - Pooled out DB connection rets to DBCP
			 * 
			 */
			// re throw the exception to the caller
			throw e;
		}
		System.out.println("is open " + session.isOpen() + " is connected " + session.isConnected());// f f
		// newUser - DETACHED (from L1 cache)
		return mesg;
	}

	@Override
	public User getUserDetailsById(Long userId) {
		User user = null; // doesn't exist in heap
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			user = session.get(User.class, userId);// select
			user = session.get(User.class, userId);// cache
			user = session.get(User.class, userId);// cache
			// user - PERSISTENT
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		// user - DETACHED
		return user;
	}

	@Override
	public List<User> getAllUsers() {
		List<User> users = null;
		String jpql = "select u from User u";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {

			users = session.createQuery(jpql, User.class).getResultList();
			// users : List of PERSISTENT entities
			tx.commit();// L1 cache is destroyed n db cn rets to the DBCP
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return users;// users : List of DETACHED entities
	}

	@Override
	public List<User> getUserDetailsByRoleAndDoB(UserRole role1, LocalDate dob1) {
		List<User> users = null;
		String jpql = "select u from User u where u.userRole = :role and u.dob > :dt";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class) // Query
					.setParameter("role", role1) // set 1st named param
					.setParameter("dt", dob1) // set 2nd named param
					.getResultList();// exec -> ORM -> List of PERSISTENT entities
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return users;// list of detached entities
	}

	@Override
	public List<String> getUserLastNamesByRole(UserRole userRole1) {
		List<String> lastNames = null;
		String jpql = "select u.lastName from User u where u.userRole=:rl";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			lastNames = session.createQuery(jpql, String.class).setParameter("rl", userRole1).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return lastNames;
	}

	@Override
	public List<User> getDetailsByRole(UserRole role) {
		List<User> users = null;
		String jpql = "select new com.sunbeam.entities.User(u.firstName,u.lastName,u.dob) "
				+ "from User u where u.userRole=:rl";
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("rl", role).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		return users;
	}

	@Override
	public String changePassword(String email1, String oldPwd1,
			String newPwd1) {
		String mesg="Password updation failed.....";
		//get user bu em n pass
		String jpql="select u from User u where u.email=:em and u.password=:pass";
		User user=null;
		// 1. Get Session from SessionFactory
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			user=session.createQuery(jpql, User.class)
					.setParameter("em", email1)
					.setParameter("pass", oldPwd1)
					.getSingleResult();
			//=> success - user : PERSISTENT
			user.setPassword(newPwd1);//modifying state of persistent entity
			tx.commit();
			mesg="changed password !";
			/*
			 * session.flush() -> dirty chcking -> DML - update
			 * session.close() -> user - DETACHED from L1 cache
			 */
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exception to the caller
			throw e;
		}
		user.setPassword("1234567890");//detached state -> is not reflected in DB.
		return mesg;
	}

}
