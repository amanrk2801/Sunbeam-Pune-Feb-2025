package com.sunbeam.dao;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sunbeam.entities.Address;
import com.sunbeam.entities.User;

public class AddressDaoImpl implements AddressDao {

	@Override
	public String assignUserAddress(Long userId, Address newAdr) {
		String mesg="assigning adr failed !";
		// 1. get session from SF (getCurrentSession)
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			//3. get user from its id n confirm if user exists n address is not yet assigned
			User user=session.get(User.class, userId);
			if(user != null && user.getUserAddress() == null) {
				//establish uni dir User -> Address
				user.setUserAddress(newAdr);
			//	session.persist(newAdr);NOT REQUIRED , thanks to cascading !
				mesg="assigned address to user";
			}
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return mesg;
	}

}
