package com.sunbeam.service;

import java.util.List;

import com.sunbeam.entities.BlogPost;

public interface BlogPostService {
//add a method to list all posts
	List<BlogPost> getAllPosts();
	String createNewBlog(BlogPost post);

	BlogPost getBlogDetails(Long id);

	String updateBlogContents(Long id, String content);
	
	String deleteBlogPost(Long blogPostId);
}
