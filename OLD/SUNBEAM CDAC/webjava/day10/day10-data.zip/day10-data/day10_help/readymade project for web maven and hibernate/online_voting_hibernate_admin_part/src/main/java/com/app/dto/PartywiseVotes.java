package com.app.dto;

public class PartywiseVotes {
	private String party;
	private long votes;
	public PartywiseVotes() {
		// TODO Auto-generated constructor stub
	}
	public PartywiseVotes(String party, long votes) {
		super();
		this.party = party;
		this.votes = votes;
	}
	public String getParty() {
		return party;
	}
	public void setParty(String party) {
		this.party = party;
	}
	public long getVotes() {
		return votes;
	}
	public void setVotes(long votes) {
		this.votes = votes;
	}
	
		
}
