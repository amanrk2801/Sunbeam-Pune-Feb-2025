package com.sunbeam.tester;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import java.util.Scanner;

//import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.SessionFactory;

import com.sunbeam.dao.UserDao;
import com.sunbeam.dao.UserDaoImpl;

public class GetUserDetailsById {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); 
				Scanner sc = new Scanner(System.in)) // SF -> DBCP
		{
			UserDao dao=new UserDaoImpl();
			System.out.println("Enter user id");
				//invoker dao's method
			System.out.println(dao.getUserDetailsById
					(sc.nextLong()));
		} // JVM - sc.close() , sf.close() => cleaning up of DBCP
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
