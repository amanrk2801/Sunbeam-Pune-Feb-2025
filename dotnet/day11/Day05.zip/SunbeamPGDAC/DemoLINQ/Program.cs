﻿namespace DemoLINQ
{
    internal class Program
    {
        static void Main(string[] args)
        {

            var emps = new List<Emp>() {
                new Emp(){ No = 11, Name = "Hitesh", Address = "Pune" },
                 new Emp(){ No = 12, Name = "Mitesh", Address = "Panji" },
                  new Emp(){ No = 13, Name = "Ritesh", Address = "Patana" },
                   new Emp(){ No = 14, Name = "Jitesh", Address = "Mumbai" },
                    new Emp(){ No = 15, Name = "Nitesh", Address = "Chennai" },
                     new Emp(){ No = 16, Name = "Latesh", Address = "Nagpur" }
            };

            //foreach (var emp in emps)
            //{
            //    if (emp.Address.ToLower().Contains("n"))
            //    {
            //        Console.WriteLine(emp.Name + " | " + emp.Address);
            //    }
            //}



            //var result = (from emp in emps
            //              where emp.Address.ToLower().Contains("n")
            //              select emp).ToList();

            var result = emps
                            .Where((emp) => 
                            { 
                                return emp.Address.ToLower().Contains("n");
                            })
                            .Select((emp) => { return emp.Name; });


            //emps.Add(new Emp() { No = 9, Name = "Dnyanesh", Address = "Nagar" });

            //foreach (var item in result)
            //{
            //    Console.WriteLine(item.Name + " | " + item.Address);
            //}

            foreach (var item in result)
            {
                Console.WriteLine(item);
            }

        }
    }

    public class Emp
    {
        public int No { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }
}
