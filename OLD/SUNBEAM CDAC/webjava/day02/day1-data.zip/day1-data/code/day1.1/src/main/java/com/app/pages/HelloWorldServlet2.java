package com.app.pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HelloWorldServlet2 extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("in do-get 1234 of "+getClass()+"- by" + Thread.currentThread());
				
		// 1. set resp cont type
		resp.setContentType("text/html");
		// 2. get writer for the text resp
		try (PrintWriter pw = resp.getWriter()) {
			pw.print("<h5> Hello from servlets !" + LocalDateTime.now() + "</h5>");
		} // JVM - pw.close() -> pw.flush() -> resp is rendered -> closed

	}

	@Override
	public void destroy() {
		System.out.println("in destroy - by" + Thread.currentThread());

	}

	@Override
	public void init() throws ServletException {
		System.out.println("in init - by" + Thread.currentThread());
	}
	// to understand life cycle - init , doGet n destroy

}
