package com.sunbeam.dao;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sunbeam.entities.BlogPost;
import com.sunbeam.entities.Category;
import com.sunbeam.entities.Role;
import com.sunbeam.entities.User;

public class BlogPostDaoImpl implements BlogPostDao {

	@Override
	public String createNewPost(BlogPost newPost, Long categoryId, Long bloggerId) {
		String mesg = "adding new post failed !!!!!!!!!!";
		// 1. get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			// 3. get category ref from it's id
			Category category = session.get(Category.class, categoryId);
			// 4 get blogger from its id
			User blogger = session.get(User.class, bloggerId);
			if (category != null && blogger != null && blogger.getRole() == Role.BLOGGER) {
				// => category n blogger exists,
				// establish bi dir asso. between Category n BlogPost
				// category - PERSISTENT
				category.addBlogPost(newPost);// modifying state of the persistent entity
				// establish uni dir BlogPost --> User
				newPost.setBlogger(blogger);
				// persist
				// session.persist(newPost);
				mesg = "added new blog post....";
			}
			tx.commit();// session.flush -> dirty chking ->CascadeType.MERGE -> new entity : post ->
						// insert
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public String removeBlog(Long catId, Long blogId) {
		String mesg = "removing blog failed";
		// 1. get session from SF (getCurrentSession)
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			//Get category reference
			Category category=session.get(Category.class, catId);
			//Get blog post ref
			BlogPost post=session.get(BlogPost.class, blogId);
			if(category != null && post !=null)
			{
				//de link
				category.removeBlogPost(post);
				mesg="removed post from the category";
			}
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return mesg;
	}

}
