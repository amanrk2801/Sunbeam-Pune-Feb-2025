package com.sunbeam.dao;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import com.sunbeam.entities.User;
import com.sunbeam.entities.UserRole;

public interface UserDao {
// add a method for user sign up
	String signUpUser(User newUser);

	User getUserDetailsById(Long userId);

	List<User> getAllUsers();

	List<User> getUserDetailsByRoleAndDoB(UserRole role, LocalDate dob);

	List<String> getUserLastNamesByRole(UserRole userRole);

	List<User> getDetailsByRole(UserRole role);

	String changePassword(String email, String oldPwd, String newPwd);

	String applyDiscount(LocalDate date, UserRole role, double discountAmount);

	String deleteUserDetailsById(Long nextLong);

	String saveImage(String file, Long userId) throws IOException;

	String restoreImage(String filePath, String email) throws IOException;
}
