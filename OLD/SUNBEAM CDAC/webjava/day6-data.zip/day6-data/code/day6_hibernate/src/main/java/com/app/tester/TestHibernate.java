package com.app.tester;

import org.hibernate.SessionFactory;

import static com.app.utils.HibernateUtils.getFactory;

public class TestHibernate {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory()) {
			System.out.println("hibernate up n running " + sf);
		} //JVM - sf.close() -> DBCP clened up !
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
