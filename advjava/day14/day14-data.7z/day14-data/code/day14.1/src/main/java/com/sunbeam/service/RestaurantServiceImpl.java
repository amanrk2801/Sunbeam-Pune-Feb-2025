package com.sunbeam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sunbeam.custom_exceptions.ResourceNotFoundException;
import com.sunbeam.dao.RestaurantDao;
import com.sunbeam.entities.Restaurant;

@Service
@Transactional
public class RestaurantServiceImpl implements RestaurantService {
	// depcy - auto wire by type - field level
	@Autowired
	private RestaurantDao restaurantDao;

	@Override
	public List<Restaurant> getAllRestaurants() {
		// TODO Auto-generated method stub
		return restaurantDao.findByStatusTrue();
	}

	@Override
	public String deleteRestaurantDetail(Long restaurantId) {
		// get restaurant from its id
		Restaurant restaurant = restaurantDao.findById(restaurantId)
				.orElseThrow(() -> new ResourceNotFoundException("invalid restaurant id !!!!!"));
		// => restaurant : PERSISTENT
		restaurant.setStatus(false);// modifying state the persistent entity
		return "soft deleted restaurant details ....";
	}
	/*
	 * Service layer rets (@Transactional) Spring supplied Tx manager bean - checks
	 * run time excs (un chked) - > yes - > tx.rollback() -> session.close() no excs
	 * - >tx.commit -> session.flush -> dirty checking -> DML - update ->
	 * session.close()
	 */

	@Override
	public Restaurant getRestaurantDetails(Long id) {
		// invoke dao's method
		return restaurantDao.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Restaurant ID !!!!!"));
	}

	@Override
	public String updateDetails(Long id, Restaurant restaurant) {
		// 1. assign id
		restaurant.setId(id);// id - not null -> update : DML
		// setter
		restaurant.setStatus(true);

		// 2. invoke dao's method
		restaurantDao.save(restaurant);
		return "Restaurant details updated ";
	}

	@Override
	public String addNewRestaurant(Restaurant transientRestaurant) {
		// setter
		transientRestaurant.setStatus(true);
		// invoke dao's method - save : inherited API from CrudRepo
		Restaurant persistenRestaurant = restaurantDao.save(transientRestaurant);
		return "Added new restaurant with ID=" + persistenRestaurant.getId();
	}// upon no exc -> commit -> flush -> insert -> close

}
