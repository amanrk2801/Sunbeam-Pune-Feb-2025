package com.sunbeam.controller;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/test") //Optional BUT recommended 
//annotation - class level , to specify base URL pattern
public class TestController {
	public TestController() {
		System.out.println("in ctor " + getClass());
	}
	/*
	 * URL - http://host:port/ctx_path/test/test1
	 * Method - GET
	 * Payload - none
	 * Resp - dyn resp , changing time stamp
	 */
	@GetMapping("/test1") //@GetMapping = 
	//@RequestMapping(method=GET) => doGet
	public ModelAndView testModelAndView() {
		System.out.println("in test m n  v");
		return new ModelAndView("test/display", "server_ts",
				LocalDateTime.now()); //AVN - /WEB-INF/views/test/display.jsp
	}
	/*
	 * Handler rets ModelAndView -> D.S -> 
	 * extracts LVN -> V.R -> AVN -> D.S 
	 * -> D.S adds model attr -> req scope -> forward
	 */
	
	/*
	 * URL - http://host:port/ctx_path/test/test2
	 * Method - GET
	 * Payload - none
	 * Resp - dyn resp , changing time stamp + list
	 */
	@GetMapping("/test2")
	public String testModelMap(Model map) {
		System.out.println("in test model map "+map);//{}
		//add model attributes
		map.addAttribute("server_time", LocalTime.now())
		.addAttribute("number_list",List.of(10, 20, 30, 40));
		System.out.println("in test model map "+map);//{....}
		
		return "test/display2";		
	}
	/*
	 * Handler retes - explicitly - > LVN -> D.S
	 * SC implicitly rets Model Map -> D.S
	 * D.S -> LVN -> V.R -> AVN : /WEB-INF/views/test/display2.jsp
	 * -> add model attrs under req scope -> forwards to view 
	 */
}
