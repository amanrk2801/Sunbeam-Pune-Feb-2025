package tester;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sunbeam.dependent.PublicSchool;

public class TestSpringContainer {

	public static void main(String[] args) {
		// start SC
		try (ClassPathXmlApplicationContext ctx = 
				new ClassPathXmlApplicationContext("bean-config.xml")) {
			//1. Health check of SC
			System.out.println("SC up n running ....");
			//2. get ready to use spring from SC			
			/*
			 * How to get ready to use spring bean from SC ?
			 * Method of BeanFactory i/f
			 * public <T> T getBean(String beanId , Class<T> beanClass) 
			 * throws BeansException
			 * T - type of spring bean
			 * 
			 */
			PublicSchool school1=ctx.getBean
					("public_school", PublicSchool.class);
			//3. invoke B.L of public school - manage academics
			school1.manageAcademics();
			
			PublicSchool school2=ctx.getBean
					("public_school", PublicSchool.class);
			System.out.println(school1==school2);//f
			
		} //JVM - ctx.close() -> calls destroy on singleton beans - > GC -> SC shut down
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
