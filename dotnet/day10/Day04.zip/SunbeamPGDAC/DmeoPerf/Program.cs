﻿using System.Diagnostics;
using System.Linq.Expressions;

namespace DmeoPerf
{
    //delegate bool MyDelegate(int i);
    internal class Program
    {
        static void Main(string[] args)
        {

            //MyDelegate pointer = new MyDelegate(Check);

            //Func<int, bool> pointer = new Func<int, bool>(Check);

            //Func<int, bool> pointer = delegate (int x)
            //                            {
            //                                return (x > 10);
            //                            };

            //Func<int, bool> pointer =  (x)=>
            //                            {
            //                                return (x > 10);
            //                            };

            //1. Create expression Tree
            Expression<Func<int, bool>> tree = (x) =>(x > 10);

            //2. Compile tree in Machine/Binary Code
            Func<int, bool> pointer = tree.Compile();

            Stopwatch sw = new Stopwatch(); 
            sw.Start();

            //bool result = Check(20);

            //3. Execute Compiled Expression Tree
            bool result = pointer(20);
                           
                         
            sw.Stop();
            
            Console.WriteLine(result);

            Console.WriteLine("Time taken  = {0}", sw.ElapsedTicks);

            Console.ReadLine();
        }

       

        //public static bool Check(int x)
        //{
        //    return (x > 10);
        //}
    }
}
