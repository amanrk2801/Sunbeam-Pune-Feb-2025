package com.sunbeam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller //spring bean - req handling logic
//singleton n eager
public class IndexController {
	public IndexController() {
		System.out.println("in ctor of "+getClass());
	}
	//add req handling method for rendering index page
	//URL - http://host:port/ctx_path/ , method=GET
	@GetMapping("/")
	public String renderIndexPage() {
		System.out.println("in render index page");
		return "/index";//AVN - /WEB-INF/views/index.jsp
	}
	
	
	

}
