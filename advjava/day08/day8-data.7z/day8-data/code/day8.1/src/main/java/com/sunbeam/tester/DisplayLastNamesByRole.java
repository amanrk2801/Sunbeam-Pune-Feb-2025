package com.sunbeam.tester;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import java.util.Scanner;

//import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.SessionFactory;

import com.sunbeam.dao.UserDao;
import com.sunbeam.dao.UserDaoImpl;
import com.sunbeam.entities.UserRole;

public class DisplayLastNamesByRole {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); 
				Scanner sc = new Scanner(System.in)) // SF -> DBCP
		{
			UserDao dao=new UserDaoImpl();
			System.out.println("Enter user role");
				//invoker dao's method
			dao.
			getUserLastNamesByRole
			(UserRole.valueOf(sc.next().toUpperCase()))
			.forEach(System.out::println);

		} // JVM - sc.close() , sf.close() => cleaning up of DBCP
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
