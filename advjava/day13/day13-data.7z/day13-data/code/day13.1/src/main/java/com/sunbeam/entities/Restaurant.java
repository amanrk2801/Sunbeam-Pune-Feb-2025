package com.sunbeam.entities;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "restaurants")
@NoArgsConstructor
@Getter
@Setter
/*
 * Project Tip
 *  Typically NEVER add (exclude) any association 
 *  based properties in toString
 *   - it may lead to recursion 
 *    - causing stack overflow error.
 */
@ToString(callSuper = true, exclude = "foodItems")
@EqualsAndHashCode(of="name",callSuper = false)
public class Restaurant extends BaseEntity {
	@Column(length = 100, unique = true)
	private String name;
	private String address;
	@Column(length = 20)
	private String city;
	private String description;
	// Restaurant 1 -----> * FoodItem
	/*
	 * Always init the collection - to avoid NPExc
	 */
	@OneToMany(mappedBy = "myRestaurant",
			cascade = CascadeType.ALL, orphanRemoval = true
			/* ,fetch = FetchType.EAGER */)
	private List<FoodItem> foodItems = new ArrayList<>();
	//for soft delete
	private boolean status;

	public Restaurant(String name, String address, String city, String description) {
		super();
		this.name = name;
		this.address = address;
		this.city = city;
		this.description = description;
		this.status=true;
	}

	// add food item
	public void addFoodItem(FoodItem foodItem) {
		// parent -> child
		this.foodItems.add(foodItem);
		// child --> parent
		foodItem.setMyRestaurant(this);
	}

	// remove food item
	public void removeFoodItem(FoodItem foodItem)
	{
		//parent ---X---- child
		this.foodItems.remove(foodItem);
		//child ----X--- parent
		foodItem.setMyRestaurant(null);
	}

}
