package com.app.dao;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import com.app.entities.Role;
import com.app.entities.User;

public interface UserDao {
//register user
	String registerNewUser(User newUser);

	// get user details by its id
	User getUserDetails(Long userId);

	// get all user details
	List<User> getAllUsers();

	// get user details by dob n role
	List<User> getUsersByDobAndRole(LocalDate begin, LocalDate end, Role userRole);
	//get all  user's last names  under a specific role
	List<String> getLastNamesByRole(Role role1);
	//get selected user details by role
	List<User> getSelectedUserDetailsByRole(Role role1);
	//change password
	String changePassword(String email,String oldPasswrd,String newPwd);
	//bulk update
	String applyDiscount(LocalDate date,double discountAmount);
	//delete user details by id
	String deleteUserDetails(Long userId);
	//store Blob(image) in the DB
	String storeImage(String fileName,String email) throws IOException;
}
