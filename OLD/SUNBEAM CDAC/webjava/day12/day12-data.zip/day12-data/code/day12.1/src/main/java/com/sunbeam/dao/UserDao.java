package com.sunbeam.dao;

import com.sunbeam.entities.User;

public interface UserDao {
User authenticateUser(String email,String password);
}
