package com.sunbeam.utils;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class HibnernateUtils {
	private static SessionFactory factory;
	static {
		System.out.println("in static init block");
		factory=new Configuration() //empty config
				.configure() //loaded config from hibernate.cfg.xmk
				.buildSessionFactory();
	}
	//getter
	public static SessionFactory getFactory() {
		return factory;
	}
	
}
