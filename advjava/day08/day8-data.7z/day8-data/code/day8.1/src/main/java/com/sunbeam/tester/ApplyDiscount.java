package com.sunbeam.tester;

import static com.sunbeam.utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

//import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.SessionFactory;

import com.sunbeam.dao.UserDao;
import com.sunbeam.dao.UserDaoImpl;
import com.sunbeam.entities.UserRole;

public class ApplyDiscount {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); 
				Scanner sc = new Scanner(System.in)) // SF -> DBCP
		{
			UserDao dao = new UserDaoImpl();
			System.out.println("Enter date role n discount amount");
			// invoker dao's method
			System.out.println(dao.applyDiscount(
					LocalDate.parse(sc.next())
					,UserRole.valueOf(sc.next().toUpperCase()),
					sc.nextDouble()));

		} // JVM - sc.close() , sf.close() => cleaning up of DBCP
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
