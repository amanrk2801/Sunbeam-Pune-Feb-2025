package com.ecom.exception_handler;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.ecom.custom_exceptions.ResourceNotFoundException;
import com.ecom.dto.ApiResponse;

@RestControllerAdvice // @ControllerAdvice + @RespBody
/*
 * Represents a spring bean containing - common advice to all RestControllers,
 * regarding exc handling
 */
public class CustomGlobalExceptionHandler {
	// exception handling method - for ResourceNotFoundException
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<?> handleResourceNotFoundException(ResourceNotFoundException e) {
		System.out.println("in resource not found exc...");
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse(e.getMessage()));
	}

	// catch @Valid @RequestBody related - MethodArgumentNotvalidException
	// exception handling method - for MethodArgumentNotValidException
	@ExceptionHandler(MethodArgumentNotValidException.class)
//	@ResponseStatus(HttpStatus.BAD_REQUEST)//for adding Status code
	public ResponseEntity<?> handleMethodArgumentNotValidException
	(MethodArgumentNotValidException e) {
		System.out.println("in handle method arg not valid - validating req body");
		//get list of all field errors(rejected fields)
		List<FieldError> fieldErrors = e.getFieldErrors();
		/*
		 * soln - covert List -> Map 
		 * Key -rejected field name (FieldError : getField)
		 * Value - error mesg (FieldError : getDefaultMessage)
		 */
		Map<String, String> map = fieldErrors.stream() //Stream<FieldError>
		.collect(Collectors.toMap(FieldError::getField,
				FieldError::getDefaultMessage));
		
		return ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body(map);
	}

	// catch all block
	// exception handling method - for RunTimeException
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<?> handleRemainingExceptions(RuntimeException e) {
		System.out.println("in catch-all");
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new ApiResponse(e.getMessage()));
	}

}
