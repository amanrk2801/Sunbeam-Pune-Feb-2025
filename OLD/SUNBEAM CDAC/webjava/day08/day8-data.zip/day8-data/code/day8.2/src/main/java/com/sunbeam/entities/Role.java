package com.sunbeam.entities;

public enum Role {
	ADMIN, BLOGGER, COMMENTER
}
