package com.sunbeam.entities;


public enum UserRole {
	ROLE_CUSTOMER, ROLE_MANAGER, 
	ROLE_ADMIN,ROLE_DELIVERY_PERSON
}
