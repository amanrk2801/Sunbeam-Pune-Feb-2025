﻿using Microsoft.AspNetCore.Mvc;
using DemoMVC.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace DemoMVC.Controllers
{
    public class HomeController : Controller
    {

        SBDBContext db = new SBDBContext();
        public IActionResult Index()
        {
            return View(db.Emps.ToList());
        }

        public IActionResult GetText()
        {
            return new ContentResult() { Content = "Hello!", ContentType = "text/plain" };
        }

        public IActionResult GetJSON()
        {
            return new JsonResult(db.Emps.ToList());
        }

        public IActionResult Create()
        {
            return View();
        }

        //public IActionResult AfterCreate([ModelBinder(typeof(MyModelBinder))] Emp emp)

        public IActionResult AfterCreate(Emp emp)
        {
            db.Emps.Add(emp);
            db.SaveChanges();

            return Redirect("/Home/Index");
        }


        public IActionResult Edit(int? id) 
        {
            Emp emp = db.Emps.Find(id);
            return View(emp);   
        }

        public IActionResult AfterEdit(Emp empUpdated)
        {
            Emp emp = db.Emps.Find(empUpdated.No);
            emp.Name = empUpdated.Name;
            emp.Address = empUpdated.Address;

            db.SaveChanges();

            return Redirect("/Home/Index");
        }

        public IActionResult Delete(int? id)
        {
            Emp emp = db.Emps.Find(id);
            db.Emps.Remove(emp);
            db.SaveChanges();
            return Redirect("/Home/Index");
        }



        //public IActionResult Index()
        //{
        //    Emp emp = new Emp() { No = 1, Name = "Kushal", Address = "Pune" };

        //    return View(emp);
        //}
    }

    //public class MyModelBinder : IModelBinder
    //{
    //    public Task BindModelAsync(ModelBindingContext bindingContext)
    //    {
    //        throw new NotImplementedException();
    //    }
    //}
}
