﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace Demo.Filters
{
    public class AuthFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.HttpContext.Request.Path.ToString().ToLower().Contains("login"))
            {

                string token = context.HttpContext.Request.Headers.Authorization;

                if (token != null && token=="1234")
                {
                    //Do nothing .. proceed 
                    context.HttpContext.Response.StatusCode = 200;
                }
                else
                {
                    context.HttpContext.Response.StatusCode = 400;
                   //await  context.HttpContext.Response.WriteAsync("Token Invalid");
                }

            }
        }
    }
}
