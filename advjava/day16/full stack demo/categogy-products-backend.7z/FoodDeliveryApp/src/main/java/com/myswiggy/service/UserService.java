package com.myswiggy.service;

import java.time.LocalDate;
import java.util.List;

import com.myswiggy.dto.AuthRequest;
import com.myswiggy.dto.UserReqDTO;
import com.myswiggy.dto.UserRespDTO;

import jakarta.validation.constraints.Past;

public interface UserService {

	UserRespDTO registerUser(UserReqDTO dto);

	UserRespDTO authenticate(AuthRequest dto);

	List<UserRespDTO> getUsersByDate(LocalDate dob);

}
