package com.sunbeam.dao;

import java.time.LocalDate;
import java.util.List;

import com.sunbeam.entities.User;
import com.sunbeam.entities.UserRole;

public interface UserDao {
// add a method for user sign up
	String signUpUser(User newUser);

	User getUserDetailsById(Long userId);

	List<User> getAllUsers();

	List<User> getUserDetailsByRoleAndDoB(UserRole role, LocalDate dob);

	List<String> getUserLastNamesByRole(UserRole userRole);

	List<User> getDetailsByRole(UserRole role);

	String changePassword(String email, String oldPwd, String newPwd);
}
