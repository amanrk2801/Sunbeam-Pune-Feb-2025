package com.sunbeam.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "categories")
@NoArgsConstructor
@Getter
@Setter
@ToString(callSuper = true)
public class Category extends BaseEntity {
	@Column(name = "category_name", length = 30, unique = true)
	private String categoryName;
	private String description;
	// one -> many Category 1->* BlogPost
//	@OneToMany(mappedBy = "blogCategory",
//			cascade = CascadeType.ALL,orphanRemoval = true
//	/* ,fetch = FetchType.EAGER */) // mandatory , otherwise MappingException !
//	private List<BlogPost> posts = new ArrayList<>();

	

	public Category(String categoryName, String description) {
		super();
		this.categoryName = categoryName;
		this.description = description;
	}

	// add helper method to establish a bi dir association between Category 1<--->*
	// BlogPost
//	public void addBlogPost(BlogPost post) {
//		//add post ref to the list
//		this.posts.add(post);
//		//assign category ref to the post
//		post.setBlogCategory(this);
//	}
//	// add helper method to un -establish(de link) a bi dir association between Category 1<--->*
//		// BlogPost
//		public void removeBlogPost(BlogPost post) {
//			this.posts.remove(post);
//			post.setBlogCategory(null);
//		}

//	@Override
//	public String toString() {
//		return "Category ID " + getId() + " [categoryName=" + categoryName + ", description=" + description + "]";
//	}

}
