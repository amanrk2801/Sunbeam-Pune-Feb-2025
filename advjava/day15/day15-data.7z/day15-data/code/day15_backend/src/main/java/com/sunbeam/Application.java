package com.sunbeam;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	/*
	 * Configure ModelMapper as a spring bean , so that
	 *  - SC manages its life cycle
	 *  - It can be injected as a dependency in any other spring bean
	 * 
	 *  
	 */
	@Bean
	ModelMapper modelMapper() {
		System.out.println("creating model mapper");
		return new ModelMapper();
	}

}
