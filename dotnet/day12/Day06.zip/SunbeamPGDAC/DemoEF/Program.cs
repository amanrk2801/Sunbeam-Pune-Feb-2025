﻿using Microsoft.EntityFrameworkCore.ChangeTracking.Internal;

namespace DemoEF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SunbeamDBContext db = new SunbeamDBContext();

            //Emp emp = new Emp() { Name = "Mahesh", Address = "Pune" };

            //db.Emps.Add(emp);
            //db.SaveChanges();

            //Emp empToBeUpdated = db.Emps.Find(1);
            //empToBeUpdated.Name = "Jayashri";
            //empToBeUpdated.Address = "Chennai";

            //db.SaveChanges();


            Emp empToBeDeleted = db.Emps.Find(1);
            db.Emps.Remove(empToBeDeleted);
            db.SaveChanges();


            var emps = db.Emps.ToList();

            foreach (var item in emps)
            {
                Console.WriteLine(item.No +  " | " + item.Name + " | " + item.Address );
            }

            Console.ReadLine();
        }

    }
}
