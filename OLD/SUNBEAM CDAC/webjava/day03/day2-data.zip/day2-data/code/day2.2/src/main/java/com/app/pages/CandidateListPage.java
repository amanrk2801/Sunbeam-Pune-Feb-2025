package com.app.pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.app.dao.CandidateDaoImpl;
import com.app.entities.Candidate;
import com.app.entities.User;

/**
 * Servlet implementation class AdminPageServlet
 */
@WebServlet("/candidate_list")
public class CandidateListPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. set content type
		response.setContentType("text/html");
		// 2. get PW
		try (PrintWriter pw = response.getWriter()) {
			// pw.print("<h5>Welcome Voter ! "+request.getParameter("em")+"</h5>");
			pw.print("<h5>Welcome Voter  ! </h5>");
			// 3. get HttpSession from WC
			HttpSession hs = request.getSession();
			System.out.println("session new " + hs.isNew());// false : if cookies are enabled otherwise true
			System.out.println("session id from login page " + hs.getId());// same : if cookies are enabled otherwise
																			// different
			// 4. get user details from HttpSession
			User user = (User) hs.getAttribute("user_info");
			if (user != null) {
				pw.print("<h5> Hello , " + user.getFirstName() + " " + user.getLastName() + " </h5>");
				
				// 5. get candidate dao from HttpSession
				CandidateDaoImpl dao = (CandidateDaoImpl) hs.getAttribute("candidate_dao");
				// 6. invoke dao's method for getting candidate list
				List<Candidate> candidates = dao.getAllCandidates();
				// dynamic form generation
				pw.print("<h5> Candidate List</h5>");
				pw.print("<h5><form method='post'"
						+ "action='logout_page'></h5>");
				for (Candidate c : candidates) {
					pw.print("<h6><input type='radio' name='cid' value='" + c.getCandidateId() + "'/>" + c.getName()
							+ "</h6>");
				}
				pw.print("<h5> <input type='submit' value='Vote'/></h5>");

				pw.print("<h5></form></h5>");

			} else
				pw.print("<h5> No cookies , Session Tracking failed !!!!!!!!</h5>");

		} catch (Exception e) {
			throw new ServletException("err in do-get " + getClass(), e);
		}
	}

}
