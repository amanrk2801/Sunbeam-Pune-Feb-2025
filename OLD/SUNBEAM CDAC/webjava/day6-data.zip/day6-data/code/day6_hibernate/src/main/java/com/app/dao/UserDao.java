package com.app.dao;

import com.app.entities.User;

public interface UserDao {
//register user
	String registerNewUser(User newUser);
	//get user details by its id
	User getUserDetails(Long userId);
}
