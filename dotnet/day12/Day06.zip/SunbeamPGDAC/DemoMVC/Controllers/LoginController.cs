﻿using DemoMVC.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DemoMVC.Controllers
{
    public class LoginController : BaseController
    {
        public IActionResult SignIn()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SignIn(SBUser user)
        {
            if (user.UserName == "mahesh" && user.Password == "mahesh@123")
            {
                this.HttpContext.Session.SetString("Username", user.UserName);
                return Redirect("/Home/Index");
            }
            else
            {
                ViewBag.Message = "Invalid Credentials!";
                return View();
            }
        }

        public IActionResult Signout() {
            this.HttpContext.Session.Remove("Username");
            return Redirect("/Login/SignIn");
        }
    }
}
