package com.myswiggy.service;

import com.myswiggy.dto.OrderRequestDTO;
import com.myswiggy.dto.OrderRespDTO;

public interface OrderService {

	OrderRespDTO saveOrderDetails(OrderRequestDTO orderDetails);

}
