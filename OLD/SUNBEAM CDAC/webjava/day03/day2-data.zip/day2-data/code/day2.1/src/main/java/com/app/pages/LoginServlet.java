package com.app.pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.dao.UserDao;
import com.app.dao.UserDaoImpl;
import com.app.entities.User;

import static com.app.utils.DBUtils.*;

/**
 * Servlet implementation class LoginServlet
 */
/*
 * WC creates a map @ web app deployment time. Adds the entries per servlet key
 * - /login value -com.app.pages.LoginServlet
 */
@WebServlet(value = "/login", loadOnStartup = 1)
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDaoImpl userDao;

	/**
	 * @see Servlet#init()
	 */
	/*
	 * Overriding / Implementing form of the method CAN NOT throw NEW or BROADER
	 * CHECKED exceptions
	 */
	@Override
	public void init() throws ServletException {
		try {
			// open connection
			openConnection();
			userDao = new UserDaoImpl();
		} catch (Exception e) {
			System.out.println(e);
			/*
			 * Centralized exc handling in Servlets 1. catch the exception in Servlet class
			 * 2. re -throw the same exc to the caller (WC) by using ServletException API -
			 * public class ServletException(String mesg, Throwable rootCause)
			 */
			throw new ServletException("err in init of " + getClass(), e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			userDao.cleanUp();
			closeConnection();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. set resp cont type for the clnt
		response.setContentType("text/html");
		// 2. get PW to send buffered text resp -> clnt
		try (PrintWriter pw = response.getWriter()) {
			// 3.read request parameters
			/*
			 * ServletRequest Methods String getParameter(String paramName) Rets value or
			 * null String[] getParameterValues(String paramName) Rets values or null
			 * 
			 */
			String email = request.getParameter("em");
			String pwd = request.getParameter("pass");
			// 4. invoke dao's method for authentication
			User user = userDao.signIn(email, pwd);
			// 5. valid or invalid login
			if (user == null) {
				// invalid , send retry link to the clnt
				pw.print("<h5>Invalid Login , " + "Please <a href='login.html'>Retry</a></h5>");

			} else {
				// valid login 
				//6. Create a cookie
				//javax.servlet.http.Cookie(String name, String value)
				Cookie c1=new Cookie("user_details", user.toString());
				//7 . Add the cookie to resp header
				response.addCookie(c1);				
				//--> continue to role based authorization
				if (user.getRole().equals("admin")) {
					// redirect the clnt to admin page
					/*
					 * API of HttpServletResponse public void sendRedirect(String redirectLoc)
					 * throws IOException
					 */
					response.sendRedirect("admin_page");
				} else {
					// voter - role
					if (user.isStatus()) {
						// voted alrdy !
						response.sendRedirect("logout_page");
					} else {
						//voter - not yet voted 
						response.sendRedirect("candidate_list");
						/*
						 * WC sends temp redirect resp to the clnt
						 * SC 302 , Header - Location-candidate_list ,
						 * Set-Cookie -user_details-user.toString
						 * Body : empty
						 * clnt browser - cookies enabled case -stores the cookie
						 * in cache
						 * clnt browser -> send redirect req
						 * URL -http://host:port/ctx_path/candidate_list
						 * Method - GET
						 * header -Cookie - user_details-user.toString
						 * 
						 * 
						 */
					}
				}
			}

		} catch (Exception e) {
			// centralized exc handling
			throw new ServletException("err in servicing " + getClass(), e);
		}
	}

}
