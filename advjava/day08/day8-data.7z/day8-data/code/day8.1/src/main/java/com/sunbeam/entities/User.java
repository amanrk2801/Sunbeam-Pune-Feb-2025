package com.sunbeam.entities;

import java.time.LocalDate;
import jakarta.persistence.*;

@Entity
@Table(name="new_users") //to specify table name
public class User {
	/*
	 * Hibernate can perform null checking for the id property 
	 * more effectively than checking against the default 
	 * un saved value 0.
	 * What should be the id prop type ?
	 * prmitive or wrapper ?
	 *  - wrapper 
	 */
	@Id //=> PK constraint - mandatory
	//for auto id generation - with MySql DB using auto increment
	@GeneratedValue(strategy = GenerationType.IDENTITY) //optional
	@Column(name="user_id")//to specify col name
	private Long userId;
	@Column(name="first_name",length = 20)//col name n varchar(20)  size
	private String firstName;
	@Column(name="last_name",length = 30)//col name n varchar(30)  size
	private String lastName;
	@Column(length = 20,unique = true) //adds unique constraint
	private String email;
	@Column(nullable = false) // NOT NULL constraint
	private String password;
	@Transient //to skip a field  - from persistence (no column generation)
	private String confirmPassword;
	//no additional annotations , @Temporal - for older APIs - Date , 
	//Calendar , GregorianCalendar
	private LocalDate dob;
	//to create column type  - enum | varchar
	@Enumerated(EnumType.STRING)
	@Column(name="user_role")
	private UserRole userRole;
	@Column(name="subscription_amount")
	private double subscriptionAmount;
	@Lob //=> large object - BLOB (longblob) - byte[]  , CLOB - char[]
	private byte[] image;

	public User() {
		// TODO Auto-generated constructor stub
	}
	//parameterized ctor
	public User(String firstName, String lastName, String email, String password, LocalDate dob, UserRole userRole,
			double subscriptionAmount) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.dob = dob;
		this.userRole = userRole;
		this.subscriptionAmount = subscriptionAmount;
	}
	
	


	public User(String firstName, String lastName, LocalDate dob) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dob;
	}
	public Long getUserId() {
		return userId;
	}

	

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public UserRole getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

	public double getSubscriptionAmount() {
		return subscriptionAmount;
	}

	public void setSubscriptionAmount(double subscriptionAmount) {
		this.subscriptionAmount = subscriptionAmount;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", dob=" + dob + ", userRole=" + userRole + ", subscriptionAmount=" + subscriptionAmount + "]";
	}

}
