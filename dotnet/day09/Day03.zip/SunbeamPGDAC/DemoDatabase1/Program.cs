﻿using Microsoft.Data.SqlClient;
using System.Diagnostics;
using DemoDatabase1.Model;
using DemoDatabase1.DAL;

namespace DemoDatabase1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(  "1: See All, 2: Insert, 3: Update, 4: Delete");

            int choice = Convert.ToInt32( Console.ReadLine() );

            EMPOps ops = new EMPOps();
            switch (choice)
            {
                case 1:
                    List<Emp> empList = ops.GetEmps();

                    foreach (var emp in empList)
                    {
                        Console.WriteLine(emp.ToString());
                    }
                    break;

                case 2:
                    Emp empToAdd = new Emp();
                    Console.WriteLine("Enter Name");
                    empToAdd.Name = Console.ReadLine();

                    Console.WriteLine("Enter Address");
                    empToAdd.Address = Console.ReadLine();
                    
                    int rowsAffected = ops.AddEmp(empToAdd);
                    Console.WriteLine("Rows affected = {0}", rowsAffected);
                    break;
                case 3:
                    Emp empToUpdate = new Emp();

                    Console.WriteLine("Enter No To Update The Record:");
                    empToUpdate.No = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Enter Name");
                    empToUpdate.Name = Console.ReadLine();

                    Console.WriteLine("Enter Address");
                    empToUpdate.Address = Console.ReadLine();

                    int rowsAffectedOnUpdate = ops.UpdateEmp(empToUpdate);
                    Console.WriteLine("Rows affected = {0}", rowsAffectedOnUpdate);
                    break;

                case 4:

                    Console.WriteLine("Enter No To Remove The Record:");
                    int No = Convert.ToInt32(Console.ReadLine());

                    int rowsAffectedOnDelete = ops.RemoveEmp(No);
                    Console.WriteLine("Rows affected = {0}", rowsAffectedOnDelete);
                    break;
                default:
                    break;
            }

            Console.ReadLine();
        }
    }

}
