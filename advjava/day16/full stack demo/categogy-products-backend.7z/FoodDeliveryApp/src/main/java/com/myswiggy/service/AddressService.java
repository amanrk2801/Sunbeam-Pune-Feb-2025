//package com.myswiggy.service;
//
//import com.myswiggy.dto.AddressReqDTO;
//import com.myswiggy.dto.ApiResponse;
//
//public interface AddressService {
//
//	ApiResponse assignUserAddress(Long userId, AddressReqDTO dto);
//
//}
