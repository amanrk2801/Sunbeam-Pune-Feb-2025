﻿namespace DemoDB2
{
    public class Maths
    {

        public static int Add(int x, int y)
        {
            return x + y;
        }
    }
}