package com.sunbeam.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeam.entities.Category;
import com.sunbeam.service.CategoryService;

import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/categories")
@AllArgsConstructor
public class CategoryController {
	//depcy  - immutable , injected using ctro based D.I
	private final CategoryService categoryService;
	/*
	 * http://localhost:8080/categories
	 * Desc of end point - get all categories
	 * URL - http://host:port/categories
	 * Method - GET
	 * Payload - none
	 * Resp - List<Category> -> serialized to Json[] -> sent to REST clnt
	 */
	@GetMapping
	public List<Category> fetchAllCategories() {
		System.out.println("in list all categories");
		return categoryService.getAllCategories();
	}
	/*
	 * 
	 * Desc of end point - add new categories(create)
	 * URL - http://host:port/categories
	 * Method - POST
	 * Payload - JSON representation of Category -> Java (de-serial)
	 * @RequestBody
	 * Resp -string 
	 */
	@PostMapping
	public String addNewCategory(@RequestBody Category transientCategory)
	{
		System.out.println("in add category "+transientCategory);
		return categoryService.addNewCategory(transientCategory);
	}

}
