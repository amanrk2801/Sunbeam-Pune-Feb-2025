package com.sunbeam.tester;

import static com.sunbeam.utils.HibernateUtils.getFactory;

//import static com.sunbeam.utils.HibernateUtils.getFactory;

import org.hibernate.SessionFactory;

import com.sunbeam.dao.UserDao;
import com.sunbeam.dao.UserDaoImpl;

public class DisplayAllUsers {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory()) // SF -> DBCP
		{
			UserDao dao = new UserDaoImpl();
			
			// invoker dao's method
			System.out.println("All Users -");
			dao.getAllUsers()
			.forEach(System.out::println);
		} // JVM - sc.close() , sf.close() => cleaning up of DBCP
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
